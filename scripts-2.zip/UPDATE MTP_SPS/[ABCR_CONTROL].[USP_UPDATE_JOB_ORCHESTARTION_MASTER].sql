CREATE  Procedure [ABCR_CONTROL].[USP_UPDATE_JOB_ORCHESTARTION_MASTER]
@Tenant_Id int,
@Job_Id int,
@SQL nvarchar (Max)

As 
Begin 

	Select @Tenant_Id as Tenant, @Job_Id as JOBID, 'N' as Stat into #job_orch_master
	Execute sp_executesql @SQL

		if exists(select Stat from #job_orch_master where Stat = 'Y')
		Begin
			Select @SQL = replace(@SQL,'ABCR_CONTROL.VW_job_orchestration_master','ABCR_CONTROL.job_orchestration_master')
			Execute sp_executesql @SQL
		END
END



