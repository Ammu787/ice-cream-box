-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_JOB_CONFIGURATION_VALUES>
-- Author:      <Chiranjeevi>
-- Create Date: <14-09-2022>
-- Description: <Updating data into ABCR_CONTROL.USP_JOB_CONFIGURATION_VALUES table>
-- =============================================

CREATE  Procedure [ABCR_CONTROL].[USP_UPDATE_JOB_CONFIGURATION_VALUES]
@Job_Id int,
@SQL nvarchar (Max)

As 
Begin 

	Select @Job_Id as Jobid, 'N' as Stat into #job_config_values
	Execute sp_executesql @SQL

		if exists(select Stat from #job_config_values where Stat = 'Y')
		Begin
			Select @SQL = replace(@SQL,'ABCR_CONTROL.VW_job_configuration_values','ABCR_CONTROL.job_configuration_values')
			Execute sp_executesql @SQL
		END
END



