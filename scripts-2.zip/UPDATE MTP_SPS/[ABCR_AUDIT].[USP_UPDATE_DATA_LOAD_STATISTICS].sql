-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_UPDATE_DATA_LOAD_STATISTICS>
-- Author:      <Chiranjeevi>
-- Create Date: <23-09-2022>
-- Description: <Updating data into ABCR_AUDIT.USP_UPDATE_DATA_LOAD_STATISTICS table>
-- =============================================

CREATE  procedure [ABCR_AUDIT].[USP_UPDATE_DATA_LOAD_STATISTICS]
@BOW_Id int,
@SBOW_Id int,
@UOW_Id bigint,
@Job_Start_Time datetime,
@Job_End_Time datetime,
@ProcessID varchar(500),
@Git_Project_Name varchar(500),
@Job_Name varchar(1000),
@Job_Repository_Id varchar(1000),
@Job_Version varchar(1000),
@Job_Used_Context varchar(500),
@Component_Name varchar(500),
@Stats_Capture_At varchar(500),
@Job_Status varchar(500),
@Job_Execution_Duration bigint,
@Error_Type varchar(500),
@Error_Code int,
@Error_Message nvarchar(max),
@HPSM_Ticket_Status varchar(250)

AS
BEGIN
SET NOCOUNT ON

If @BOW_Id is null OR @SBOW_Id is null OR @UOW_Id is null

	Begin
		THROW 51000, 'Pass BOW_ID, SBOW_ID AND UOW_ID values to update the statement',1
	END

	If Exists
		(Select * from ABCR_AUDIT.VW_DATA_LOAD_STATISTICS WHERE BOW_Id=@BOW_Id AND SBOW_Id=@SBOW_Id AND UOW_Id=@UOW_Id)
		Begin
			Insert into ABCR_AUDIT.DATA_LOAD_STATISTICS_HISTORY Select *,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_AUDIT.VW_DATA_LOAD_STATISTICS 
			WHERE BOW_Id=@BOW_Id AND SBOW_Id=@SBOW_Id AND UOW_Id=@UOW_Id
		END
	   
	    Else 
				Begin
					THROW 51000, 'No entry with @BOW_ID, @SBOW_ID & @UOW_ID',1
				END

		Begin
			Update ABCR_AUDIT.VW_DATA_LOAD_STATISTICS Set BOW_Id=Isnull(@BOW_Id,BOW_Id),SBOW_Id=Isnull(@SBOW_Id,SBOW_Id),UOW_Id=Isnull(@UOW_Id,UOW_Id),Job_Start_Time=Isnull(@Job_Start_Time,Job_Start_Time),
			Job_End_Time=Isnull(@Job_End_Time,Job_End_Time),ProcessID=Isnull(@ProcessID,ProcessID),Git_Project_Name=Isnull(@Git_Project_Name,Git_Project_Name),Job_Name=Isnull(@Job_Name,Job_Name),
			Job_Repository_Id=Isnull(@Job_Repository_Id,Job_Repository_Id),Job_Version=Isnull(@Job_Version,Job_Version),Job_Used_Context=Isnull(@Job_Used_Context,Job_Used_Context),Component_Name=Isnull(@Component_Name,Component_Name),
			Stats_Capture_At=Isnull(@Stats_Capture_At,Stats_Capture_At),Job_Status=Isnull(@Job_Status,Job_Status),Job_Execution_Duration=Isnull(@Job_Execution_Duration,Job_Execution_Duration),Error_Type=Isnull(@Error_Type,Error_Type),
			Error_Code=Isnull(@Error_Code,Error_Code),Error_Message=Isnull(@Error_Message,Error_Message),HPSM_Ticket_Status=Isnull(@HPSM_Ticket_Status,HPSM_Ticket_Status)
			Where BOW_Id=@BOW_Id AND SBOW_Id=@SBOW_Id AND UOW_Id=@UOW_Id
		End

			Begin
				Select * From ABCR_AUDIT.VW_DATA_LOAD_STATISTICS Where BOW_Id=@BOW_Id AND SBOW_Id=@SBOW_Id AND UOW_Id=@UOW_Id
			End

End



