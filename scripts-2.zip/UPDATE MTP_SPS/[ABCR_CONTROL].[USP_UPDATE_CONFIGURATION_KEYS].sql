-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_CONFIGURATION_KEYS>
-- Author:      <Chiranjeevi>
-- Create Date: <14-09-2022>
-- Description: <Updating data into ABCR_CONTROL.USP_CONFIGURATION_KEYS table>
-- =============================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_UPDATE_CONFIGURATION_KEYS]
@Config_ID int,
@Config_Key_Text varchar(900),
@Description_Text varchar(1000),
@IS_Active_Flag char(1),
@Insert_GMT_Timestamp datetime,
@Update_GMT_Timestamp datetime,
@Insert_Maintenance_System_Domain_Account_Name varchar(1000),
@Update_Maintenance_System_Domain_Account_Name varchar (1000)

AS
BEGIN
SET NOCOUNT ON

If Exists
		(Select * from ABCR_CONTROL.VW_Configuration_Keys Where Config_ID=@Config_ID AND Config_Key_Text=@Config_Key_Text)
		Begin
			Insert into ABCR_CONTROL.Configuration_Keys_History Select *,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_Configuration_Keys
			Where Config_ID=@Config_ID AND Config_Key_Text=@Config_Key_Text
		END
			Else 
				Begin
					THROW 51000, 'No entry with passed parameters in configuration keys table',1
				END

		Begin
			Update ABCR_CONTROL.VW_Configuration_Keys Set Config_ID=Isnull(@Config_ID,Config_ID), Config_Key_Text=Isnull(@Config_Key_Text,Config_Key_Text),
			Description_Text=Isnull(@Description_Text,Description_Text), IS_Active_Flag=Isnull(@IS_Active_Flag,IS_Active_Flag), Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),
			@Update_GMT_Timestamp=CURRENT_TIMESTAMP,Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
			@Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER Where Config_ID=@Config_ID AND Config_Key_Text=@Config_Key_Text
		END
			Begin
				Select * from ABCR_CONTROL.VW_Configuration_Keys Where Config_ID=@Config_ID AND Config_Key_Text=@Config_Key_Text
			End
END



