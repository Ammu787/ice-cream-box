CREATE  Procedure [ABCR_CONTROL].[USP_UPDATE_UOW_CONFIGURATION_VALUES]
@Bow_Id Int,
@Sbow_Id Int=0,
@Uow_Id Bigint =0,
@SQL nvarchar (Max)

As 
Begin 

	Select @Bow_Id as BOWID,@Sbow_Id as SBOWID, @Uow_Id as UOWID, 'N' as Stat into #uow_config_values
	Execute sp_executesql @SQL

		if exists(select Stat from #uow_config_values where Stat = 'Y')
		Begin
			Select @SQL = replace(@SQL,'ABCR_CONTROL.VW_UOW_Configuration_Values','ABCR_CONTROL.UOW_Configuration_Values')
			Execute sp_executesql @SQL
		END
END


