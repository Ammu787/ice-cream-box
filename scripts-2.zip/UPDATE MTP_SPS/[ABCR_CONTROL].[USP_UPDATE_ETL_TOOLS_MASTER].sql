-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_ETL_TOOLS_MASTER>
-- Author:      <Chiranjeevi>
-- Create Date: <14-09-2022>
-- Description: <Updating data into ABCR_CONTROL.VW_ETL_TOOLS_MASTER table>
-- =======================================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_UPDATE_ETL_TOOLS_MASTER]
@Tool_ID_Text varchar(20),
@TOOL_NAME varchar(200),
@IS_ACTIVE_FLAG char(1),
@Insert_GMT_Timestamp datetime,
@Update_GMT_Timestamp datetime,
@Insert_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_Maintenance_System_Domain_Account_Name varchar (1000)

AS
BEGIN
SET NOCOUNT ON

If exists 
	(Select * from ABCR_CONTROL.VW_ETL_TOOLS_MASTER Where Tool_ID_Text=@Tool_ID_Text)
		Begin
			Insert into ABCR_CONTROL.ETL_TOOLS_MASTER_HISTORY Select *,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_ETL_TOOLS_MASTER 
			Where Tool_ID_Text=@Tool_ID_Text 
		END
			
	Else 
			Begin
				THROW 51000, 'No entry with passed parameters in ETL_Tools_Master table',1
			END
	Begin
		UPDATE ABCR_CONTROL.VW_ETL_TOOLS_MASTER SET Tool_ID_Text=Isnull(@Tool_ID_Text,Tool_ID_Text),TOOL_NAME=Isnull(@TOOL_NAME,TOOL_NAME),IS_ACTIVE_FLAG=Isnull(@IS_ACTIVE_FLAG,IS_ACTIVE_FLAG),
		Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),Update_GMT_Timestamp=CURRENT_TIMESTAMP,Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
		Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER WHERE Tool_ID_Text=@Tool_ID_Text
	END

		Begin
			Select * from ABCR_CONTROL.VW_ETL_TOOLS_MASTER WHERE Tool_ID_Text=@Tool_ID_Text AND TOOL_NAME=@TOOL_NAME
		End
END



