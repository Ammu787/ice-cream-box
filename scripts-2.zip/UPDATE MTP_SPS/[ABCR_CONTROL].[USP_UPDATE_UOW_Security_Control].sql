-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_UOW_Security_Control>
-- Author:      <Chiranjeevi>
-- Create Date: <08-09-2022>
-- Description: <Updating data into ABCR_CONTROL.USP_UOW_Security_Control>
-- =======================================================

CREATE  Procedure [ABCR_CONTROL].[USP_UPDATE_UOW_Security_Control]
@Tenant_ID int,
@BOW_ID int,
@SBOW_ID int,
@UOW_ID Bigint,
@SEC_TYPE Varchar(50),
@Role varchar(50),
@Columns varchar(max),
@is_encrypted char(1),
@location char(15),
@Path varchar(250),
@Inserted_By_Name varchar(100),
@Inserted_DateTime datetime2,
@Updated_By_Name varchar(100),
@updated_DateTime datetime2

As 
Begin 
SET NOCOUNT On

If @Tenant_ID Is null OR @BOW_ID is null OR @SBOW_ID is null OR @UOW_ID is null

	Begin
		THROW 51000, 'Pass Tenant_ID, BOW_ID, SBOW_ID AND UOW_ID values to update the statement',1
	END

	If Exists
		(Select * from ABCR_CONTROL.VW_UOW_Security_Control WHERE Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID)
		Begin
			Insert into ABCR_CONTROL.UOW_Security_Control_History Select *,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.UOW_Security_Control 
			Where Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		END
			Else 
				Begin
					THROW 51000, 'No entry with @Tenant_ID, @BOW_ID, @SBOW_ID & @UOW_ID',1
				END
	Begin
		UPDATE ABCR_CONTROL.VW_UOW_Security_Control Set Tenant_ID=Isnull(@Tenant_ID,Tenant_ID),BOW_ID=Isnull(@BOW_ID,BOW_ID),SBOW_ID=Isnull(@SBOW_ID,SBOW_ID),UOW_ID=Isnull(@UOW_ID,UOW_ID),
		[SEC_TYPE]=Isnull(@SEC_TYPE,SEC_TYPE),Role=Isnull(@Role,Role),Columns=Isnull(@Columns,Columns),is_encrypted=Isnull(@is_encrypted,is_encrypted),location=Isnull(@location,location),
		Path=Isnull(@Path,Path),Inserted_By_Name=Isnull(@Inserted_By_Name,Inserted_By_Name),Inserted_DateTime=Isnull(@Inserted_DateTime,Inserted_DateTime),Updated_By_Name=SYSTEM_USER,updated_DateTime=CURRENT_TIMESTAMP
		Where Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
	End

		Begin
			Select * from ABCR_CONTROL.VW_UOW_Security_Control Where Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		End
End



