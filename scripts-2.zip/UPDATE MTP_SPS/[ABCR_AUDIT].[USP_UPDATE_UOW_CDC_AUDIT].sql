-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_UPDATE_UOW_CDC_AUDIT>
-- Author:      <Chiranjeevi>
-- Create Date: <14-09-2022>
-- Description: <Updating data into ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL_R01 table>
-- =======================================================

CREATE Procedure [ABCR_AUDIT].[USP_UPDATE_UOW_CDC_AUDIT]
@Tenant_Id int,
@Bow_Id int,
@Sbow_Id Int=0,
@Uow_Id Bigint =0,
@SQL nvarchar (Max)

As 
Begin 

	Select @Tenant_Id as Tenant, @Bow_Id as BOWID,@Sbow_Id as SBOWID, @Uow_Id as UOWID, 'N' as Stat into #cdc
	Execute sp_executesql @SQL
	Set @SQL=UPPER(@SQL)
		if exists(select Stat from #cdc where Stat = 'Y')
		Begin
			Select @SQL = replace(@SQL,'ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL','ABCR_AUDIT.BOW_CDC_AUX_CONTROL_R01')
			
			Execute sp_executesql @SQL
		END
END



