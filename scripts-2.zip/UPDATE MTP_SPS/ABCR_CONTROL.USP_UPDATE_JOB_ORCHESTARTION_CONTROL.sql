-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_JOB_ORCHESTARTION_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <14-09-2022>
-- Description: <Updating data into ABCR_CONTROL.VW_JOB_ORCHESTARTION_CONTROL table>
-- =======================================================

Create   Procedure ABCR_CONTROL.USP_UPDATE_JOB_ORCHESTARTION_CONTROL

@Job_Id int,
@Tenant_Id int,
@Bow_Id int,
@Sbow_Id Int=0,
@Uow_Id Bigint =0,
@SQL nvarchar (Max)

As 
Begin 

	Select @Job_Id as JobID,@Tenant_Id as Tenant, @Bow_Id as BOWID,@Sbow_Id as SBOWID, @Uow_Id as UOWID, 'N' as Stat into #job_orche_control
	Execute sp_executesql @SQL

		if exists(select Stat from #job_orche_control where Stat = 'Y')
		Begin
			Select @SQL = replace(@SQL,'ABCR_CONTROL.VW_Job_orchestration_control','ABCR_CONTROL.Job_orchestration_control')
			Execute sp_executesql @SQL
		END
END