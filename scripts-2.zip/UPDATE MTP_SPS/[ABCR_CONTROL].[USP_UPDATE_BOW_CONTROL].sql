-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_BOW_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <08-09-2022>
-- Description: <Updating data into ABCR_CONTROL.VW_BOW_CONTROL table>
-- =============================================

CREATE procedure [ABCR_CONTROL].[USP_UPDATE_BOW_CONTROL]
@TENANT_ID INT,
@BOW_ID INT,
@BOW_NAME VARCHAR(1000),
@SRC_SYSTEM_ID VARCHAR(50),
@EMAIL	VARCHAR(1000),
@IS_ACTIVE_FLAG CHAR(1),
@BOW_Source_Description_TEXT	VARCHAR(500),
@Insert_GMT_Timestamp DATETIME2,
@severity_number INT,
@raise_ticket_flag TINYINT,
@impact_number INT,
@Insert_Maintenance_System_Domain_Account_Name VARCHAR(1000),
@Update_Maintenance_System_Domain_Account_Name VARCHAR(1000),
@Update_GMT_Timestamp DATETIME,
@BOW_CODE VARCHAR(10)

AS
BEGIN
SET NOCOUNT ON

If @TENANT_ID Is null OR @BOW_ID is null
	Begin
		THROW 51000, 'Pass Tenant_ID AND BOW_ID values to update the statement',1
	END

	If Exists
		(Select * from ABCR_CONTROL.VW_BOW_CONTROL WHERE TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID)
		Begin
			Insert into ABCR_CONTROL.BOW_CONTROL_HISTORY Select TENANT_ID,BOW_ID,BOW_NAME,SRC_SYSTEM_ID,EMAIL,IS_ACTIVE_FLAG,BOW_Source_Description_TEXT,Insert_GMT_Timestamp,
			severity_number,raise_ticket_flag,impact_number,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,BOW_CODE,
			SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_BOW_CONTROL Where TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID
		END
		
		Else 
				Begin
					THROW 51000, 'No entry with @Tenant_ID & @BOW_ID ',1
				END
	   
		Begin
			Update ABCR_CONTROL.VW_BOW_CONTROL Set TENANT_ID=ISnull(@TENANT_ID,TENANT_ID), BOW_ID=Isnull(@BOW_ID,BOW_ID),BOW_NAME=Isnull(@BOW_NAME,BOW_NAME),
			SRC_SYSTEM_ID=Isnull(@SRC_SYSTEM_ID,SRC_SYSTEM_ID), EMAIL=Isnull(@EMAIL,EMAIL), IS_ACTIVE_FLAG=Isnull(@IS_ACTIVE_FLAG,IS_ACTIVE_FLAG), 
			BOW_Source_Description_TEXT=Isnull(@BOW_Source_Description_TEXT,BOW_Source_Description_TEXT), Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),
			severity_number=Isnull(@severity_number,severity_number),raise_ticket_flag=Isnull(@raise_ticket_flag,raise_ticket_flag),impact_number=Isnull(@impact_number,impact_number),
			Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,
			Update_GMT_Timestamp=CURRENT_TIMESTAMP,BOW_CODE=Isnull(@BOW_CODE,BOW_CODE) Where TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID
		END

			Begin
				Select * from ABCR_CONTROL.VW_BOW_CONTROL WHere TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID
			END
END



