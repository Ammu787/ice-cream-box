-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_ADF_PIPELINE_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <14-09-2022>
-- Description: <Updating data into ABCR_CONTROL.VW_ADF_PIPELINE_CONTROL table>
-- =======================================================

CREATE Procedure [ABCR_CONTROL].[USP_UPDATE_ADF_PIPELINE_CONTROL]

@Job_Id int,
@SQL nvarchar (Max)

As 
Begin 

	Select @Job_Id as JOBID, 'N' as Stat into #adf_pipeline_control
	Execute sp_executesql @SQL
		
		if exists(select Stat from #adf_pipeline_control where Stat = 'Y')
		Begin
			Select @SQL = replace(@SQL,'ABCR_CONTROL.VW_adf_pipeline_control','ABCR_CONTROL.adf_pipeline_control')
			Execute sp_executesql @SQL
		END
END



