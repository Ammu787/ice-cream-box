-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_TENANT_MASTER_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <08-09-2022>
-- Description: <Updating data into ABCR_CONTROL.VW_TENANT_MASTER_CONTROL table>
-- =============================================
CREATE  procedure [ABCR_CONTROL].[USP_UPDATE_TENANT_MASTER_CONTROL]
@Tenant_ID Int,
@Tenant_Code char(10) NULL,
@Tenant_Name_Text varchar(1000),
@Tech_Lead_Text	varchar(1000),
@Tech_Manager_Text varchar(1000),
@Support_Team_Text varchar(1000),
@Project_Description_Text varchar (1000),
@Tenancy_Start_Date datetime,
@Tenancy_End_Date datetime,
@Is_Active_Flag char(1),
@Insert_GMT_Timestamp datetime,
@Insert_Maintenance_System_Domain_Account_Name varchar(1000)


AS
BEGIN
SET NOCOUNT ON

If @Tenant_ID is null
	Begin
		THROW 51000, 'Pass Tenant_ID value to update the statement',1
	END

	If Exists
		(Select * from ABCR_CONTROL.VW_TENANT_MASTER_CONTROL WHERE Tenant_ID=@Tenant_ID)
		Begin
			Insert into ABCR_CONTROL.TENANT_MASTER_CONTROL_HISTORY Select *,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_TENANT_MASTER_CONTROL WHERE Tenant_ID=@Tenant_ID
		END

		Else
			Begin
				THROW 51000, 'No entry with @Tenant_ID ',1
			END
	   
		Begin
			Update ABCR_CONTROL.VW_TENANT_MASTER_CONTROL SET Tenant_ID =isnull(@Tenant_ID,Tenant_ID), Tenant_Code =Isnull(@Tenant_Code,Tenant_Code),Tenant_Name_Text=Isnull(@Tenant_Name_Text,Tenant_Name_Text),
			Tech_Lead_Text=Isnull(@Tech_Lead_Text,Tech_Lead_Text), Tech_Manager_Text=Isnull(@Tech_Manager_Text,Tech_Manager_Text), Support_Team_Text=Isnull(@Support_Team_Text,Support_Team_Text),
			Project_Description_Text=Isnull(@Project_Description_Text,Project_Description_Text),Tenancy_Start_Date=Isnull(@Tenancy_Start_Date,Tenancy_Start_Date),Tenancy_End_Date=Isnull(@Tenancy_End_Date,Tenancy_End_Date),
			Is_Active_Flag=ISNULL(@Is_Active_Flag,Is_Active_Flag),Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
			Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,Update_GMT_Timestamp=CURRENT_TIMESTAMP Where Tenant_ID=@Tenant_ID
		END
				
			Begin
				Select * from ABCR_CONTROL.VW_TENANT_MASTER_CONTROL Where Tenant_ID=@Tenant_ID
			END
END



