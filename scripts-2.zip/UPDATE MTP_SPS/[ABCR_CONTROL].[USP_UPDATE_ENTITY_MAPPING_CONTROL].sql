CREATE  Procedure [ABCR_CONTROL].[USP_UPDATE_ENTITY_MAPPING_CONTROL]
@Tenant_Id int,
@Bow_Id int,
@Sbow_Id Int=0,
@Uow_Id Bigint =0,
@SQL nvarchar (Max)

As 
Begin 

	Select @Tenant_Id as Tenant, @Bow_Id as BOWID,@Sbow_Id as SBOWID, @Uow_Id as UOWID, 'N' as Stat into #entity_mapping_control
	Execute sp_executesql @SQL

		if exists(select Stat from #entity_mapping_control where Stat = 'Y')
		Begin
			Select @SQL = replace(@SQL,'ABCR_CONTROL.VW_Entity_Mapping_Control','ABCR_CONTROL.Entity_Mapping_Control')
			Execute sp_executesql @SQL
		END
END



