-- =======================================================
-- Create TRIGGER Template for <ABCR_CONTROL>.<Instead_of_Job_Orchestration_Control_Update>
-- Author:      <Chiranjeevi>
-- Create Date: <07-09-2022>
-- Description: <Adding update trigger on ABCR_CONTROL.VW_Job_orchestration_control>
-- =======================================================

CREATE TRIGGER ABCR_CONTROL.Instead_of_Job_Orchestration_Control_Update ON ABCR_CONTROL.VW_Job_orchestration_control
	instead of update  
AS 
	declare @cnt_jobid int
	declare @cnt_tenantid int
	declare @cnt_bowid int
	declare @cnt_sbowid int 
	declare @cnt_uowid Bigint
		
	set @cnt_jobid=0
	select @cnt_jobid = count(JOB_ID) from inserted where JOB_ID not in (select JobID from #job_orche_control)
	
	if (isnull(@cnt_jobid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 Jobid affected',16,1)
		end

	set @cnt_tenantid=0
	select @cnt_tenantid = count(TENANT_ID) from inserted where TENANT_ID not in (select Tenant from #job_orche_control)
	
	if (isnull(@cnt_tenantid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 Tenant affected',16,1)
		end
	
	set @cnt_bowid=0
	select @cnt_bowid = count(BOW_ID) from inserted where BOW_ID not in (select BOWID from #job_orche_control)
	
	if (isnull(@cnt_bowid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 BOW affected',16,1)
		end
	
	if exists(select 1 from #job_orche_control where SBOWID > 0)
	begin
		set @cnt_sbowid =0
		select @cnt_sbowid = count(SBOW_ID) from inserted where SBOW_ID not in (select SBOWID from #job_orche_control)
		if (isnull(@cnt_sbowid,0)) > 0
			begin
				raiserror('Invalid Operation. More than 1 SBOW affected',16,1)
			end
	end
	
	if exists(select 1 from #job_orche_control where UOWID > 0)
	begin
		set @cnt_uowid =0
		select @cnt_uowid = count(UOW_ID) from inserted where UOW_ID not in (select UOWID from #job_orche_control)
		if (isnull(@cnt_uowid,0)) > 0
		begin
			raiserror('Invalid Operation. More than 1 UOW affected',16,1)
		end
	end
	
	else
	
	begin
		insert into ABCR_CONTROL.Job_orchestration_control_History select JOB_ID,TENANT_ID,BOW_ID,SBOW_ID,UOW_ID,Seq_ID,IS_Active_Flag,Insert_Maintenance_System_Domain_Account_Name,Insert_GMT_Timestamp,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,Wait_Time_In_Min,Job_Params,SYSTEM_USER,CURRENT_TIMESTAMP from deleted
	
		update #job_orche_control set Stat = 'Y'
	end