
CREATE   TRIGGER ABCR_CONTROL.Instead_of_UOW_Configuration_Values_Update ON ABCR_CONTROL.VW_UOW_Configuration_Values
	instead of update  
AS 
	declare @cnt_bowid int
	declare @cnt_sbowid int 
	declare @cnt_uowid bigint

	set @cnt_bowid=0
	select @cnt_bowid = count(BOW_ID) from inserted where BOW_ID not in (select BOWID from #uow_config_values)
	
	if (isnull(@cnt_bowid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 BOW affected',16,1)
		end

	if exists(select 1 from #uow_config_values where SBOWID > 0)
	begin
		set @cnt_sbowid =0
		select @cnt_sbowid = count(SBOW_ID) from inserted where SBOW_ID not in (select SBOWID from #uow_config_values)
		if (isnull(@cnt_sbowid,0)) > 0
			begin
				raiserror('Invalid Operation. More than 1 SBOW affected',16,1)
			end
	end

	if exists(select 1 from #uow_config_values where UOWID > 0)
	begin
		set @cnt_uowid =0
		select @cnt_uowid = count(UOW_ID) from inserted where UOW_ID not in (select UOWID from #uow_config_values)
		if (isnull(@cnt_uowid,0)) > 0
		begin
			raiserror('Invalid Operation. More than 1 UOW affected',16,1)
		end
	end
	
	else
	
	begin
		insert into ABCR_CONTROL.UOW_Configuration_Values_History select *,SYSTEM_USER,CURRENT_TIMESTAMP from deleted
	
		update #uow_config_values set Stat = 'Y'
	end
	