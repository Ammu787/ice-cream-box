
CREATE   TRIGGER ABCR_CONTROL.Instead_of_Job_Orch_Master_Update ON ABCR_CONTROL.VW_job_orchestration_master
	instead of update  
AS 
	declare @cnt_tenantid int
	declare @cnt_jobid int
	
	set @cnt_tenantid=0
	select @cnt_tenantid = count(TENANT_ID) from inserted where TENANT_ID not in (select Tenant from #job_orch_master)
	
	if (isnull(@cnt_tenantid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 Tenant affected',16,1)
		end
	/*
	set @cnt_jobid=0
	select @cnt_jobid = count(JOB_ID) from inserted where JOB_ID not in (select JOBID from #job_orch_master)
	
	if (isnull(@cnt_jobid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 Job affected',16,1)
		end */
	if exists(select 1 from #job_orch_master where JOBID > 0)
	begin
		set @cnt_jobid =0
		select @cnt_jobid = count(JOB_ID) from inserted where JOB_ID not in (select JOBID from #job_orch_master)
		if (isnull(@cnt_jobid,0)) > 0
		begin
			raiserror('Invalid Operation. More than 1 JOBID affected',16,1)
		end
	end
	
	else
	
	begin
		insert into ABCR_CONTROL.job_orchestration_master_history select *,SYSTEM_USER,CURRENT_TIMESTAMP from deleted
		update #job_orch_master set Stat = 'Y'
	end