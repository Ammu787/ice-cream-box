
CREATE   TRIGGER ABCR_CONTROL.Instead_of_Job_Configuration_Values_Update ON ABCR_CONTROL.VW_job_configuration_values
	instead of update  
AS 
	declare @cnt_jobid int
			
	set @cnt_jobid=0
	select @cnt_jobid = count(JobId) from inserted where JobId not in (select Jobid from #job_config_values)
	
	if (isnull(@cnt_jobid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 Jobid affected',16,1)
		end

	else
	
	begin
		insert into ABCR_CONTROL.job_configuration_values_history select *,SYSTEM_USER,CURRENT_TIMESTAMP from deleted
	
		update #job_config_values set Stat = 'Y'
	end