CREATE   TRIGGER ABCR_CONTROL.Instead_of_Process_Control_Update ON ABCR_CONTROL.VW_Process_Control
	instead of update  
AS 
	declare @cnt_tenantid int
	declare @cnt_bowid int
	declare @cnt_sbowid int 
	declare @cnt_uowid bigint
		
	set @cnt_tenantid=0
	select @cnt_tenantid = count(Tenant_ID) from inserted where Tenant_ID not in (select Tenant from #process_control)
	
	if (isnull(@cnt_tenantid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 Tenant affected',16,1)
		end
	
	set @cnt_bowid=0
	select @cnt_bowid = count(BOW_ID) from inserted where BOW_ID not in (select BOWID from #process_control)
	
	if (isnull(@cnt_bowid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 BOW affected',16,1)
		end
	
	if exists(select 1 from #process_control where SBOWID > 0)
	begin
		set @cnt_sbowid =0
		select @cnt_sbowid = count(SBOW_ID) from inserted where SBOW_ID not in (select SBOWID from #process_control)
		if (isnull(@cnt_sbowid,0)) > 0
			begin
				raiserror('Invalid Operation. More than 1 SBOW affected',16,1)
			end
	end
	
	if exists(select 1 from #process_control where UOWID > 0)
	begin
		set @cnt_uowid =0
		select @cnt_uowid = count(UOW_ID) from inserted where UOW_ID not in (select UOWID from #process_control)
		if (isnull(@cnt_uowid,0)) > 0
		begin
			raiserror('Invalid Operation. More than 1 UOW affected',16,1)
		end
	end
	
	else
	
	begin
		insert into ABCR_CONTROL.Process_Control_History select *,SYSTEM_USER,CURRENT_TIMESTAMP from deleted
	
		update #process_control set Stat = 'Y'
	end
	