-- =======================================================
-- Create TRIGGER Template for <ABCR_CONTROL>.<Instead_of_Adf_Pipeline_Control>
-- Author:      <Chiranjeevi>
-- Create Date: <07-09-2022>
-- Description: <Assigning update trigger on ABCR_CONTROL.Adf_Pipeline_Control>
-- =============================================


CREATE   TRIGGER ABCR_CONTROL.Instead_of_Adf_Pipeline_Control_Update ON ABCR_CONTROL.VW_adf_pipeline_control
	instead of update  
AS 
	declare @cnt_jobid int
			
	set @cnt_jobid=0
	select @cnt_jobid = count(JOB_ID) from inserted where JOB_ID not in (select Jobid from #adf_pipeline_control)
	
	if (isnull(@cnt_jobid,0)) > 0
		begin
			raiserror('Invalid Query. More than 1 Jobid affected',16,1)
		end

	else
	
	begin
		insert into ABCR_CONTROL.adf_pipeline_control_history select *,SYSTEM_USER,CURRENT_TIMESTAMP from deleted
	
		update #adf_pipeline_control set Stat = 'Y'
	end
	