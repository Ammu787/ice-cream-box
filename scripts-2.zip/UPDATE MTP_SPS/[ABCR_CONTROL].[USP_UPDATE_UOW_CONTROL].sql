-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_UOW_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <07-09-2022>
-- Description: <Updating data into ABCR_CONTROL.VW_UOW_CONTROL table>
-- =============================================

CREATE procedure [ABCR_CONTROL].[USP_UPDATE_UOW_CONTROL]
@TENANT_ID int,
@BOW_ID int,
@SBOW_ID int,
@UOW_ID bigint,
@UOW_NAME varchar (1000),
@IS_ACTIVE_FLAG char(1),
@UOW_Description varchar (1000),
@retry_on_error_flag char (1),
@severity_number int,
@raise_ticket_flag int,
@impact_number int,
@Is_Reprocess_Flag char (1),
@Insert_GMT_Timestamp datetime,
@Insert_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_GMT_Timestamp datetime,
@UOW_CODE varchar(20)

AS
BEGIN
SET NOCOUNT ON

If @TENANT_ID Is null OR @BOW_ID is null OR @SBOW_ID is null OR @UOW_ID is null

	Begin
		THROW 51000, 'Pass Tenant_ID, BOW_ID, SBOW_ID AND UOW_ID values to update the statement',1
	END
	
	If Exists
		(Select * from ABCR_CONTROL.VW_UOW_CONTROL WHERE TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID)
		Begin
			Insert into ABCR_CONTROL.UOW_CONTROL_HISTORY Select TENANT_ID,BOW_ID,SBOW_ID,UOW_ID,UOW_NAME,IS_ACTIVE_FLAG,UOW_Description,retry_on_error_flag,severity_number,
			raise_ticket_flag,impact_number,Is_Reprocess_Flag,Insert_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,
			UOW_CODE,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_UOW_CONTROL Where TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		END
		
			Else 
				Begin
					THROW 51000, 'No entry with @Tenant_ID, @BOW_ID, @SBOW_ID & @UOW_ID',1
				END

	   
		Begin
			Update ABCR_CONTROL.VW_UOW_CONTROL Set TENANT_ID=Isnull(@TENANT_ID,TENANT_ID),BOW_ID=Isnull(@BOW_ID,BOW_ID), SBOW_ID=Isnull(@SBOW_ID,BOW_ID),UOW_ID=Isnull(@UOW_ID,UOW_ID),
			UOW_NAME=Isnull(@UOW_NAME,UOW_NAME),IS_ACTIVE_FLAG=Isnull(@IS_ACTIVE_FLAG,IS_ACTIVE_FLAG),UOW_Description=Isnull(@UOW_Description,UOW_Description),retry_on_error_flag=Isnull(@retry_on_error_flag,retry_on_error_flag),
			severity_number=Isnull(@severity_number,severity_number),raise_ticket_flag=Isnull(@raise_ticket_flag,raise_ticket_flag),impact_number=Isnull(@impact_number,impact_number),
			Is_Reprocess_Flag=Isnull(@Is_Reprocess_Flag,Is_Reprocess_Flag),Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
			Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,Update_GMT_Timestamp=CURRENT_TIMESTAMP, UOW_CODE=Isnull(@UOW_CODE,UOW_CODE)
			Where TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		End

			Begin
				Select * From ABCR_CONTROL.VW_UOW_CONTROL Where TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
			End

End



