-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_SBOW_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <08-09-2022>
-- Description: <Inserting data into ABCR_CONTROL.VW_SBOW_CONTROL table>
-- =============================================

CREATE procedure [ABCR_CONTROL].[USP_UPDATE_SBOW_CONTROL]
@TENANT_ID int,
@BOW_ID int,
@SBOW_ID int,
@LAYER_CODE char(3),
@SBOW_NAME varchar(1000),
@CDC_START_TIMESTAMP datetime,		
@CDC_END_TIMESTAMP	datetime,
@EMAIL varchar (1000),
@IS_ACTIVE_FLAG char(1),
@SEQUENCE_ID int,
@SBOW_DESCRIPTION varchar (1000),
@Insert_GMT_Timestamp DATETIME2,
@Insert_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_GMT_Timestamp DATETIME2,
@SBOW_CODE varchar (10)

AS
BEGIN
SET NOCOUNT ON

If @TENANT_ID Is null OR @BOW_ID is null OR @SBOW_ID is null
	Begin
		THROW 51000, 'Pass Tenant_ID, BOW_ID AND SBOW_ID values to update the statement',1
	END

	If Exists
		(Select * from ABCR_CONTROL.VW_SBOW_CONTROL WHERE TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID)
			Begin
				Insert into ABCR_CONTROL.SBOW_CONTROL_HISTORY Select TENANT_ID,BOW_ID,SBOW_ID,LAYER_CODE,SBOW_NAME,CDC_START_TIMESTAMP,CDC_END_TIMESTAMP,EMAIL,IS_ACTIVE_FLAG,
				SEQUENCE_ID,SBOW_DESCRIPTION,Insert_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,
				SBOW_CODE,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_SBOW_CONTROL Where TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID
			END
		Else 
			Begin
				THROW 51000, 'No entry with @Tenant_ID, @BOW_ID & @SBOW_ID',1
			END
	   
		Begin
			Update ABCR_CONTROL.VW_SBOW_CONTROL Set TENANT_ID=Isnull(@TENANT_ID,TENANT_ID), BOW_ID=Isnull(@BOW_ID,BOW_ID), SBOW_ID= Isnull(@SBOW_ID,SBOW_ID),
			LAYER_CODE=Isnull(@LAYER_CODE,LAYER_CODE),SBOW_NAME=Isnull(@SBOW_NAME,SBOW_NAME),CDC_START_TIMESTAMP=Isnull(@CDC_START_TIMESTAMP,CDC_START_TIMESTAMP),
			CDC_END_TIMESTAMP=Isnull(@CDC_END_TIMESTAMP,CDC_END_TIMESTAMP),EMAIL=Isnull(@EMAIL,EMAIL),IS_ACTIVE_FLAG=Isnull(@IS_ACTIVE_FLAG,IS_ACTIVE_FLAG),
			SEQUENCE_ID=Isnull(@SEQUENCE_ID,SEQUENCE_ID),SBOW_DESCRIPTION=Isnull(@SBOW_DESCRIPTION,SBOW_DESCRIPTION),Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),
			Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
			Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,Update_GMT_Timestamp=CURRENT_TIMESTAMP,SBOW_CODE=Isnull(@SBOW_CODE,SBOW_CODE)
			Where TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID
		End

			Begin
				Select * From ABCR_CONTROL.VW_SBOW_CONTROL Where TENANT_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID
			End

End


