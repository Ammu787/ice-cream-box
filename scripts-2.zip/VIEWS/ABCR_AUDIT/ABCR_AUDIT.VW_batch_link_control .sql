Create   View ABCR_AUDIT.VW_batch_link_control AS
Select * from ABCR_AUDIT.batch_link_control