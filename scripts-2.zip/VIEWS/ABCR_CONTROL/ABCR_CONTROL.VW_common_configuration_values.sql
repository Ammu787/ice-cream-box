Create   View ABCR_CONTROL.VW_common_configuration_values AS
Select * from ABCR_CONTROL.common_configuration_values