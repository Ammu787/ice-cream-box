Create   View ABCR_CONTROL.VW_Process_Control AS
Select * FROM ABCR_CONTROL.Process_Control