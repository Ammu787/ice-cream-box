Create   View ABCR_CONTROL.VW_adf_pipeline_control AS
Select * from ABCR_CONTROL.adf_pipeline_control