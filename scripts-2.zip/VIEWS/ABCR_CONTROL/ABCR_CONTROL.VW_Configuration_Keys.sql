
Create   View ABCR_CONTROL.VW_Configuration_Keys AS
Select * from ABCR_CONTROL.Configuration_Keys