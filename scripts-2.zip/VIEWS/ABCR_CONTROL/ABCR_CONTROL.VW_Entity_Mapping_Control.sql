Create   View ABCR_CONTROL.VW_Entity_Mapping_Control AS
Select * from ABCR_CONTROL.Entity_Mapping_Control