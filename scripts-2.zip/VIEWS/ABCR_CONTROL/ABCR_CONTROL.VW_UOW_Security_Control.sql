
Create   View ABCR_CONTROL.VW_UOW_Security_Control AS
Select * from ABCR_CONTROL.UOW_Security_Control
