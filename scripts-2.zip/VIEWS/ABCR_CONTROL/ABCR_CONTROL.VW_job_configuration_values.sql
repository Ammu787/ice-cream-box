Create   View ABCR_CONTROL.VW_job_configuration_values AS
Select * from ABCR_CONTROL.job_configuration_values