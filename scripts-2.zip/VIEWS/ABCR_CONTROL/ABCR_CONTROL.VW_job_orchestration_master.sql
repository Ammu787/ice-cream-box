Create   View ABCR_CONTROL.VW_job_orchestration_master AS
Select *, Cast(Right(Cast(JOB_ID as Varchar),6)as Int) as JOB_PART_ID from ABCR_CONTROL.job_orchestration_master