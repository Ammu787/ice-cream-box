
Create   View ABCR_CONTROL.VW_UOW_Configuration_Values AS
Select * from ABCR_CONTROL.UOW_Configuration_Values
