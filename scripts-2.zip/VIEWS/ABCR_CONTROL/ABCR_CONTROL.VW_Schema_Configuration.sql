Create   View ABCR_CONTROL.VW_Schema_Configuration AS
Select * from ABCR_CONTROL.Schema_Configuration
