CREATE TABLE ABCR_CONTROL.SBOW_CONTROL 
(
    TENANT_ID                                     INT            NULL,
    BOW_ID                                        INT            NULL,
    SBOW_ID                                       INT            NOT NULL,
    LAYER_CODE                                    VARCHAR (5)    NULL,
    SBOW_NAME                                     VARCHAR (1000) NULL,
    CDC_START_TIMESTAMP                           DATETIME       NULL,
    CDC_END_TIMESTAMP                             DATETIME       NULL,
    EMAIL                                         VARCHAR (1000) NULL,
    IS_ACTIVE_FLAG                                CHAR (1)       NULL,
    SEQUENCE_ID                                   INT            NULL,
    SBOW_DESCRIPTION                              VARCHAR (1000) NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_GMT_Timestamp                          DATETIME2 (7)  NULL,
    SBOW_CODE                                     VARCHAR (10)   NULL,
    PRIMARY KEY CLUSTERED (SBOW_ID ASC),
    CONSTRAINT FK_SBOW_CONTROL_BOW_ID FOREIGN KEY (BOW_ID) REFERENCES ABCR_CONTROL.BOW_CONTROL (BOW_ID),
    CONSTRAINT FK_SBOW_CONTROL_TENANT_ID FOREIGN KEY (TENANT_ID) REFERENCES ABCR_CONTROL.TENANT_MASTER_CONTROL (Tenant_ID)
);