CREATE TABLE ABCR_CONTROL.Schema_Configuration 
(
    Tenant_ID                                     INT           NULL,
    Schema_name                                   VARCHAR (200) NULL,
    Insert_GMT_Timestamp                          DATETIME      NULL,
    Update_GMT_Timestamp                          DATETIME      NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (200) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (200) NULL,
    CONSTRAINT FK_SCHEMA_CONFIGURATION_TENANT_ID FOREIGN KEY (Tenant_ID) REFERENCES ABCR_CONTROL.TENANT_MASTER_CONTROL (Tenant_ID)
);