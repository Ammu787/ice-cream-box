CREATE TABLE ABCR_CONTROL.job_orchestration_master 
(
    TENANT_ID                                     INT           NULL,
    JOB_ID                                        INT           NOT NULL,
    Job_Name_Text                                 VARCHAR (200) NULL,
    Job_Description_Text                          VARCHAR (200) NULL,
    IS_Active_Flag                                CHAR (1)      NULL,
    JOB_EXECUTION_TIME                            DATETIME      NULL,
    INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME VARCHAR (200) NULL,
    INSERT_GMT_TIMESTAMP                          DATETIME      NULL,
    UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME VARCHAR (200) NULL,
    UPDATE_GMT_TIMESTAMP                          DATETIME      NULL,
    Spark_Cluster_Size_Text                       VARCHAR (100) NULL,
    Tool_ID_Text                                  VARCHAR (20)  NULL,
    PRIMARY KEY CLUSTERED (JOB_ID ASC),
    CONSTRAINT FK_JOB_ORCH_MASTER_TENANT_ID FOREIGN KEY (TENANT_ID) REFERENCES ABCR_CONTROL.TENANT_MASTER_CONTROL (Tenant_ID),
    CONSTRAINT FK_JOB_ORCH_MASTER_TOOL_ID_TEXT FOREIGN KEY (Tool_ID_Text) REFERENCES ABCR_CONTROL.ETL_TOOLS_MASTER (Tool_ID_Text)
);