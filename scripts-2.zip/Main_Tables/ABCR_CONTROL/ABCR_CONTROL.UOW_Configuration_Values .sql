CREATE TABLE ABCR_CONTROL.UOW_Configuration_Values 
(
    BOW_ID                                        INT            NULL,
    SBOW_ID                                       INT            NULL,
    UOW_ID                                        BIGINT         NULL,
    Config_Key_Text                               VARCHAR (900)  NULL,
    Config_Value_Text                             VARCHAR (4000) NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    CONSTRAINT FK_UOW_CONFIG_VALUES_BOW_ID FOREIGN KEY (BOW_ID) REFERENCES ABCR_CONTROL.BOW_CONTROL (BOW_ID),
    CONSTRAINT FK_UOW_CONFIG_VALUES_CONFIG_KEY_TEXT FOREIGN KEY (Config_Key_Text) REFERENCES ABCR_CONTROL.Configuration_Keys (Config_Key_Text),
    CONSTRAINT FK_UOW_CONFIG_VALUES_SBOW_ID FOREIGN KEY (SBOW_ID) REFERENCES ABCR_CONTROL.SBOW_CONTROL (SBOW_ID),
    CONSTRAINT FK_UOW_CONFIG_VALUES_UOW_ID FOREIGN KEY (UOW_ID) REFERENCES ABCR_CONTROL.UOW_CONTROL (UOW_ID)
);
