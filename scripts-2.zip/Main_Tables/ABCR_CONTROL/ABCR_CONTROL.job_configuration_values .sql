
CREATE TABLE ABCR_CONTROL.job_configuration_values 
(
    JobId                                         INT            NULL,
    Config_Key_Text                               VARCHAR (900)  NULL,
    Config_Value_Text                             VARCHAR (1000) NULL,
    Description_Text                              VARCHAR (1000) NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    CONSTRAINT FK_JOB_CONFIG_VALUES_CONFIG_KEY_TEXT FOREIGN KEY (Config_Key_Text) REFERENCES ABCR_CONTROL.Configuration_Keys (Config_Key_Text),
    CONSTRAINT FK_JOB_CONFIG_VALUES_JOB_ID FOREIGN KEY (JobId) REFERENCES ABCR_CONTROL.job_orchestration_master (JOB_ID)
);
