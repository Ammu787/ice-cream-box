CREATE TABLE ABCR_CONTROL.TENANT_MASTER_CONTROL 
(
    Tenant_ID                                     INT            NOT NULL,
    Tenant_Code                                   CHAR (10)      NULL,
    Tenant_Name_Text                              VARCHAR (1000) NULL,
    Tech_Lead_Text                                VARCHAR (1000) NULL,
    Tech_Manager_Text                             VARCHAR (1000) NULL,
    Support_Team_Text                             VARCHAR (1000) NULL,
    Project_Description_Text                      VARCHAR (1000) NULL,
    Tenancy_Start_Date                            DATETIME       NULL,
    Tenancy_End_Date                              DATETIME       NULL,
    Is_Active_Flag                                CHAR (1)       NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    PRIMARY KEY CLUSTERED (Tenant_ID ASC),
    UNIQUE NONCLUSTERED (Tenant_Code ASC)
);