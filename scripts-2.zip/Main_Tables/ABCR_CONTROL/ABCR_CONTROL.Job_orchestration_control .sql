CREATE TABLE ABCR_CONTROL.Job_orchestration_control 
(
    JOB_ID                                        INT            NOT NULL,
    TENANT_ID                                     INT            NOT NULL,
    BOW_ID                                        INT            NOT NULL,
    SBOW_ID                                       INT            NOT NULL,
    UOW_ID                                        BIGINT         NOT NULL,
    Seq_ID                                        INT            NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (100)  NOT NULL,
    Insert_GMT_Timestamp                          DATETIME       NOT NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (100)  NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Wait_Time_In_Min                              INT            NULL,
    Job_Params                                    VARCHAR (1000) NULL,
    CONSTRAINT FK_JOB_ORCH_CONTROL_BOW_ID FOREIGN KEY (BOW_ID) REFERENCES ABCR_CONTROL.BOW_CONTROL (BOW_ID),
    CONSTRAINT FK_JOB_ORCH_CONTROL_JOB_ID FOREIGN KEY (JOB_ID) REFERENCES ABCR_CONTROL.job_orchestration_master (JOB_ID),
    CONSTRAINT FK_JOB_ORCH_CONTROL_SBOW_ID FOREIGN KEY (SBOW_ID) REFERENCES ABCR_CONTROL.SBOW_CONTROL (SBOW_ID),
    CONSTRAINT FK_JOB_ORCH_CONTROL_TENANT_ID FOREIGN KEY (TENANT_ID) REFERENCES ABCR_CONTROL.TENANT_MASTER_CONTROL (Tenant_ID),
    CONSTRAINT FK_JOB_ORCH_CONTROL_UOW_ID FOREIGN KEY (UOW_ID) REFERENCES ABCR_CONTROL.UOW_CONTROL (UOW_ID)
);
