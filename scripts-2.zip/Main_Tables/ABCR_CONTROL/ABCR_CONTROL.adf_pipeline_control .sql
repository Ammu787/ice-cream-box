CREATE TABLE ABCR_CONTROL.adf_pipeline_control 
(
    JOB_ID                                        INT            NOT NULL,
    Parent_Pipeline_Text                          VARCHAR (100)  NULL,
    ChildPipeline_Text                            VARCHAR (100)  NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Description_Text                              VARCHAR (500)  NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    CONSTRAINT FK_ADF_PIPELINE_CONTROL_JOB_ID FOREIGN KEY (JOB_ID) REFERENCES ABCR_CONTROL.job_orchestration_master (JOB_ID)
);