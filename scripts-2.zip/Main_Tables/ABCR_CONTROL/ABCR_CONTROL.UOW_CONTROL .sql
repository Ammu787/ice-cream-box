CREATE TABLE ABCR_CONTROL.UOW_CONTROL 
(
    TENANT_ID                                     INT            NULL,
    BOW_ID                                        INT            NULL,
    SBOW_ID                                       INT            NULL,
    UOW_ID                                        BIGINT         NOT NULL,
    UOW_NAME                                      VARCHAR (1000) NULL,
    IS_ACTIVE_FLAG                                CHAR (1)       NULL,
    UOW_Description                               VARCHAR (1000) NULL,
    retry_on_error_flag                           CHAR (1)       NULL,
    severity_number                               INT            NULL,
    raise_ticket_flag                             INT            NULL,
    impact_number                                 INT            NULL,
    Is_Reprocess_Flag                             CHAR (1)       NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    UOW_CODE                                      VARCHAR (20)   NULL,
    PRIMARY KEY CLUSTERED (UOW_ID ASC),
    CONSTRAINT FK_UOW_CONTROL_BOW_ID FOREIGN KEY (BOW_ID) REFERENCES ABCR_CONTROL.BOW_CONTROL (BOW_ID),
    CONSTRAINT FK_UOW_CONTROL_SBOW_ID FOREIGN KEY (SBOW_ID) REFERENCES ABCR_CONTROL.SBOW_CONTROL (SBOW_ID),
    CONSTRAINT FK_UOW_CONTROL_TENANT_ID FOREIGN KEY (TENANT_ID) REFERENCES ABCR_CONTROL.TENANT_MASTER_CONTROL (Tenant_ID)
);
