CREATE TABLE ABCR_CONTROL.Configuration_Keys 
(
    Config_ID                                     INT            NOT NULL,
    Config_Key_Text                               VARCHAR (900)  NOT NULL,
    Description_Text                              VARCHAR (1000) NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    PRIMARY KEY CLUSTERED (Config_Key_Text ASC),
    CONSTRAINT Config_Keys_Unique UNIQUE NONCLUSTERED (Config_ID ASC)
);