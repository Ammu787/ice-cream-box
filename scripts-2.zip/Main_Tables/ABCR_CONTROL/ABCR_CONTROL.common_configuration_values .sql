CREATE TABLE ABCR_CONTROL.common_configuration_values 
(
    Config_Key_Text                               VARCHAR (900) NULL,
    Config_Value_Text                             VARCHAR (500) NULL,
    IS_Active_Flag                                CHAR (1)      NULL,
    Config_Group_Text                             VARCHAR (200) NULL,
    Description_Text                              VARCHAR (200) NULL,
    Insert_GMT_Timestamp                          DATETIME      NULL,
    Update_GMT_Timestamp                          DATETIME      NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (200) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (200) NULL,
    CONSTRAINT FK_CMN_CONFIGVALUES_CONFIG_KEY_TEXT FOREIGN KEY (Config_Key_Text) REFERENCES ABCR_CONTROL.Configuration_Keys (Config_Key_Text)
);
