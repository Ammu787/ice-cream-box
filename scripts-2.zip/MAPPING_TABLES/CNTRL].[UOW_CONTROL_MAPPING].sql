
CREATE TABLE [CNTRL].[UOW_CONTROL_MAPPING] (
    [New_Tenant_Id] INT    NULL,
    [New_BOW_ID]    INT    NULL,
    [New_SBOW_ID]   INT    NULL,
    [Old_UOW_ID]    BIGINT NULL,
    [New_UOW_ID]    BIGINT NULL
);