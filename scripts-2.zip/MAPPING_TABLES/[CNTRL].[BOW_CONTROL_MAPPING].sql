CREATE TABLE [CNTRL].[BOW_CONTROL_MAPPING] (
    [New_Tenant_Id] INT    NULL,
    [New_BOW_ID]    INT    NULL,
    [Old_BOW_ID]    BIGINT NULL
);