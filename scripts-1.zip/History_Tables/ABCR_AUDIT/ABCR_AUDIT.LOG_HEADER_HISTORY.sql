CREATE TABLE ABCR_AUDIT.LOG_HEADER_HISTORY 
(
    Tenant_ID                           INT            NOT NULL,
    Log_Header_ID                       INT            NOT NULL,
    BOW_ID                              INT            NULL,
    UOW_ID                              BIGINT         NULL,
    Batch_Execution_ID                  VARCHAR (50)   NULL,
    Status_Flag                         CHAR (1)       NULL,
    Execution_Start_Time                DATETIME2 (7)  NULL,
    Execution_End_Time                  DATETIME2 (7)  NULL,
    Edl_Validation_Flag                 CHAR (1)       NULL,
    Adls_Validation_Flag                CHAR (1)       NULL,
    SBOW_ID                             INT            NULL,
    Change_Data_Capture_Start_Timestamp DATETIME2 (7)  NULL,
    Change_Data_Capture_End_Timestamp   DATETIME2 (7)  NULL,
    Job_Execution_id                    VARCHAR (500)  NULL,
    Job_Id                              INT            NOT NULL,
    Source_Total_Record_Count           BIGINT         NULL,
    Target_Total_Record_Count           BIGINT         NULL,
    Modified_User                       VARCHAR (1000) NULL,
    Modified_Date                       DATETIME       NULL,
    PRIMARY KEY CLUSTERED (Log_Header_ID ASC)
);