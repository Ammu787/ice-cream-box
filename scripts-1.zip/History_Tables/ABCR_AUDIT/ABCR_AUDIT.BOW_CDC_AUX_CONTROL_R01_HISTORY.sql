CREATE TABLE ABCR_AUDIT.BOW_CDC_AUX_CONTROL_R01_HISTORY 
(
    TENANT_ID                                     INT            NOT NULL,
    BOW_ID                                        INT            NOT NULL,
    SBOW_ID                                       INT            NOT NULL,
    UOW_ID                                        BIGINT         NOT NULL,
    CHANGE_DATA_CAPTURE_START_TIMESTAMP           DATETIME2 (7)  NULL,
    CHANGE_DATA_CAPTURE_END_TIMESTAMP             DATETIME2 (7)  NULL,
    CHANGE_DATA_CAPTURE_START_SEQUENCE_NUMBER     BIGINT         NULL,
    CHANGE_DATA_CAPTURE_END_SEQUENCE_NUMBER       BIGINT         NULL,
    CDC_TYPE_DESCRIPTION                          VARCHAR (300)  NULL,
    INSERT_GMT_TIMESTAMP                          DATETIME       NULL,
    INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME VARCHAR (1000) NULL,
    UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME VARCHAR (1000) NULL,
    UPDATE_GMT_TIMESTAMP                          DATETIME       NULL,
    BATCHID                                       BIGINT         NULL,
    MICROBATCHID                                  BIGINT         NULL,
    Modified_User                                 VARCHAR (1000) NULL,
    Modified_Date                                 DATETIME       NULL
);