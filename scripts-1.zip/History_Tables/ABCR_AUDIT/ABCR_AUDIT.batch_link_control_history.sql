CREATE TABLE ABCR_AUDIT.batch_link_control_history 
(
    Tenant_id         INT            NULL,
    bow_id            INT            NULL,
    sbow_id           INT            NULL,
    uow_id            BIGINT         NULL,
    src_batch_exec_id VARCHAR (MAX)  NULL,
    tgt_batch_exec_id VARCHAR (MAX)  NULL,
    Modified_User     VARCHAR (1000) NULL,
    Modified_Date     DATETIME       NULL
);