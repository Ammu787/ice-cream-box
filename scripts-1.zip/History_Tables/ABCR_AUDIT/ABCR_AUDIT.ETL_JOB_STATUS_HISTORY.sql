CREATE TABLE ABCR_AUDIT.ETL_JOB_STATUS_HISTORY 
(
    OBJECT                  VARCHAR (100)  NULL,
    ETL_JOB_START_TIMESTAMP DATETIME       NULL,
    ETL_JOB_END_TIMESTAMP   DATETIME       NULL,
    UPDATE_DATE             DATETIME       NULL,
    NOTES1                  VARCHAR (500)  NULL,
    Modified_User           VARCHAR (1000) NULL,
    Modified_Date           DATETIME       NULL
);