CREATE TABLE ABCR_AUDIT.DATA_LOAD_STATISTICS_HISTORY 
(
    BOW_Id                 INT             NOT NULL,
    SBOW_Id                INT             NOT NULL,
    UOW_Id                 BIGINT          NULL,
    Job_Start_Time         DATETIME        NULL,
    Job_End_Time           DATETIME        NULL,
    ProcessID              VARCHAR (500)   NULL,
    Git_Project_Name       VARCHAR (500)   NULL,
    Job_Name               VARCHAR (1000)  NULL,
    Job_Repository_Id      VARCHAR (1000)  NULL,
    Job_Version            VARCHAR (1000)  NULL,
    Job_Used_Context       VARCHAR (500)   NULL,
    Component_Name         VARCHAR (500)   NULL,
    Stats_Capture_At       VARCHAR (500)   NULL,
    Job_Status             VARCHAR (500)   NULL,
    Job_Execution_Duration BIGINT          NULL,
    Error_Type             VARCHAR (500)   NULL,
    Error_Code             INT             NULL,
    Error_Message          NVARCHAR (4000) NULL,
    HPSM_Ticket_Status     VARCHAR (250)   NULL,
    Modified_User          VARCHAR (1000)  NULL,
    Modified_Date          DATETIME        NULL
);