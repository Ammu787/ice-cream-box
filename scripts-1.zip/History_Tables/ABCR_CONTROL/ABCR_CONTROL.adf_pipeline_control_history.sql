CREATE TABLE ABCR_CONTROL.adf_pipeline_control_history 
(
    JOB_ID                                        INT            NOT NULL,
    Parent_Pipeline_Text                          VARCHAR (100)  NULL,
    ChildPipeline_Text                            VARCHAR (100)  NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Description_Text                              VARCHAR (500)  NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Modified_user                                 VARCHAR (1000) NULL,
    Modified_date                                 DATETIME       NULL
);