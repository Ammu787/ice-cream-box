CREATE TABLE ABCR_CONTROL.ETL_TOOLS_MASTER_HISTORY 
(
    Tool_ID_Text                                  VARCHAR (20)   NULL,
    TOOL_NAME                                     VARCHAR (200)  NULL,
    IS_ACTIVE_FLAG                                CHAR (1)       NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Modified_User                                 VARCHAR (1000) NULL,
    Modified_Date                                 DATETIME       NULL
);