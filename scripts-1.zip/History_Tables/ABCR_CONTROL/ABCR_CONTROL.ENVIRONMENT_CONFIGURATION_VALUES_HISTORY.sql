CREATE TABLE ABCR_CONTROL.ENVIRONMENT_CONFIGURATION_VALUES_HISTORY 
(
    TENANT_ID                                     INT            NULL,
    ENVIRONMENT                                   VARCHAR (1000) NULL,
    ENVIRONMENT_CONFIG_KEY_TEXT                   VARCHAR (1000) NULL,
    ENVIRONMENT_CONFIG_VALUE_TEXT                 VARCHAR (1000) NULL,
    IS_ACTIVE_FLAG                                CHAR (1)       NULL,
    INSERT_GMT_TIMESTAMP                          DATETIME       NULL,
    UPDATE_GMT_TIMESTAMP                          DATETIME       NULL,
    INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME VARCHAR (1000) NULL,
    UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME VARCHAR (1000) NULL,
    MODIFIED_USER                                 VARCHAR (1000) NULL,
    MODIFIED_DATE                                 DATETIME       NULL
);