CREATE TABLE ABCR_CONTROL.Configuration_Keys_History 
(
    Config_ID                                     INT            NOT NULL,
    Config_Key_Text                               VARCHAR (900)  NULL,
    Description_Text                              VARCHAR (1000) NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Modified_User                                 VARCHAR (1000) NULL,
    Modified_Date                                 DATETIME       NULL
);