CREATE TABLE ABCR_CONTROL.SBOW_CONTROL_HISTORY 
(
    TENANT_ID                                     INT            NULL,
    BOW_ID                                        INT            NULL,
    SBOW_ID                                       INT            NULL,
    LAYER_CODE                                    CHAR (3)       NULL,
    SBOW_NAME                                     VARCHAR (1000) NULL,
    CDC_START_TIMESTAMP                           DATETIME       NULL,
    CDC_END_TIMESTAMP                             DATETIME       NULL,
    EMAIL                                         VARCHAR (1000) NULL,
    IS_ACTIVE_FLAG                                CHAR (1)       NULL,
    SEQUENCE_ID                                   INT            NULL,
    SBOW_DESCRIPTION                              VARCHAR (1000) NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_GMT_Timestamp                          DATETIME2 (7)  NULL,
    SBOW_CODE                                     VARCHAR (10)   NULL,
    Modified_User                                 VARCHAR (1000) NULL,
    Modified_Date                                 DATETIME       NULL
    
);