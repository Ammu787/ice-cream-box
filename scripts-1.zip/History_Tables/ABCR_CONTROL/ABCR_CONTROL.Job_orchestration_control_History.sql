CREATE TABLE ABCR_CONTROL.Job_orchestration_control_History 
(
    JOB_ID                                        INT            NOT NULL,
    TENANT_ID                                     INT            NOT NULL,
    BOW_ID                                        INT            NOT NULL,
    SBOW_ID                                       INT            NOT NULL,
    UOW_ID                                        BIGINT         NULL,
    Seq_ID                                        INT            NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (100)  NOT NULL,
    Insert_GMT_Timestamp                          DATETIME       NOT NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (100)  NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Wait_Time_In_Min                              INT            NULL,
    Job_Params                                    VARCHAR (1000) NULL,
    JOB_PART_ID                                   BIGINT         NULL,
    Modified_User                                 VARCHAR (500)  NULL,
    Modified_Date                                 DATETIME       NULL
);