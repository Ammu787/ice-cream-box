CREATE TABLE ABCR_CONTROL.Entity_Mapping_Control_History 
(
    Tenant_ID                                     INT            NULL,
    BOW_ID                                        INT            NOT NULL,
    SBOW_ID                                       INT            NOT NULL,
    UOW_ID                                        BIGINT         NULL,
    Parent_UOW_ID                                 BIGINT         NULL,
    IS_ACTIVE                                     CHAR (1)       NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NOT NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Modified_user                                 VARCHAR (1000) NULL,
    Modified_date                                 DATETIME       NULL
);