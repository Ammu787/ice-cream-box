CREATE TABLE ABCR_CONTROL.UOW_Configuration_Values_History 
(
    BOW_ID                                        INT            NULL,
    SBOW_ID                                       INT            NULL,
    UOW_ID                                        BIGINT         NULL,
    Config_Key_Text                               VARCHAR (900)  NULL,
    Config_Value_Text                             VARCHAR (4000) NULL,
    IS_Active_Flag                                CHAR (1)       NULL,
    Insert_GMT_Timestamp                          DATETIME       NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Modified_user                                 VARCHAR (1000) NULL,
    Modified_date                                 DATETIME       NULL
);