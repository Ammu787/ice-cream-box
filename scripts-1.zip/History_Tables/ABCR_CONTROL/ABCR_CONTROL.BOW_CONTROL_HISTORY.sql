CREATE TABLE ABCR_CONTROL.BOW_CONTROL_HISTORY 
(
    TENANT_ID                                     INT            NULL,
    BOW_ID                                        INT            NULL,
    BOW_NAME                                      VARCHAR (1000) NULL,
    SRC_SYSTEM_ID                                 VARCHAR (50)   NULL,
    EMAIL                                         VARCHAR (1000) NULL,
    IS_ACTIVE_FLAG                                CHAR (1)       NULL,
    BOW_Source_Description_TEXT                   VARCHAR (500)  NULL,
    Insert_GMT_Timestamp                          DATETIME2 (7)  NULL,
    severity_number                               INT            NULL,
    raise_ticket_flag                             TINYINT        NULL,
    impact_number                                 INT            NULL,
    Insert_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_Maintenance_System_Domain_Account_Name VARCHAR (1000) NULL,
    Update_GMT_Timestamp                          DATETIME       NULL,
    BOW_CODE                                      VARCHAR (10)   NULL,
    Modified_User                                 VARCHAR (1000) NULL,
    Modified_Date                                 DATETIME       NULL,
   
);