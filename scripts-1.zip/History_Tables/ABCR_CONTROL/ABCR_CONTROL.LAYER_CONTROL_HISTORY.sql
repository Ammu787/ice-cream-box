CREATE TABLE ABCR_CONTROL.LAYER_CONTROL_HISTORY 
(
    LAYER_CODE                                    VARCHAR (5)    NULL,
    LAYER_NAME                                    VARCHAR (500)  NULL,
    LAYER_DESCRIPTION_TEXT                        VARCHAR (2000) NULL,
    IS_ACTIVE_FLAG                                CHAR (1)       NULL,
    INSERT_GMT_TIMESTAMP                          DATETIME       NULL,
    UPDATE_GMT_TIMESTAMP                          DATETIME       NULL,
    INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME VARCHAR (200)  NULL,
    UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME VARCHAR (200)  NULL,
    MODIFIED_USER                                 VARCHAR (1000) NULL,
    MODIFIED_DATE                                 DATETIME       NULL
);