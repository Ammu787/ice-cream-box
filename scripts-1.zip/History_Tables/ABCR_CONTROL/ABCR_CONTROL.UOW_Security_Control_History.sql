CREATE TABLE ABCR_CONTROL.UOW_Security_Control_History 
(
    Tenant_ID         INT           NOT NULL,
    BOW_ID            INT           NOT NULL,
    SBOW_ID           INT           NOT NULL,
    UOW_ID            BIGINT        NULL,
    SEC_TYPE          VARCHAR (50)  NULL,
    Role              VARCHAR (50)  NULL,
    Columns           VARCHAR (MAX) NULL,
    is_encrypted      CHAR (1)      NOT NULL,
    location          CHAR (15)     NULL,
    Path              VARCHAR (250) NULL,
    Inserted_By_Name  VARCHAR (100) NULL,
    Inserted_DateTime DATETIME2 (7) NULL,
    Updated_By_Name   VARCHAR (100) NULL,
    updated_DateTime  DATETIME2 (7) NULL,
    Modified_User     VARCHAR (100) NULL,
    Modified_Date     DATETIME2 (7) NULL
);