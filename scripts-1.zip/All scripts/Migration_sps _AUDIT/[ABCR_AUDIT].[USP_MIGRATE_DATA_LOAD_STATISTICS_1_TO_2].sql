-- =======================================================  
-- Create Migrate Procedure Template for <ABCR_AUDIT>.<USP_MIGRATE_DATA_LOAD_STATISTICS_1_TO_2>  
-- Author:������<Amani>  
-- Create Date: <27-09-2022>  
-- Description: <Migrating data from CNTRL.Data_Load_statistics to ABCR_AUDIT.VW_DATA_LOAD_STATISTICS table>  
-- =============================================  
 
  
CREATE procedure [ABCR_AUDIT].[USP_MIGRATE_DATA_LOAD_STATISTICS_1_TO_2]  
@Old_BOW_ID Bigint  
  
AS  
BEGIN  
SET NOCOUNT ON  
  
Declare 
@New_BOW_ID Int,  
@New_SBOW_ID Int,  
@New_UOW_ID BigInt  
  
Select BOW_Id,SBOW_Id,Cast(UOW_Id as Bigint) as UOW_ID,Job_Start_Time,Job_End_Time,ProcessID,Git_Project_Name,Job_Name,Job_Repository_Id,Job_Version,Job_Used_Context,  
Component_Name,Stats_Capture_At,Job_Status,Job_Execution_Duration,Error_Type,Error_Code,Error_Message,HPSM_Ticket_Status  
into #Data_Load_statistics from CNTRL.DATA_LOAD_STATS where  BOW_Id=@Old_BOW_ID  
  
--Select @New_Tenant_ID=New_Tenant_Id from CNTRL.TENANT_MASTER_CONTRL_MAPPING where Old_Tenant_Id=@Old_TENANT_ID  
Select @New_BOW_ID=New_BOW_ID from CNTRL.BOW_CONTROL_MAPPING where Old_BOW_ID=@Old_BOW_ID  
Select New_BOW_ID, New_SBOW_ID, New_UOW_ID,Old_UOW_ID into #uow_mapping_Data_load_statistics from CNTRL.UOW_CONTROL_MAPPING where New_BOW_ID=@New_BOW_ID  
  
Insert into ABCR_AUDIT.VW_DATA_LOAD_STATISTICS Select New_BOW_ID,New_SBOW_ID,New_UOW_ID,Job_Start_Time,Job_End_Time,ProcessID,Git_Project_Name,Job_Name,  
Job_Repository_Id,Job_Version,Job_Used_Context,Component_Name,Stats_Capture_At,Job_Status,Job_Execution_Duration,Error_Type,Error_Code,Error_Message,  
HPSM_Ticket_Status from #Data_Load_statistics a,#uow_mapping_Data_load_statistics b  
where a.UOW_ID = b.Old_UOW_ID  
  
Select * from ABCR_AUDIT.VW_DATA_LOAD_STATISTICS Where BOW_Id=@New_BOW_ID
  
END  



