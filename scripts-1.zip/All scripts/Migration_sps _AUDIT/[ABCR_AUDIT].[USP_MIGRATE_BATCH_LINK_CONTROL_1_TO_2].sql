-- =======================================================
-- Create Migrate Procedure Template for <ABCR_AUDIT>.<USP_MIGRATE_BATCH_LINK_CONTROL_1_TO_2>
-- Author:������<Amani>
-- Create Date: <04-10-2022>
-- Description: <Migrating data from CNTRL.BATCH_LINK_CONTROL to ABCR_AUDIT.VW_BATCH_LINK_CONTROL table>
-- =============================================

CREATE procedure [ABCR_AUDIT].[USP_MIGRATE_BATCH_LINK_CONTROL_1_TO_2]
@Old_BOW_ID Bigint,
@Old_TENANT_ID Bigint


AS
BEGIN
SET NOCOUNT ON

Declare @New_TENANT_ID Int,
@New_BOW_ID Int,
@New_SBOW_ID Int,
@New_UOW_ID BigInt
 
Select Tenant_id,bow_id,sbow_id,Cast(uow_id as Bigint) as uow_id,src_batch_exec_id,tgt_batch_exec_id into #batch_link_control from CNTRL.batch_link_control where Tenant_id=@Old_TENANT_ID and bow_id=@Old_BOW_ID

Select @New_Tenant_ID=New_Tenant_Id from CNTRL.TENANT_MASTER_CONTRL_MAPPING where Old_Tenant_Id=@Old_TENANT_ID

Select New_Tenant_Id, New_BOW_ID,New_SBOW_ID, New_UOW_ID,Old_UOW_ID into #uow_mapping_batch_link_control from CNTRL.UOW_CONTROL_MAPPING where New_Tenant_Id=@New_TENANT_ID

Insert into ABCR_AUDIT.VW_batch_link_control Select New_Tenant_Id,New_BOW_ID,New_SBOW_ID,New_UOW_ID,src_batch_exec_id,tgt_batch_exec_id  
from #batch_link_control a,#uow_mapping_batch_link_control b where a.uow_id = b.Old_UOW_ID

Select * from  ABCR_AUDIT.VW_batch_link_control where Tenant_id=@New_TENANT_ID

END



