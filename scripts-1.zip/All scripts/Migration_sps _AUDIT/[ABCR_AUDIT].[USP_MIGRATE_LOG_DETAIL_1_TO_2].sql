-- =======================================================
-- Create Migrate Procedure Template for <ABCR_AUDIT>.<USP_MIGRATE_LOG_DETAIL_1_TO_2>
-- Author:������<Amani>
-- Create Date: <O4-10-2022>
-- Description: <Migrating data from CNTRL.LOG_DETAIL to ABCR_AUDIT.VW_LOG_DETAIL table>
-- =============================================

CREATE  procedure [ABCR_AUDIT].[USP_MIGRATE_LOG_DETAIL_1_TO_2]
@Old_BOW_ID Bigint,
@Old_TENANT_ID Bigint


AS
BEGIN
SET NOCOUNT ON

Declare @New_TENANT_ID Int,
@New_BOW_ID Int,
@New_SBOW_ID Int,
@New_UOW_ID BigInt
 
Select Tenant_ID,Log_Header_ID,Log_Detail_ID,BOW_ID,Cast(UOW_ID as Bigint) as UOW_ID,Stage_ID,Batch_Execution_ID,Batch_ID,Status_Flag,Start_Part_Number,End_Part_Number,Execution_Start_Time,
Execution_End_Time,Landing_Record_Count,History_Total_Record_Count,Total_Partitions_Count,Total_Files_Count,File_Name_Processed,Task_ID,
Inserted_Record_Count,Updated_Record_Count,Deleted_Record_Count,Fedllc_Record_Count,Fed_Inserted_Record_Count,Fed_Updated_Record_Count,
Fed_Deleted_Record_Count into #log_detail from CNTRL.Log_Detail where Tenant_ID=@Old_TENANT_ID and BOW_ID=@Old_BOW_ID

Select @New_Tenant_ID=New_Tenant_Id from CNTRL.TENANT_MASTER_CONTRL_MAPPING where Old_Tenant_Id=@Old_TENANT_ID

Select New_Tenant_Id, New_BOW_ID, New_SBOW_ID, New_UOW_ID,Old_UOW_ID into #uow_mapping_log_detail from CNTRL.UOW_CONTROL_MAPPING where New_Tenant_Id=@New_TENANT_ID


Insert into ABCR_AUDIT.VW_LOG_DETAIL Select New_Tenant_Id,Log_Header_ID,Log_Detail_ID,New_BOW_ID,New_UOW_ID,Stage_ID,Batch_Execution_ID,Batch_ID,Status_Flag,Start_Part_Number,End_Part_Number,Execution_Start_Time,
Execution_End_Time,Landing_Record_Count,History_Total_Record_Count,Total_Partitions_Count,Total_Files_Count,File_Name_Processed,Task_ID,
Inserted_Record_Count,Updated_Record_Count,Deleted_Record_Count,Fedllc_Record_Count,Fed_Inserted_Record_Count,Fed_Updated_Record_Count,
Fed_Deleted_Record_Count  from #log_detail a,#uow_mapping_log_detail b where a.UOW_ID = b.Old_UOW_ID

Select * from  ABCR_AUDIT.VW_LOG_DETAIL Where Tenant_ID=@New_TENANT_ID

END


