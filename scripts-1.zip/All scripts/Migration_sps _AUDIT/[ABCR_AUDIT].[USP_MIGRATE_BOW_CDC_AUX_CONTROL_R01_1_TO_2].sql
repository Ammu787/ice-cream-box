-- =======================================================
-- Create Migrate Procedure Template for <ABCR_AUDIT>.<USP_MIGRATE_BOW_CDC_AUX_CONTROL_R01_1_TO_2>
-- Author:������<Amani>
-- Create Date: <04-10-2022>
-- Description: <Migrating data from CNTRL.BOW_CDC_AUX_CONTROL_R01 to ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL table>
-- =======================================================

CREATE  procedure [ABCR_AUDIT].[USP_MIGRATE_BOW_CDC_AUX_CONTROL_R01_1_TO_2]
@Old_BOW_ID Bigint,
@Old_TENANT_ID Bigint


AS
BEGIN
SET NOCOUNT ON

Declare @New_TENANT_ID int,
@New_BOW_ID Int,
@New_SBOW_ID Int,
@New_UOW_ID BigInt

 

Select BOW_ID,UOW_Unique_ID as UOW_ID,CHANGE_DATA_CAPTURE_START_TIMESTAMP,CHANGE_DATA_CAPTURE_END_TIMESTAMP,CDC_TYPE_DESCRIPTION,Insert_GMT_Timestamp
 into #bow_cdc_aux_control_r01 from CNTRL.BOW_CDC_AUX_CONTROL_R01 where BOW_ID=@Old_BOW_ID 

Select @New_Tenant_ID=New_Tenant_Id from CNTRL.TENANT_MASTER_CONTRL_MAPPING where Old_Tenant_Id=@Old_TENANT_ID

Select  New_Tenant_Id,New_BOW_ID, New_SBOW_ID, New_UOW_ID,Old_UOW_ID into #uow_mapping_bow_cdc_aux_control_r01 from CNTRL.UOW_CONTROL_MAPPING where New_Tenant_Id=@New_Tenant_Id

Insert into ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL Select  New_Tenant_Id,New_BOW_ID,New_SBOW_ID,New_UOW_ID,CHANGE_DATA_CAPTURE_START_TIMESTAMP,
CHANGE_DATA_CAPTURE_END_TIMESTAMP,NULL,NULL,CDC_TYPE_DESCRIPTION,Insert_GMT_Timestamp,NULL,NULL,NULL,NULL,NULL from #bow_cdc_aux_control_r01 a,#uow_mapping_bow_cdc_aux_control_r01 b 
where a.UOW_ID = b.Old_UOW_ID

Select * from ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL where TENANT_ID=@New_TENANT_ID

END
  



