-- =======================================================
-- Create Migrate Procedure Template for <ABCR_AUDIT>.<USP_MIGRATE_LOG_HEADER_1_TO_2>
-- Author:������<Amani>
-- Create Date: <01-10-2022>
-- Description: <Migrating data from CNTRL.LOG_HEADER to ABCR_AUDIT.VW_LOG_HEADER table>
-- =======================================================

CREATE procedure [ABCR_AUDIT].[USP_MIGRATE_LOG_HEADER_1_TO_2]
@Old_BOW_ID Bigint,
@Old_TENANT_ID Bigint


AS
BEGIN
SET NOCOUNT ON

Declare @New_TENANT_ID Int,
@New_BOW_ID Int,
@New_SBOW_ID Int,
@New_UOW_ID BigInt
 
Select Tenant_ID,Log_Header_ID,BOW_ID,Cast(UOW_ID as Bigint) as UOW_ID,Batch_Execution_ID,Status_Flag,Execution_Start_Time,Execution_End_Time,Edl_Validation_Flag,
Adls_Validation_Flag,SBOW_ID,Change_Data_Capture_Start_Timestamp,Change_Data_Capture_End_Timestamp,Job_Execution_id,Job_Id,Source_Total_Record_Count,
Target_Total_Record_Count  into #log_header from CNTRL.Log_Header where Tenant_ID=@Old_TENANT_ID and BOW_ID=@Old_BOW_ID

Select @New_Tenant_ID=New_Tenant_Id from CNTRL.TENANT_MASTER_CONTRL_MAPPING where Old_Tenant_Id=@Old_TENANT_ID

Select New_Tenant_Id,New_BOW_ID, New_SBOW_ID, New_UOW_ID,Old_UOW_ID into #uow_mapping_log_header from CNTRL.UOW_CONTROL_MAPPING where New_Tenant_Id=@New_TENANT_ID
Select New_JOB_ID,Old_JOB_ID into #jobid_mapping_log_header from CNTRL.JOB_ORCHESTARTION_MASTER_MAPPING where New_TENANT_ID=@New_TENANT_ID 


Insert into ABCR_AUDIT.VW_LOG_HEADER Select  New_Tenant_Id,Log_Header_ID,New_BOW_ID,New_UOW_ID,Batch_Execution_ID,Status_Flag,Execution_Start_Time,Execution_End_Time,
Edl_Validation_Flag,Adls_Validation_Flag,New_SBOW_ID,Change_Data_Capture_Start_Timestamp,Change_Data_Capture_End_Timestamp,Job_Execution_id,New_JOB_ID,
Source_Total_Record_Count,Target_Total_Record_Count from #log_header a,#uow_mapping_log_header b, #jobid_mapping_log_header c 
where a.UOW_ID = b.Old_UOW_ID AND a.Job_Id=c.Old_JOB_ID 

Select * FROM ABCR_AUDIT.VW_LOG_HEADER Where Tenant_ID=@New_TENANT_ID

END



