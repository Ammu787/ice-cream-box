-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_Process_Control>
-- Author:      <Chiranjeevi>
-- Create Date: <17-10-2022>
-- Description: <Updating data into ABCR_CONTROL.Process_Control table>
-- =============================================

Create or Alter procedure ABCR_CONTROL.USP_UPDATE_PROCESS_CONTROL_APPROACH-1_Update
@Tenant_ID int,
@BOW_ID int,
@SBOW_ID int,
@UOW_ID bigint,
@Stage_ID int,
@Task_ID int,
@Batch_ID int,
@Query_Type varchar(max),
@Query_Text varchar(max),
@Schema_ID Bigint,
@SPARK_SETTINGS_TEXT varchar(Max),
@IS_ACTIVE_FLAG char(1),
@Source_Table_Name varchar(100),
@Target_Table_Name varchar(100),
@PARAMS_JSON_TEXT varchar(4000),
@Actions_Text varchar(MAX),
@Insert_GMT_Timestamp datetime,
@Insert_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_GMT_Timestamp datetime

AS
BEGIN
SET NOCOUNT ON

If @Tenant_ID Is null OR @BOW_ID is null OR @SBOW_ID is null OR @UOW_ID is null

	Begin
		THROW 51000, 'Pass Tenant_ID, BOW_ID, SBOW_ID AND UOW_ID values to update the statement',1
	END

	If Exists
		(Select * from ABCR_CONTROL.VW_Process_Control WHERE Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID AND Stage_ID=@Stage_ID AND Task_ID=@Task_ID AND Batch_ID=@Batch_ID)
		Begin
			Insert into ABCR_CONTROL.Process_Control_History Select Tenant_ID,BOW_ID,SBOW_ID,UOW_ID,Stage_ID,Task_ID,Batch_ID,Query_Type,Query_Text,Schema_ID,
			SPARK_SETTINGS_TEXT,IS_ACTIVE_FLAG,Source_Table_Name,Target_Table_Name,PARAMS_JSON_TEXT,Actions_Text,Insert_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,
			Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_Process_Control
			Where Tenant_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID AND Stage_ID=@Stage_ID AND Task_ID=@Task_ID AND Batch_ID=@Batch_ID
		END
		
			Else 
				Begin
					THROW 51000, 'No entry with @Tenant_ID, @BOW_ID, @SBOW_ID & @UOW_ID',1
				END
				
	   BEGIN
	        Update ABCR_CONTROL.Process_control Set Tenant_ID=Isnull(@TENANT_ID,Tenant_ID),BOW_ID=Isnull(@BOW_ID,BOW_ID), SBOW_ID=Isnull(@SBOW_ID,SBOW_ID),UOW_ID=Isnull(@UOW_ID,UOW_ID),
              Stage_ID=Isnull(@Stage_ID,Stage_ID),Task_ID=Isnull(@Task_ID,Task_ID),Batch_ID=ISnull(@Batch_ID,Batch_ID),Query_Type=Isnull(@Query_Type,Query_Type),Query_Text=Isnull(@Query_Text,Query_Text),
		  Schema_ID=Isnull(@Schema_ID,Schema_ID),SPARK_SETTINGS_TEXT=Isnull(@SPARK_SETTINGS_TEXT,SPARK_SETTINGS_TEXT),IS_ACTIVE_FLAG=Isnull(@IS_ACTIVE_FLAG,IS_ACTIVE_FLAG),
		  Source_Table_Name=Isnull(@Source_Table_Name,Source_Table_Name),Target_Table_Name=Isnull(@Target_Table_Name,Target_Table_Name),PARAMS_JSON_TEXT=Isnull(@PARAMS_JSON_TEXT,PARAMS_JSON_TEXT),
		  Actions_Text=Isnull(@Actions_Text,Actions_Text),Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
		  Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,Update_GMT_Timestamp=CURRENT_TIMESTAMP Where Tenant_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID AND Stage_ID=@Stage_ID AND Task_ID=@Task_ID AND Batch_ID=@Batch_ID
		  
		  Begin
				Select * From ABCR_CONTROL.VW_Process_Control Where Tenant_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID AND Stage_ID=@Stage_ID AND Task_ID=@Task_ID AND Batch_ID=@Batch_ID
			End
		End
End
		  
		  
