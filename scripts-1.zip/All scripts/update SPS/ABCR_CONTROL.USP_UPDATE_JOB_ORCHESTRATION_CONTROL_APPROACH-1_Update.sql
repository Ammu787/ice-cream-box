-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_JOB_ORCHESTRATION_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <09-12-2022>
-- Description: <Updating data into ABCR_CONTROL.JOB_ORCHESTRATION_CONTROL Table>
-- =============================================

Create or Alter procedure ABCR_CONTROL.USP_UPDATE_JOB_ORCHESTRATION_CONTROL_APPROACH-1_Update
JOB_ID int NULL,
TENANT_ID int NOT NULL,
BOW_ID int NOT NULL,
SBOW_ID int NOT NULL,
UOW_ID Bigint NOT NULL,
Seq_ID int NULL,
IS_Active_Flag char(1) NULL,
Insert_Maintenance_System_Domain_Account_Name varchar(100) NOT NULL,
Insert_GMT_Timestamp datetime NOT NULL,
Update_Maintenance_System_Domain_Account_Name varchar(100) NULL,
Update_GMT_Timestamp datetime NULL,
Wait_Time_In_Min int NULL,
Job_Params Varchar(1000)

AS
BEGIN
SET NOCOUNT ON
 
If  @Tenant_ID Is null OR @BOW_ID is null OR @SBOW_ID is null OR @UOW_ID is null 

    Begin
		THROW 51000,'Pass Tenant_ID,BOW_ID,SBOW_ID AND UOW_ID values to update the statement',1
	END
	If Exists
		(Select * from ABCR_CONTROL.VW_Job_orchestration_control WHERE Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID)
		Begin
			Insert into ABCR_CONTROL.Job_orchestration_control_History Select Tenant_ID,BOW_ID,SBOW_ID,UOW_ID,Seq_ID,IS_Active_Flag,Update_Maintenance_System_Domain_Account_Name,
			Update_GMT_Timestamp,Wait_Time_In_Min,Job_Params,SYSTEM_USER,CURRENT_TIMESTAMP,from ABCR_CONTROL.VW_Job_orchestration_control
			Where Tenant_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		END
		
			Else 
				Begin
					THROW 51000, 'No entry with @Tenant_ID,@BOW_ID,@SBOW_ID & @UOW_ID',1
			    END
        BEGIN
	            Update ABCR_CONTROL.VW_Job_orchestration_control Set Tenant_ID=Isnull(@TENANT_ID,Tenant_ID),BOW_ID=Isnull(@BOW_ID,BOW_ID),SBOW_ID=Isnull(@SBOW_ID,SBOW_ID),
			UOW_ID=Isnull(@UOW_ID,UOW_ID),Seq_ID=Isnull(@Seq_ID,Seq_ID),IS_Active_Flag=Isnull(@IS_Active_Flag,IS_Active_Flag),Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
			Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,
			Update_GMT_Timestamp=CURRENT_TIMESTAMP Where Tenant_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
			
			Begin
				Select * From ABCR_CONTROL.VW_Job_orchestration_control Where Tenant_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID 
			End
		End
End
				
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

