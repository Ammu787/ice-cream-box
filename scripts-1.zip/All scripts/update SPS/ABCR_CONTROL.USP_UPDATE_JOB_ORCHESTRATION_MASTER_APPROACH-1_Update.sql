-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_JOB_ORCHESTRATION_MASTER>
-- Author:      <Chiranjeevi>
-- Create Date: <17-10-2022>
-- Description: <Updating data into ABCR_CONTROL.VW_JOB_ORCHESTRATION_MASTER table>
-- =======================================================

Create  procedure ABCR_CONTROL.USP_UPDATE_JOB_ORCHESTRATION_MASTER_APPROACH-1_Update
@TENANT_ID int NULL,
@JOB_ID int,
@Job_Name_Text varchar(200) NULL,
@Job_Description_Text varchar(200) NULL,
@IS_Active_Flag char(1) NULL,
@JOB_EXECUTION_TIME datetime NULL,
@INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME varchar(200) NULL,
@INSERT_GMT_TIMESTAMP datetime NULL,
@UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME varchar(200) NULL,
@UPDATE_GMT_TIMESTAMP datetime NULL,
@Spark_Cluster_Size_Text varchar(100) NULL,
@Tool_ID_Text varchar(20) NULL

AS
BEGIN
SET NOCOUNT ON

If @Tenant_ID Is null or JOB_ID Is null

	Begin
		THROW 51000, 'Pass TENANT_ID,JOB_ID to update the statement',1
	END

	If Exists
		(Select * from ABCR_CONTROL.VW_job_orchestration_master WHERE TENANT_ID=@Tenant_ID)
		Begin
			  Insert into ABCR_CONTROL.job_orchestration_master_history Select TENANT_ID,JOB_ID,Job_Name_Text,Job_Description_Text,IS_Active_Flag,JOB_EXECUTION_TIME,
                    UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME,UPDATE_GMT_TIMESTAMP,Spark_Cluster_Size_Text,Tool_ID_Text,SYSTEM_USER,CURRENT_TIMESTAMP from 
                    ABCR_CONTROL.VW_job_orchestration_master Where TENANT_ID=@Tenant_ID And JOB_ID=@JOB_ID
		END
		
			Else 
				Begin
					THROW 51000, 'No entry with @Tenant_ID,@JOB_ID',1
				END
				BEGIN
	                         Update ABCR_CONTROL.VW_job_orchestration_master Set TENANT_ID=Isnull(@TENANT_ID,TENANT_ID),JOB_ID=Isnull(@JOB_ID,JOB_ID),Job_Name_Text=Isnull(@Job_Name_Text,Job_Name_Text),
					 Job_Description_Text=Isnull(@Job_Description_Text,Job_Description_Text),IS_Active_Flag=Isnull(@IS_Active_Flag,IS_Active_Flag),
					 JOB_EXECUTION_TIME=Isnull(@JOB_EXECUTION_TIME,JOB_EXECUTION_TIME),INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME=Isnull(@INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME,INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME),
					 INSERT_GMT_TIMESTAMP=Isnull(@INSERT_GMT_TIMESTAMP,INSERT_GMT_TIMESTAMP),UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME=SYSTEM_USER,UPDATE_GMT_TIMESTAMP=CURRENT_TIMESTAMP,Spark_Cluster_Size_Text=Isnull(@Spark_Cluster_Size_Text,Spark_Cluster_Size_Text),
					 Tool_ID_Text=Isnull(@Tool_ID_Text,Tool_ID_Text) Where TENANT_ID=@TENANT_ID and JOB_ID=@JOB_ID
			      END

				Begin
				  Select * From ABCR_CONTROL.VW_job_orchestration_master Where TENANT_ID=@TENANT_ID and JOB_ID=@JOB_ID                                       
                        End


END
				
				
				
				
				
				
				
				
			