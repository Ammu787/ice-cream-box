-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_UOW_Configuration_Values>
-- Author:      <Chiranjeevi>
-- Create Date: <17-10-2022>
-- Description: <Updating data into ABCR_CONTROL.VW_UOW_Configuration_Values table>
-- =======================================================

Create procedure ABCR_CONTROL.USP_UPDATE_UOW_Configuration_Values_APPROACH-1_Update
@BOW_ID int NULL,
@SBOW_ID int NULL,
@UOW_ID bigint NULL,
@Config_Key_Text varchar(900) NULL,
@Config_Value_Text varchar(4000) NULL,
@IS_Active_Flag char(1) NULL,
@Insert_GMT_Timestamp datetime NULL,
@Update_GMT_Timestamp datetime NULL,
@Insert_Maintenance_System_Domain_Account_Name varchar(1000) NULL,
@Update_Maintenance_System_Domain_Account_Name varchar(1000) NULL

AS
BEGIN
SET NOCOUNT ON

If  @BOW_ID is null OR @SBOW_ID is null OR @UOW_ID is null
     
	 BEGIN
		THROW 51000, 'Pass BOW_ID,SBOW_ID AND UOW_ID values to update the statement',1
	 END

	If Exists
		(select * from ABCR_CONTROL.VW_UOW_Configuration_Values WHERE  BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID)
		Begin
			Insert into ABCR_CONTROL.UOW_Configuration_Values_History select BOW_ID,SBOW_ID,UOW_ID,Config_Key_Text,Config_Value_Text,IS_Active_Flag,
                  Update_GMT_Timestamp,Update_Maintenance_System_Domain_Account_Name,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_UOW_Configuration_Values
			Where BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		END
		
                Else 
				BEGIN
					THROW 51000, 'No entry with  @BOW_ID, @SBOW_ID & @UOW_ID',1
				END
				
	      BEGIN
	               Update ABCR_CONTROL.VW_UOW_Configuration_Values Set BOW_ID=Isnull(@BOW_ID,BOW_ID),SBOW_ID=Isnull(@SBOW_ID,BOW_ID),UOW_ID=Isnull(@UOW_ID,UOW_ID),
			   Config_Key_Text=Isnull(@Config_Key_Text,Config_Value_Text),IS_Active_Flag=Isnull(@IS_Active_Flag,IS_Active_Flag),Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),
			   Update_GMT_Timestamp=CURRENT_TIMESTAMP,Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
			   Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER where BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID

			Begin
				Select * From ABCR_CONTROL.VW_UOW_Configuration_Values Where BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
			End
             END

End
		  
		  
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			