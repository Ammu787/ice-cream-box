-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_ABCR_CONTROL.ADF_PIPELINE_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <09-12-2022>
-- Description: <Updating data into ABCR_CONTROL.ADF_PIPELINE_CONTROL Table>
-- =============================================

Create or Alter procedure ABCR_CONTROL.USP_UPDATE_ADF_PIPELINE_CONTROL_APPROACH-1_Update
JOB_ID int NOT NULL,
Parent_Pipeline_Text varchar(100) NULL,
ChildPipeline_Text varchar(100) NULL,
IS_Active_Flag char(1) NULL,
Description_Text varchar(500) NULL,
Insert_GMT_Timestamp datetime NULL,
Update_GMT_Timestamp datetime NULL,
Insert_Maintenance_System_Domain_Account_Name varchar(1000) NULL,
Update_Maintenance_System_Domain_Account_Name varchar(1000) NULL

AS
BEGIN
SET NOCOUNT ON
 
If  @JOB_ID is null
    Begin
		THROW 51000,'Pass JOB_ID to update the statement',1
	END
	
      If Exists
		(Select * from ABCR_CONTROL.VW_ADF_PIPELINE_CONTROL where JOB_ID=@JOB_ID)
	Begin
	   Insert into ABCR_CONTROL.ADF_PIPELINE_CONTROL_History Select JOB_ID,Parent_Pipeline_Text,ChildPipeline_Text,IS_Active_Flag,
	   Update_GMT_Timestamp,Update_Maintenance_System_Domain_Account_Name,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_ADF_PIPELINE_CONTROL where JOB_ID=@JOB_ID
	END
		
			Else 
				Begin
					THROW 51000, 'No entry with @JOB_ID',1
			    END
	BEGIN
	    Update ABCR_CONTROL.VW_ADF_PIPELINE_CONTROL set JOB_ID=Isnull(@JOB_ID,JOB_ID),Parent_Pipeline_Text=Isnull(@Parent_Pipeline_Text,Parent_Pipeline_Text),
	    ChildPipeline_Text=Isnull(@ChildPipeline_Text,ChildPipeline_Text),IS_Active_Flag=Isnull(@IS_Active_Flag,IS_Active_Flag),Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
	    Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,Update_GMT_Timestamp=CURRENT_TIMESTAMP Where JOB_ID=@JOB_ID
	
		    Begin
				Select * From ABCR_CONTROL.VW_ADF_PIPELINE_CONTROL Where JOB_ID=@JOB_ID
			End
	End
End
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	