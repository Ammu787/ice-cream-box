-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_ABCR_CONTROL.JOB_CONFIGURATION_VALUES>
-- Author:      <Chiranjeevi>
-- Create Date: <09-12-2022>
-- Description: <Updating data into ABCR_CONTROL.JOB_CONFIGURATION_VALUES Table>
-- =============================================

Create or Alter procedure ABCR_CONTROL.USP_UPDATE_JOB_CONFIGURATION_VALUES_APPROACH-1_Update
JobId int NULL,
Config_Key_Text varchar(900) NULL,
Config_Value_Text varchar(1000) NULL,
Description_Text varchar(1000) NULL,
IS_Active_Flag char(1) NULL,
Insert_Maintenance_System_Domain_Account_Name varchar(1000) NULL,
Update_Maintenance_System_Domain_Account_Name varchar(1000) NULL,
Insert_GMT_Timestamp datetime NULL,
Update_GMT_Timestamp datetime NULL

AS
BEGIN
SET NOCOUNT ON
 
If  @JobId is null
    Begin
		THROW 51000,'Pass JobId to update the statement',1
	END
	If Exists
		(Select * from ABCR_CONTROL.VW_JOB_CONFIGURATION_VALUES where JobId=@JobId)
	Begin
	   Insert into ABCR_CONTROL.JOB_CONFIGURATION_VALUES_History Select JobId,Config_Key_Text,Config_Value_Text,Description_Text,IS_Active_Flag,
	   Update_GMT_Timestamp,Update_Maintenance_System_Domain_Account_Name,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_JOB_CONFIGURATION_VALUES where JobId=@JobId
	END
		
			Else 
				Begin
					THROW 51000, 'No entry with @JobId',1
			    END
	BEGIN
	      Update ABCR_CONTROL.VW_JOB_CONFIGURATION_VALUES set JobId=Isnull(@JobId,JobId),Config_Key_Text=Isnull(@Config_Key_Text,Config_Key_Text),
		Config_Value_Text=Isnull(@Config_Value_Text,Config_Value_Text),Description_Text=Isnull(@Description_Text,Description_Text),IS_Active_Flag=Isnull(@IS_Active_Flag,IS_Active_Flag),
		Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
		Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,Update_GMT_Timestamp=CURRENT_TIMESTAMP Where JobId=@JobId
		Begin
			Select * From ABCR_CONTROL.VW_JOB_CONFIGURATION_VALUES  Where JobId=@JobId
		End
	End
End
		
		
		
		
		
		
		
		
		
		
		