-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_UPDATE_ENTITY_MAPPING_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <09-12-2022>
-- Description: <Updating data into ABCR_CONTROL.ENTITY_MAPPING_CONTROL Table>
-- =============================================

Create or Alter procedure ABCR_CONTROL.USP_UPDATE_ENTITY_MAPPING_CONTROL_APPROACH-1_Update
Tenant_ID int NULL,
BOW_ID int NOT NULL,
SBOW_ID int NOT NULL,
UOW_ID bigint NOT NULL,
Parent_UOW_ID bigint NULL,
IS_ACTIVE char(1) NULL,
Insert_GMT_Timestamp datetime NULL,
Insert_Maintenance_System_Domain_Account_Name varchar(1000) NOT NULL,
Update_Maintenance_System_Domain_Account_Name varchar(1000) NULL,
Update_GMT_Timestamp datetime NULL

AS
BEGIN
SET NOCOUNT ON
 
If  @Tenant_ID Is null OR @BOW_ID is null OR @SBOW_ID is null OR @UOW_ID is null 

    Begin
		THROW 51000,'Pass Tenant_ID,BOW_ID,SBOW_ID AND UOW_ID values to update the statement',1
    END
	If Exists
		(Select * from ABCR_CONTROL.VW_Entity_Mapping_Control WHERE Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID)
		Begin
			Insert into ABCR_CONTROL.Entity_Mapping_Control_History Select Tenant_ID,BOW_ID,SBOW_ID,UOW_ID,Parent_UOW_ID,IS_ACTIVE,
			Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,SYSTEM_USER,CURRENT_TIMESTAMP from ABCR_CONTROL.VW_Entity_Mapping_Control 
			WHERE Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		END
		
			Else 
				Begin
					THROW 51000, 'No entry with @Tenant_ID,@BOW_ID,@SBOW_ID & @UOW_ID',1
			      END
	BEGIN
	       Update ABCR_CONTROL.VW_Entity_Mapping_Control Set Tenant_ID=Isnull(@TENANT_ID,Tenant_ID),BOW_ID=Isnull(@BOW_ID,BOW_ID),SBOW_ID=Isnull(@SBOW_ID,SBOW_ID),
		 UOW_ID=Isnull(@UOW_ID,UOW_ID),Parent_UOW_ID=Isnull(@Parent_UOW_ID,Parent_UOW_ID),IS_ACTIVE=Isnull(@IS_ACTIVE,IS_ACTIVE),Insert_Maintenance_System_Domain_Account_Name=Isnull(@Insert_Maintenance_System_Domain_Account_Name,Insert_Maintenance_System_Domain_Account_Name),
		 Insert_GMT_Timestamp=Isnull(@Insert_GMT_Timestamp,Insert_GMT_Timestamp),Update_Maintenance_System_Domain_Account_Name=SYSTEM_USER,
		 Update_GMT_Timestamp=CURRENT_TIMESTAMP Where Tenant_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
			Begin
				Select * From ABCR_CONTROL.VW_Entity_Mapping_Control Where Tenant_ID=@TENANT_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID 
			End
	End
End
		
	
	
	
	
	
	
	
	
	
	
	