-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_ADF_PIPELINE_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <13-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_ADF_PIPELINE_CONTROL table>
-- =============================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_INSERT_ADF_PIPELINE_CONTROL]
@JOB_ID int,
@Parent_Pipeline_Text varchar(100),
@ChildPipeline_Text varchar(100),
@IS_Active_Flag char(1),
@Description_Text varchar(500),
@Update_GMT_Timestamp datetime,
@Update_Maintenance_System_Domain_Account_Name varchar(1000)

AS
BEGIN
SET NOCOUNT ON

if not exists (select JOB_ID from ABCR_CONTROL.VW_job_orchestration_master Where JOB_ID=@JOB_ID)
	Begin
		Throw 51000, 'JOB_ID is not available with the details. Please recheck the JOB_ID',16
	End

Else 

/* If @JOB_ID<100000001 OR @JOB_ID>999999999
			Begin
				THROW 51000, 'JOB_ID is out of range',1
			End
Else */

		Begin
			Insert into ABCR_CONTROL.VW_adf_pipeline_control(JOB_ID,Parent_Pipeline_Text,ChildPipeline_Text,IS_Active_Flag,Description_Text,Insert_GMT_Timestamp,Update_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name)
			Values (@JOB_ID,@Parent_Pipeline_Text,@ChildPipeline_Text,@IS_Active_Flag,@Description_Text,CURRENT_TIMESTAMP,@Update_GMT_Timestamp,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name)
		End

			Begin
				Select * from ABCR_CONTROL.VW_adf_pipeline_control Where JOB_ID=@JOB_ID
			End
End



