-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_UOW_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data into ABCR_CONTROL.VW_UOW_CONTROL table>
-- =============================================
CREATE  procedure [ABCR_CONTROL].[USP_INSERT_UOW_CONTROL]
@TENANT_ID int,
@BOW_ID int,
@SBOW_ID int,
@UOW_NAME varchar (1000),
@IS_ACTIVE_FLAG char(1),
@UOW_Description varchar (1000),
@retry_on_error_flag char (1),
@severity_number int,
@raise_ticket_flag int,
@impact_number int,
@Is_Reprocess_Flag char (1),
@Update_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_GMT_Timestamp datetime,
@UOW_CODE varchar(20)

AS
BEGIN
SET NOCOUNT ON

Declare @UOW_ID BIGINT
Declare @Max_UOW_ID Bigint
Declare @Char_ID Char(5)

Select @Max_UOW_ID=MAX(UOW_PART_ID) From ABCR_CONTROL.VW_UOW_CONTROL Where BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID


	Begin
		If @Max_UOW_ID IS NULL
			Select @UOW_ID=1	

		Else
			if @Max_UOW_ID IS NOT NULL
				Select @UOW_ID=(@Max_UOW_ID)+1
	END
		
		If LEN(@UOW_ID)=1
		Begin
			Set @Char_ID='0000'+Cast(@UOW_ID as char(1))
			Select @UOW_ID=Cast(Concat(@SBOW_ID,@Char_ID)as Bigint)
		End

		Else if	LEN(@UOW_ID)=2
			Begin
				Set @Char_ID='000'+Cast(@UOW_ID as char(2))
				Select @UOW_ID=Cast(Concat(@SBOW_ID,@Char_ID)as Bigint)
			END

		Else if	LEN(@UOW_ID)=3
			Begin
				Set @Char_ID='00'+Cast(@UOW_ID as char(3))
				Select @UOW_ID=Cast(Concat(@SBOW_ID,@Char_ID)as Bigint)
			End

		Else if	LEN(@UOW_ID)=4
			Begin
				Set @Char_ID='0'+Cast(@UOW_ID as char(4))
				Select @UOW_ID=Cast(Concat(@SBOW_ID,@Char_ID)as Bigint)
			End

		Else if	LEN(@UOW_ID)=5
			Begin
				Set @Char_ID=Cast(@UOW_ID as char(5))
				Select @UOW_ID=Cast(Concat(@SBOW_ID,@Char_ID)as Bigint)
			End
		
	If @Max_UOW_ID<1 OR @Max_UOW_ID>=99999

		Begin
			THROW 51000, 'UOW_ID is out of range',1
		END
	
		Else

		Begin
			Insert into ABCR_CONTROL.VW_UOW_CONTROL (TENANT_ID,BOW_ID,SBOW_ID,UOW_ID,UOW_NAME,IS_ACTIVE_FLAG,UOW_Description,retry_on_error_flag,severity_number,raise_ticket_flag,impact_number,Is_Reprocess_Flag,Insert_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,UOW_CODE)
			Values (@TENANT_ID,@BOW_ID,@SBOW_ID,@UOW_ID,@UOW_NAME,@IS_ACTIVE_FLAG,@UOW_Description,@retry_on_error_flag,@severity_number,@raise_ticket_flag,@impact_number,@Is_Reprocess_Flag,CURRENT_TIMESTAMP,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name,@Update_GMT_Timestamp,@UOW_CODE)
		End

			Begin
				Select * From ABCR_CONTROL.VW_UOW_CONTROL Where UOW_ID=@UOW_ID 
			End

End



