-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_BOW_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data into ABCR_CONTROL.VW_BOW_CONTROL table>
-- =============================================

Create   procedure [ABCR_CONTROL].[USP_INSERT_BOW_CONTROL]
@TENANT_ID INT,
@BOW_NAME VARCHAR(1000),
@SRC_SYSTEM_ID VARCHAR(50),
@EMAIL	VARCHAR(1000),
@IS_ACTIVE_FLAG CHAR(1),
@BOW_Source_Description_TEXT	VARCHAR(500),
@severity_number INT,
@raise_ticket_flag TINYINT,
@impact_number INT,
@Update_Maintenance_System_Domain_Account_Name VARCHAR(1000),
@Update_GMT_Timestamp DATETIME,
@BOW_CODE VARCHAR(10)

AS
BEGIN
SET NOCOUNT ON

Declare @BOW_ID INT
Declare @Max_BOW_ID Int
Declare @Char_ID Char(3)

Select @Max_BOW_ID=MAX(BOW_PART_ID) From ABCR_CONTROL.VW_BOW_CONTROL Where TENANT_ID=@TENANT_ID

	Begin
		If @Max_BOW_ID IS NULL
		Select @BOW_ID=Cast(Concat(@TENANT_ID,'001') as Int)
	End

		If	@Max_BOW_ID IS NOT NULL AND Len(@Max_BOW_ID+1)=1
			Begin
				Set @Char_ID='00'+Cast((@Max_BOW_ID+1) as char(1))
				Select @BOW_ID=Cast(Concat(@TENANT_ID,@Char_ID)as int)
			End

		Else if	@Max_BOW_ID IS NOT NULL AND Len(@Max_BOW_ID+1)=2
			Begin
				Set @Char_ID='0'+Cast((@Max_BOW_ID+1) as char(2))
				Select @BOW_ID=Cast(Concat(@TENANT_ID,@Char_ID)as int)
			End
		Else if	@Max_BOW_ID IS NOT NULL AND Len(@Max_BOW_ID+1)=3
			Begin
				Set @Char_ID=Cast((@Max_BOW_ID+1) as char(3))
				Select @BOW_ID=Cast(Concat(@TENANT_ID,@Char_ID)as int)
			End
	
		
		If @Max_BOW_ID<1 OR @Max_BOW_ID>=999
			Begin
				THROW 51000, 'BOW_ID is out of range',1
			End
			
		Else

		Begin
			Insert into ABCR_CONTROL.VW_BOW_CONTROL (TENANT_ID,BOW_ID,BOW_NAME,SRC_SYSTEM_ID,EMAIL,IS_ACTIVE_FLAG,BOW_Source_Description_TEXT,Insert_GMT_Timestamp,severity_number,raise_ticket_flag,impact_number,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,BOW_CODE)
			Values (@TENANT_ID,@BOW_ID,@BOW_NAME,@SRC_SYSTEM_ID,@EMAIL,@IS_ACTIVE_FLAG,@BOW_Source_Description_TEXT,CURRENT_TIMESTAMP,@severity_number,@raise_ticket_flag,@impact_number,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name,@Update_GMT_Timestamp,@BOW_CODE)
		End

			Begin
				Select * From ABCR_CONTROL.VW_BOW_CONTROL Where BOW_ID=@BOW_ID
			End

End
GO


