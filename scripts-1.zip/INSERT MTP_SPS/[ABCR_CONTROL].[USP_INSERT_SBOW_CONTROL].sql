-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_SBOW_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <07-09-2022>
-- Description: <Inserting data into ABCR_CONTROL.VW_SBOW_CONTROL table>
-- =============================================

CREATE  procedure [ABCR_CONTROL].[USP_INSERT_SBOW_CONTROL]
@TENANT_ID int,
@BOW_ID int,
@LAYER_CODE char(3),
@SBOW_NAME varchar(1000),
@CDC_START_TIMESTAMP datetime,		
@CDC_END_TIMESTAMP	datetime,
@EMAIL varchar (1000),
@IS_ACTIVE_FLAG char(1),
@SEQUENCE_ID int,
@SBOW_DESCRIPTION varchar (1000),
@Update_Maintenance_System_Domain_Account_Name varchar (1000),
@Update_GMT_Timestamp DATETIME2,
@SBOW_CODE varchar (10)

AS
BEGIN
SET NOCOUNT ON

Declare @SBOW_ID INT
Declare @Max_SBOW_ID Int
Declare @Char_ID Char(2)

Select @Max_SBOW_ID=MAX(SBOW_PART_ID) From ABCR_CONTROL.VW_SBOW_CONTROL Where BOW_ID=@BOW_ID --AND TENANT_ID=@TENANT_ID

	Begin
		If @Max_SBOW_ID IS NULL
		Select @SBOW_ID=Cast(Concat(@BOW_ID,'01') as Int)
	END

	If @Max_SBOW_ID IS NOT NULL AND Len(@Max_SBOW_ID+1)=1
			Begin
				Set @Char_ID='0'+Cast((@Max_SBOW_ID+1) as char(1))
				Select @SBOW_ID=Cast(Concat(@BOW_ID,@Char_ID)as int)
			End

	Else If @Max_SBOW_ID IS NOT NULL AND Len(@Max_SBOW_ID+1)=2
			Begin
				Set @Char_ID=Cast((@Max_SBOW_ID+1) as char(2))
				Select @SBOW_ID=Cast(Concat(@BOW_ID,@Char_ID)as int)
			End

			
		If @Max_SBOW_ID<01 OR @Max_SBOW_ID>=99
			Begin
				THROW 51000, 'SBOW_ID is out of range',1
			END
	
		Else
			Begin
				Insert into ABCR_CONTROL.VW_SBOW_CONTROL (TENANT_ID,BOW_ID,SBOW_ID,LAYER_CODE,SBOW_NAME,CDC_START_TIMESTAMP,CDC_END_TIMESTAMP,EMAIL,IS_ACTIVE_FLAG,SEQUENCE_ID,SBOW_DESCRIPTION,Insert_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,SBOW_CODE)
				Values (@TENANT_ID,@BOW_ID,@SBOW_ID,@LAYER_CODE,@SBOW_NAME,@CDC_START_TIMESTAMP,@CDC_END_TIMESTAMP,@EMAIL,@IS_ACTIVE_FLAG,@SEQUENCE_ID,@SBOW_DESCRIPTION,CURRENT_TIMESTAMP,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name,@Update_GMT_Timestamp,@SBOW_CODE)
			End

				Begin
					Select * From ABCR_CONTROL.VW_SBOW_CONTROL Where SBOW_ID=@SBOW_ID
				End

End


