-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_INSERT_LOG_HEADER>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data with SP into ABCR_AUDIT.VW_LOG_HEADER table>
-- =============================================

CREATE PROCEDURE [ABCR_AUDIT].[USP_INSERT_LOG_HEADER]
@Tenant_ID int,
@Log_Header_ID int,
@BOW_ID int,
@UOW_ID bigint,
@Batch_Execution_ID varchar(50),
@Status_Flag char(1),
@Execution_Start_Time datetime2(7),
@Execution_End_Time datetime2(7),
@Edl_Validation_Flag char(1),
@Adls_Validation_Flag char(1),
@SBOW_ID int,
@Change_Data_Capture_Start_Timestamp datetime2(7),
@Change_Data_Capture_End_Timestamp datetime2(7),
@Job_Execution_id varchar(500),
@Job_Id int,
@Source_Total_Record_Count bigint,
@Target_Total_Record_Count bigint

AS
BEGIN
SET NOCOUNT ON

if not exists (select UOW_ID from ABCR_CONTROL.VW_UOW_CONTROL Where UOW_ID=@UOW_ID AND SBOW_ID=@SBOW_ID AND BOW_ID=@BOW_ID AND TENANT_ID=@Tenant_ID)
	Begin
		Throw 51000, 'UOW_ID is not available in UOW_CONTROL Table. Please recheck UOW_ID',16
	End

Else 

	Begin
		Insert into ABCR_AUDIT.VW_LOG_HEADER (Tenant_ID,Log_Header_ID,BOW_ID,UOW_ID,Batch_Execution_ID,Status_Flag,Execution_Start_Time,Execution_End_Time,Edl_Validation_Flag,Adls_Validation_Flag,SBOW_ID,Change_Data_Capture_Start_Timestamp,Change_Data_Capture_End_Timestamp,Job_Execution_id,Job_Id,Source_Total_Record_Count,Target_Total_Record_Count)
		Values (@Tenant_ID,@Log_Header_ID,@BOW_ID,@UOW_ID,@Batch_Execution_ID,@Status_Flag,@Execution_Start_Time,@Execution_End_Time,@Edl_Validation_Flag,@Adls_Validation_Flag,@SBOW_ID,@Change_Data_Capture_Start_Timestamp,@Change_Data_Capture_End_Timestamp,@Job_Execution_id,@Job_Id,@Source_Total_Record_Count,@Target_Total_Record_Count)
	End

		Begin
			Select * from ABCR_AUDIT.VW_LOG_HEADER Where Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		End

END



