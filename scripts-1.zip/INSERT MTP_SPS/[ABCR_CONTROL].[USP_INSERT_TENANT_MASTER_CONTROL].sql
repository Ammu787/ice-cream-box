-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_TENANT_MASTER_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data into ABCR_CONTROL.VW_TENANT_MASTER_CONTROL table>
-- =======================================================

CREATE procedure [ABCR_CONTROL].[USP_INSERT_TENANT_MASTER_CONTROL]
@Insert_Mode varchar(10) NULL,
@Tenant_Code char(10) NULL,
@Tenant_Name_Text varchar(1000),
@Tech_Lead_Text	varchar(1000),
@Tech_Manager_Text varchar(1000),
@Support_Team_Text varchar(1000),
@Project_Description_Text varchar (1000),
@Tenancy_Start_Date datetime,
@Tenancy_End_Date datetime,
@Is_Active_Flag char(1),
@Update_Maintenance_System_Domain_Account_Name varchar(1000),
@Update_GMT_Timestamp datetime

AS
BEGIN
SET NOCOUNT ON

Declare @Tenant_ID Int
Declare @Max_Tenant_Id Int

SET @Insert_Mode=UPPER(@Insert_Mode)
If @Insert_Mode='SYMPHONY'
	Begin
		Select @Max_Tenant_Id=MAX(Tenant_ID) From ABCR_CONTROL.TENANT_MASTER_CONTROL where Tenant_ID >= 500
		 If @Max_Tenant_Id<500 OR @Max_Tenant_Id>999
					Begin
						Raiserror ('Selected Tenant_ID is out of range for Symphony Insert mode',16,1)						
					End 
	
			If @Max_Tenant_Id IS NULL
				Select @Tenant_ID=500

			Else if
			@Max_Tenant_Id IS NOT NULL
				Select @Tenant_ID=(@Max_Tenant_Id)+1
			
End

Else 
	Begin
		Select @Max_Tenant_Id=MAX(Tenant_ID) From ABCR_CONTROL.TENANT_MASTER_CONTROL  where Tenant_ID < 500
		If @Max_Tenant_Id<100 OR @Max_Tenant_Id>499
				Begin
					Raiserror ('Selected Tenant_ID is out of range for Selected Insert mode',16,1)
				End
			
			If @Max_Tenant_Id IS NULL
				Select @Tenant_ID=100

			Else if
				@Max_Tenant_Id IS NOT NULL
					Select @Tenant_ID=(@Max_Tenant_Id)+1
			
	End

			Begin
				Insert into ABCR_CONTROL.VW_TENANT_MASTER_CONTROL (Tenant_ID,Tenant_Code,Tenant_Name_Text,Tech_Lead_Text,Tech_Manager_Text,Support_Team_Text,Project_Description_Text,Tenancy_Start_Date,Tenancy_End_Date,Is_Active_Flag,Insert_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp)
				Values (@Tenant_ID,@Tenant_Code,@Tenant_Name_Text,@Tech_Lead_Text,@Tech_Manager_Text,@Support_Team_Text,@Project_Description_Text,@Tenancy_Start_Date,@Tenancy_End_Date,@Is_Active_Flag,CURRENT_TIMESTAMP,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name,@Update_GMT_Timestamp)
			End

			Begin
				Select * From ABCR_CONTROL.VW_TENANT_MASTER_CONTROL Where Tenant_ID=@Tenant_ID
			End
End



