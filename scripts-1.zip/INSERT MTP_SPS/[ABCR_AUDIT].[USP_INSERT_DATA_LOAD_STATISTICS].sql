-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_INSERT_DATA_LOAD_STATISTICS>
-- Author:      <Chiranjeevi>
-- Create Date: <23-09-2022>
-- Description: <Inserting data with SP into ABCR_AUDIT.VW_DATA_LOAD_STATISTICS table>
-- =============================================

CREATE  PROCEDURE [ABCR_AUDIT].[USP_INSERT_DATA_LOAD_STATISTICS]
@BOW_Id int,
@SBOW_Id int,
@UOW_Id bigint,
@Job_Start_Time datetime,
@Job_End_Time datetime,
@ProcessID varchar(500),
@Git_Project_Name varchar(500),
@Job_Name varchar(1000),
@Job_Repository_Id varchar(1000),
@Job_Version varchar(1000),
@Job_Used_Context varchar(500),
@Component_Name varchar(500),
@Stats_Capture_At varchar(500),
@Job_Status varchar(500),
@Job_Execution_Duration bigint,
@Error_Type varchar(500),
@Error_Code int,
@Error_Message nvarchar(4000),
@HPSM_Ticket_Status varchar(250)

AS
BEGIN
SET NOCOUNT ON

	Begin
		Insert into ABCR_AUDIT.VW_DATA_LOAD_STATISTICS (BOW_Id,SBOW_Id,UOW_Id,Job_Start_Time,Job_End_Time,ProcessID,Git_Project_Name,Job_Name,Job_Repository_Id,Job_Version,Job_Used_Context,Component_Name,Stats_Capture_At,Job_Status,Job_Execution_Duration,Error_Type,Error_Code,Error_Message,HPSM_Ticket_Status)
		Values	(@BOW_Id,@SBOW_Id,@UOW_Id,@Job_Start_Time,@Job_End_Time,@ProcessID,@Git_Project_Name,@Job_Name,@Job_Repository_Id,@Job_Version,@Job_Used_Context,@Component_Name,@Stats_Capture_At,@Job_Status,@Job_Execution_Duration,@Error_Type,@Error_Code,@Error_Message,@HPSM_Ticket_Status)
	End
		Begin
			Select * from ABCR_AUDIT.VW_DATA_LOAD_STATISTICS Where BOW_Id=@BOW_Id AND SBOW_Id=@SBOW_Id AND UOW_Id=@UOW_Id
		End
END


