-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_ENTITY_MAPPING_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <23-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_ENTITY_MAPPING_CONTROL table>
-- =============================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_INSERT_ENTITY_MAPPING_CONTROL]
@Tenant_ID int,
@BOW_ID int,
@SBOW_ID int,
@UOW_ID bigint,
@Parent_UOW_ID bigint,
@IS_ACTIVE char(1),
@Update_Maintenance_System_Domain_Account_Name varchar(1000),
@Update_GMT_Timestamp datetime

AS
BEGIN
SET NOCOUNT ON

if not exists (select * from ABCR_CONTROL.VW_UOW_CONTROL Where UOW_ID=@UOW_ID AND TENANT_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID)
	Begin
		Throw 51000, 'UOW_ID is not available in UOW_CONTROL Table. Please recheck UOW_ID',16
	End

Else 

	Begin
		Insert into ABCR_CONTROL.VW_Entity_Mapping_Control(Tenant_ID,BOW_ID,SBOW_ID,UOW_ID,Parent_UOW_ID,IS_ACTIVE,Insert_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp)
		Values (@Tenant_ID,@BOW_ID,@SBOW_ID,@UOW_ID,@Parent_UOW_ID,@IS_ACTIVE,CURRENT_TIMESTAMP,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name,@Update_GMT_Timestamp)
	End

		Begin
			Select * from ABCR_CONTROL.VW_Entity_Mapping_Control Where Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		End
End



