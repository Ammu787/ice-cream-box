-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_UOW_CONFIGURATION_VALUES>
-- Author:      <Chiranjeevi>
-- Create Date: <13-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_UOW_CONFIGURATION_VALUES table>
-- =============================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_INSERT_UOW_CONFIGURATION_VALUES]
@BOW_ID int,
@SBOW_ID int,
@UOW_ID bigint,
@Config_Key_Text varchar(200),
@Config_Value_Text varchar(4000),
@IS_Active_Flag char(1),
@Update_GMT_Timestamp datetime,
@Update_Maintenance_System_Domain_Account_Name varchar(1000)

AS
BEGIN
SET NOCOUNT ON


if not exists (select * from ABCR_CONTROL.VW_UOW_CONTROL Where UOW_ID=@UOW_ID)
	Begin
		Throw 51000, 'UOW_ID is not available in UOW_CONTROL Table. Please recheck UOW_ID',16
	End

Else 

		Begin
			Insert into ABCR_CONTROL.VW_UOW_Configuration_Values (BOW_ID,SBOW_ID,UOW_ID,Config_Key_Text,Config_Value_Text,IS_Active_Flag,Insert_GMT_Timestamp,Update_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name)
			Values (@BOW_ID,@SBOW_ID,@UOW_ID,@Config_Key_Text,@Config_Value_Text,@IS_Active_Flag,CURRENT_TIMESTAMP,@Update_GMT_Timestamp,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name)
		End
			Begin
				Select * from ABCR_CONTROL.VW_UOW_Configuration_Values Where BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
			End

	END



