-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_UOW_UOW_SECURITY_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_UOW_UOW_SECURITY_CONTROL table>
-- ======================================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_INSERT_UOW_SECURITY_CONTROL]
@Tenant_ID int,
@BOW_ID int,
@SBOW_ID int,
@UOW_ID bigint,
@SEC_TYPE varchar(50),
@Role varchar(50),
@Columns varchar(max),
@is_encrypted char(1),
@location char(15),
@Path varchar(250),
@Updated_By_Name varchar(100),
@updated_DateTime datetime2(7)


AS
BEGIN
SET NOCOUNT ON


if not exists (select UOW_ID from  ABCR_CONTROL.VW_UOW_CONTROL Where @Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID)
    Begin
        Throw 51000, 'UOW_ID is not available in UOW_CONTROL Table. Please recheck UOW_ID',16
    End

Else

	   Begin
			Insert into  ABCR_CONTROL.VW_UOW_Security_Control (Tenant_ID,BOW_ID,SBOW_ID,UOW_ID,SEC_TYPE,Role,Columns,is_encrypted,location,Path,Inserted_By_Name,Inserted_DateTime,Updated_By_Name,updated_DateTime)
			VALUES (@Tenant_ID,@BOW_ID,@SBOW_ID,@UOW_ID,@SEC_TYPE,@Role,@Columns,@is_encrypted,@location,@Path,SYSTEM_USER,CURRENT_TIMESTAMP,@Updated_By_Name,@updated_DateTime)

	   End

		  Begin
				Select * from ABCR_CONTROL.VW_UOW_Security_Control Where Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
			End
END



