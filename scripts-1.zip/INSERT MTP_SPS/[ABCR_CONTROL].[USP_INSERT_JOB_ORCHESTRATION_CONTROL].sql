-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_JOB_ORCHESTRATION_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_JOB_ORCHESTRATION_CONTROL table>
-- =============================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_INSERT_JOB_ORCHESTRATION_CONTROL]
@JOB_ID int,
@TENANT_ID int,
@BOW_ID int,
@SBOW_ID int,
@UOW_ID bigint,
@Seq_ID int,
@IS_Active_Flag char(1),
@Update_Maintenance_System_Domain_Account_Name varchar(100),
@Update_GMT_Timestamp datetime,
@Wait_Time_In_Min int,
@Job_Params Varchar(1000)

AS 
BEGIN
SET NOCOUNT ON

if not exists (select JOB_ID from ABCR_CONTROL.VW_job_orchestration_master Where JOB_ID=@JOB_ID)
	Begin
		Throw 51000, 'JOB_ID is not available with the details. Please recheck the JOB_ID',1
	End

Else 

If @JOB_ID<100000001 OR @JOB_ID>999999999
			Begin
				THROW 51000, 'JOB_ID is out of range',1
			End
Else

if not exists (select * from ABCR_CONTROL.VW_UOW_CONTROL Where UOW_ID=@UOW_ID AND SBOW_ID=@SBOW_ID AND BOW_ID=@BOW_ID)
	Begin
		Throw 51000, 'UOW_ID is not available with the details. Please recheck the UOW_ID',16
	End
	
Else 

		Begin
			Insert into ABCR_CONTROL.VW_Job_orchestration_control(JOB_ID,TENANT_ID,BOW_ID,SBOW_ID,UOW_ID,Seq_ID,IS_Active_Flag,Insert_Maintenance_System_Domain_Account_Name,Insert_GMT_Timestamp,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp,Wait_Time_In_Min,Job_Params)
			Values (@JOB_ID,@TENANT_ID,@BOW_ID,@SBOW_ID,@UOW_ID,@Seq_ID,@IS_Active_Flag,SYSTEM_USER,CURRENT_TIMESTAMP,@Update_Maintenance_System_Domain_Account_Name,@Update_GMT_Timestamp,@Wait_Time_In_Min,@Job_Params)
		End

			Begin
				Select * from ABCR_CONTROL.VW_Job_orchestration_control Where TENANT_ID=@TENANT_ID AND JOB_ID=@JOB_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
			End
End



