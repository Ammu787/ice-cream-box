-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_JOB_ORCHESTRATION_MASTER>
-- Author:      <Chiranjeevi>
-- Create Date: <13-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_JOB_ORCHESTRATION_MASTER table>
-- =============================================

CREATE  PROCEDURE [ABCR_CONTROL].[USP_INSERT_JOB_ORCHESTRATION_MASTER]
@TENANT_ID int,
@Job_Name_Text varchar(200),
@Job_Description_Text varchar(200),
@IS_Active_Flag char(1),
@JOB_EXECUTION_TIME datetime,
@UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME varchar(200),
@UPDATE_GMT_TIMESTAMP datetime,
@Spark_Cluster_Size_Text varchar(100),
@Tool_ID_Text varchar(20)

AS 
BEGIN
SET NOCOUNT ON

Declare @JOB_ID int
Declare @MAX_JOB_PART_ID Int
Declare @Char_Id Char(6)

Select @MAX_JOB_PART_ID=Max(JOB_PART_ID) from ABCR_CONTROL.VW_job_orchestration_master where TENANT_ID=@TENANT_ID

If @MAX_JOB_PART_ID Is Null
	Begin
		Select @JOB_ID=Cast(Concat(@TENANT_ID,'000001')as Int)
	End

	Else if @MAX_JOB_PART_ID Is Not Null AND LEN(@MAX_JOB_PART_ID+1)=1
		Begin
			Set @Char_Id='00000'+Cast((@MAX_JOB_PART_ID+1) as Char(1))
			Select @JOB_ID=Cast(Concat(@TENANT_ID,@Char_Id)as Int)
		End
	Else if @MAX_JOB_PART_ID Is Not Null AND LEN(@MAX_JOB_PART_ID+1)=2
		Begin
			Set @Char_Id='0000'+Cast((@MAX_JOB_PART_ID+1) as Char(2))
			Select @JOB_ID=Cast(Concat(@TENANT_ID,@Char_Id)as Int)
		End
	Else if @MAX_JOB_PART_ID Is Not Null AND LEN(@MAX_JOB_PART_ID+1)=3
		Begin
			Set @Char_Id='000'+Cast((@MAX_JOB_PART_ID+1) as Char(3))
			Select @JOB_ID=Cast(Concat(@TENANT_ID,@Char_Id)as Int)
		End
	Else if @MAX_JOB_PART_ID Is Not Null AND LEN(@MAX_JOB_PART_ID+1)=4
		Begin
			Set @Char_Id='00'+Cast((@MAX_JOB_PART_ID+1) as Char(4))
			Select @JOB_ID=Cast(Concat(@TENANT_ID,@Char_Id)as Int)
		End
	Else if @MAX_JOB_PART_ID Is Not Null AND LEN(@MAX_JOB_PART_ID+1)=5
		Begin
			Set @Char_Id='0'+Cast((@MAX_JOB_PART_ID+1) as Char(5))
			Select @JOB_ID=Cast(Concat(@TENANT_ID,@Char_Id)as Int)
		End
	Else if @MAX_JOB_PART_ID Is Not Null AND LEN(@MAX_JOB_PART_ID+1)=6
		Begin
			Set @Char_Id=Cast((@MAX_JOB_PART_ID+1) as Char(6))
			Select @JOB_ID=Cast(Concat(@TENANT_ID,@Char_Id)as Int)
		End

		If @MAX_JOB_PART_ID<1 OR @MAX_JOB_PART_ID>999999
			Begin
				THROW 51000, 'JOB_ID is out of range',1
			End

	Else
			Begin
				Insert into ABCR_CONTROL.VW_job_orchestration_master(TENANT_ID,JOB_ID,Job_Name_Text,Job_Description_Text,IS_Active_Flag,JOB_EXECUTION_TIME,INSERT_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME,INSERT_GMT_TIMESTAMP,UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME,UPDATE_GMT_TIMESTAMP,Spark_Cluster_Size_Text,Tool_ID_Text)
				Values (@TENANT_ID,@JOB_ID,@Job_Name_Text,@Job_Description_Text,@IS_Active_Flag,@JOB_EXECUTION_TIME,SYSTEM_USER,CURRENT_TIMESTAMP,@UPDATE_MAINTENANCE_SYSTEM_DOMAIN_ACCOUNT_NAME,@UPDATE_GMT_TIMESTAMP,@Spark_Cluster_Size_Text,@Tool_ID_Text)
			End
				Begin
					Select * From ABCR_CONTROL.VW_job_orchestration_master Where JOB_ID=@JOB_ID
				End
END



