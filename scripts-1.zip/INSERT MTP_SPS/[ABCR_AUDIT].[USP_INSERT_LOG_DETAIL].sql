-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_INSERT_LOG_DETAIL>
-- Author:      <Chiranjeevi>
-- Create Date: <13-09-2022>
-- Description: <Inserting data with SP into ABCR_AUDIT.VW_LOG_DETAIL table>
-- ======================================================

CREATE  PROCEDURE [ABCR_AUDIT].[USP_INSERT_LOG_DETAIL]
@Tenant_ID int,
@Log_Header_ID int,
@Log_Detail_ID int,
@BOW_ID int,
@UOW_ID bigint,
@Stage_ID int,
@Batch_Execution_ID varchar(500),
@Batch_ID bigint,
@Status_Flag char(1),
@Start_Part_Number int,
@End_Part_Number int,
@Execution_Start_Time datetime2(7),
@Execution_End_Time datetime2(7),
@Landing_Record_Count bigint,
@History_Total_Record_Count bigint,
@Total_Partitions_Count int,
@Total_Files_Count int,
@File_Name_Processed varchar(100),
@Task_ID int,
@Inserted_Record_Count bigint,
@Updated_Record_Count bigint,
@Deleted_Record_Count bigint,
@Fedllc_Record_Count bigint,
@Fed_Inserted_Record_Count bigint,
@Fed_Updated_Record_Count bigint,
@Fed_Deleted_Record_Count bigint

AS
BEGIN
SET NOCOUNT ON


if not exists (select UOW_ID from ABCR_CONTROL.VW_UOW_CONTROL Where UOW_ID=@UOW_ID AND BOW_ID=@BOW_ID AND TENANT_ID=@Tenant_ID)
	Begin
		Throw 51000, 'UOW_ID is not available in UOW_CONTROL Table. Please recheck UOW_ID',16
	End

Else 

	Begin
		Insert into ABCR_AUDIT.VW_LOG_DETAIL (Tenant_ID,Log_Header_ID,Log_Detail_ID,BOW_ID,UOW_ID,Stage_ID,Batch_Execution_ID,Batch_ID,Status_Flag,Start_Part_Number,End_Part_Number,Execution_Start_Time,Execution_End_Time,Landing_Record_Count,History_Total_Record_Count,Total_Partitions_Count,Total_Files_Count,File_Name_Processed,Task_ID,Inserted_Record_Count,Updated_Record_Count,Deleted_Record_Count,Fedllc_Record_Count,Fed_Inserted_Record_Count,Fed_Updated_Record_Count,Fed_Deleted_Record_Count)
		Values (@Tenant_ID,@Log_Header_ID,@Log_Detail_ID,@BOW_ID,@UOW_ID,@Stage_ID,@Batch_Execution_ID,@Batch_ID,@Status_Flag,@Start_Part_Number,@End_Part_Number,@Execution_Start_Time,@Execution_End_Time,@Landing_Record_Count,@History_Total_Record_Count,@Total_Partitions_Count,@Total_Files_Count,@File_Name_Processed,@Task_ID,@Inserted_Record_Count,@Updated_Record_Count,@Deleted_Record_Count,@Fedllc_Record_Count,@Fed_Inserted_Record_Count,@Fed_Updated_Record_Count,@Fed_Deleted_Record_Count)
	End

		Begin
			Select * from ABCR_AUDIT.VW_LOG_DETAIL Where Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND UOW_ID=@UOW_ID
		End
END


