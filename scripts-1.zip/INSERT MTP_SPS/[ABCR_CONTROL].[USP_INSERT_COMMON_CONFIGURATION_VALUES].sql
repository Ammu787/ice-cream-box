-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_COMMON_CONFIGURATION_VALUES>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_COMMON_CONFIGURATION_VALUES table>
-- =============================================

CREATE  PROCEDURE [ABCR_CONTROL].[USP_INSERT_COMMON_CONFIGURATION_VALUES]
@Config_Key_Text varchar(900),
@Config_Value_Text varchar(500),
@IS_Active_Flag char(1),
@Config_Group_Text varchar(200),
@Description_Text varchar(200),
@Update_GMT_Timestamp datetime,
@Update_Maintenance_System_Domain_Account_Name varchar(200)

AS
BEGIN
SET NOCOUNT ON

	BEGIN
		INSERT INTO  ABCR_CONTROL.VW_common_configuration_values (Config_Key_Text,Config_Value_Text,IS_Active_Flag,Config_Group_Text,Description_Text,Insert_GMT_Timestamp,Update_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name)
		VALUES (@Config_Key_Text,@Config_Value_Text,@IS_Active_Flag,@Config_Group_Text,@Description_Text,CURRENT_TIMESTAMP,@Update_GMT_Timestamp,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name)
	END
		BEGIN
			SELECT * FROM ABCR_CONTROL.VW_common_configuration_values WHERE Config_Key_Text=@Config_Key_Text AND Config_Value_Text=@Config_Value_Text
		END

END



