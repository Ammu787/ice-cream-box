-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_INSERT_ETL_JOB_STATUS>
-- Author:      <Chiranjeevi>
-- Create Date: <13-09-2022>
-- Description: <Inserting data with SP into ABCR_AUDIT.USP_ETL_JOB_STATUS table>
-- =============================================

CREATE  PROCEDURE [ABCR_AUDIT].[USP_INSERT_ETL_JOB_STATUS]
@OBJECT varchar(100),
@ETL_JOB_START_TIMESTAMP datetime,
@ETL_JOB_END_TIMESTAMP datetime,
@UPDATE_DATE datetime,
@NOTES1 varchar(500)

AS 
BEGIN
SET NOCOUNT ON

	BEGIN
		Insert into ABCR_AUDIT.VW_ETL_JOB_STATUS (OBJECT,ETL_JOB_START_TIMESTAMP,ETL_JOB_END_TIMESTAMP,UPDATE_DATE,NOTES1)
		Values (@OBJECT,@ETL_JOB_START_TIMESTAMP,@ETL_JOB_END_TIMESTAMP,@UPDATE_DATE,@NOTES1)
	END
		BEGIN
			Select * from ABCR_AUDIT.VW_ETL_JOB_STATUS Where OBJECT=@OBJECT
		END
END



