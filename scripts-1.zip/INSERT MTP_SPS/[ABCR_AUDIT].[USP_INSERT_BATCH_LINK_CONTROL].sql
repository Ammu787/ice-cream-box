-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_INSERT_BATCH_LINK_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <16-09-2022>
-- Description: <Inserting data with SP into ABCR_AUDIT.VW_BATCH_LINK_CONTROL table>
-- =============================================

CREATE  PROCEDURE [ABCR_AUDIT].[USP_INSERT_BATCH_LINK_CONTROL]
@Tenant_id int NULL,
@bow_id int NULL,
@sbow_id int NULL,
@uow_id bigint,
@src_batch_exec_id varchar(max) NULL,
@tgt_batch_exec_id varchar(max) NULL

AS
BEGIN
SET NOCOUNT ON

if not exists (select UOW_ID from ABCR_CONTROL.VW_UOW_CONTROL Where UOW_ID=@uow_id AND SBOW_ID=@sbow_id AND BOW_ID=@bow_id AND TENANT_ID=@Tenant_id)
	Begin
		Throw 51000, 'UOW_ID is not available in UOW_CONTROL Table. Please recheck UOW_ID',16
	End

Else 

	Begin
		Insert into ABCR_AUDIT.VW_batch_link_control(Tenant_id,bow_id,sbow_id,uow_id,src_batch_exec_id,tgt_batch_exec_id)
		Values (@Tenant_id,@bow_id,@sbow_id,@uow_id,@src_batch_exec_id,@tgt_batch_exec_id)
	End

		Begin
			Select * from ABCR_AUDIT.VW_batch_link_control Where Tenant_id=@Tenant_id AND bow_id=@bow_id AND sbow_id=@sbow_id AND uow_id=@uow_id
		End
END


