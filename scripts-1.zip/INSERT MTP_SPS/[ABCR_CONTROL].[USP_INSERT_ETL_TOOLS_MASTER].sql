-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_ETL_TOOLS_MASTER>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_ETL_TOOLS_MASTER table>
-- =======================================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_INSERT_ETL_TOOLS_MASTER]
@Tool_ID_Text varchar(20),
@TOOL_NAME varchar(200),
@IS_ACTIVE_FLAG char(1),
@Update_GMT_Timestamp datetime,
@Update_Maintenance_System_Domain_Account_Name varchar(1000)

AS
BEGIN
SET NOCOUNT ON


BEGIN
        INSERT INTO ABCR_CONTROL.VW_ETL_TOOLS_MASTER (Tool_ID_Text,TOOL_NAME,IS_ACTIVE_FLAG,Insert_GMT_Timestamp,Update_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name)
        Values (@Tool_ID_Text,@TOOL_NAME,@IS_ACTIVE_FLAG,CURRENT_TIMESTAMP,@Update_GMT_Timestamp,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name)
    END
    
        BEGIN
            SELECT * FROM ABCR_CONTROL.VW_ETL_TOOLS_MASTER WHERE Tool_ID_Text = @Tool_ID_Text
        END
END


