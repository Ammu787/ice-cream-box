-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_CONFIGURATION_KEYS>
-- Author:      <Chiranjeevi>
-- Create Date: <15-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.VW_CONFIGURATION_KEYS table>
-- =============================================

CREATE  PROCEDURE [ABCR_CONTROL].[USP_INSERT_CONFIGURATION_KEYS]
@Config_Key_Text varchar(900),
@Description_Text varchar(1000),
@IS_Active_Flag char(1),
@Update_GMT_Timestamp datetime,
@Update_Maintenance_System_Domain_Account_Name varchar(1000)

AS 
BEGIN
SET NOCOUNT ON
Declare @Config_ID Int,
@Max_Config_ID Int

Select @Max_Config_ID=Max(Config_ID) from ABCR_CONTROL.Configuration_Keys
Set @Config_ID= @Max_Config_ID+1

	BEGIN
		INSERT INTO ABCR_CONTROL.VW_Configuration_Keys (Config_ID,Config_Key_Text,Description_Text,IS_Active_Flag,Insert_GMT_Timestamp,Update_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name)
		Values (@Config_ID,@Config_Key_Text,@Description_Text,@IS_Active_Flag,CURRENT_TIMESTAMP,@Update_GMT_Timestamp,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name)
	END

		BEGIN
			SELECT * FROM ABCR_CONTROL.VW_Configuration_Keys WHERE Config_ID=@Config_ID AND Config_Key_Text=@Config_Key_Text
		END

END


