-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_INSERT_PROCESS_CONTROL>
-- Author:      <Chiranjeevi>
-- Create Date: <13-09-2022>
-- Description: <Inserting data with SP into ABCR_CONTROL.PROCESS_CONTROL table>
-- =============================================

CREATE PROCEDURE [ABCR_CONTROL].[USP_INSERT_PROCESS_CONTROL]
@Tenant_ID int,
@BOW_ID int,
@SBOW_ID int,
@UOW_ID bigint,
@Stage_ID int ,
@Task_ID int,
@Batch_ID int,
@Query_Type varchar(max),
@Query_Text varchar(max),
@Schema_ID bigint,
@SPARK_SETTINGS_TEXT varchar (Max),
@IS_ACTIVE_FLAG char(1),
@Source_Table_Name varchar(100),
@Target_Table_Name varchar(100),
@PARAMS_JSON_TEXT varchar(4000),
@Actions_Text varchar(MAX),
@Update_Maintenance_System_Domain_Account_Name varchar(1000),
@Update_GMT_Timestamp datetime

AS
BEGIN
SET NOCOUNT ON

if not exists (select UOW_ID from ABCR_CONTROL.VW_UOW_CONTROL Where UOW_ID=@UOW_ID AND SBOW_ID=@SBOW_ID AND BOW_ID=@BOW_ID AND TENANT_ID=@Tenant_ID)
	Begin
		Throw 51000, 'UOW_ID is not available in UOW_CONTROL Table. Please recheck UOW_ID & respective control IDs',16
	End

Else 
	
	Begin
		Insert into ABCR_CONTROL.VW_Process_Control (Tenant_ID,BOW_ID,SBOW_ID,UOW_ID,Stage_ID,Task_ID,Batch_ID,Query_Type,Query_Text,Schema_ID,SPARK_SETTINGS_TEXT,IS_ACTIVE_FLAG,Source_Table_Name,Target_Table_Name,PARAMS_JSON_TEXT,Actions_Text,Insert_GMT_Timestamp,Insert_Maintenance_System_Domain_Account_Name,Update_Maintenance_System_Domain_Account_Name,Update_GMT_Timestamp)
		Values (@Tenant_ID,@BOW_ID,@SBOW_ID,@UOW_ID,@Stage_ID,@Task_ID,@Batch_ID,@Query_Type,@Query_Text,@Schema_ID,@SPARK_SETTINGS_TEXT,@IS_ACTIVE_FLAG,@Source_Table_Name,@Target_Table_Name,@PARAMS_JSON_TEXT,@Actions_Text,CURRENT_TIMESTAMP,SYSTEM_USER,@Update_Maintenance_System_Domain_Account_Name,@Update_GMT_Timestamp)
	END

		Begin
			Select * from ABCR_CONTROL.VW_Process_Control Where Tenant_ID=@Tenant_ID AND BOW_ID=@BOW_ID AND SBOW_ID=@SBOW_ID AND UOW_ID=@UOW_ID
		End

END



