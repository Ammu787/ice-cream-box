-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<usp_insert_batch_link_control_table>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Inserting below log information into ABCR_AUDIT.VW_BATCH_LINK_CONTROL>
-- =============================================

CREATE   proc [ABCR_AUDIT].[usp_insert_batch_link_control_table]
@tenantid Int,
@bowid Bigint,
@sbowid Bigint,
@uowid bigint,
@load_jobs varchar(100),
@tgt_exec_id varchar(100)
As
Begin
select Column1 as loadjob into #temp1 from  dbo.usp_util_convertstrtorow (@load_jobs)
SELECT  distinct batch_id,Batch_Execution_ID into #temp2 FROM  ABCR_AUDIT.VW_LOG_DETAIL a, #temp1 b where a.batch_id = b.loadjob
insert into ABCR_AUDIT.VW_batch_link_control(Tenant_id,bow_id,sbow_id,uow_id,src_batch_exec_id,tgt_batch_exec_id)
                    (select @tenantid,@bowid,@sbowid,@uowid,Batch_Execution_ID,@tgt_exec_id from #temp2)
DROP TABLE #temp1;
DROP TABLE #temp2;
end



