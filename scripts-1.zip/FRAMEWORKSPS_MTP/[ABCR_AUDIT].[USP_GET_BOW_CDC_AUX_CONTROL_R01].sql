-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_GET_BOW_CDC_AUX_CONTROL_R01>
-- =======================================================

-- =======================================================
-- Author:      <Satya Bhargavi>  
-- Create Date: <23-08-2022>  
-- Description: <Used to get the details from ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL table>  
-- =======================================================

CREATE  PROCEDURE [ABCR_AUDIT].[USP_GET_BOW_CDC_AUX_CONTROL_R01]
  
@BOW_ID INT,  
@UOW_Unique_ID BIGINT  
AS                                                                                      
  SET NOCOUNT ON                                                                  
   BEGIN  
            select BOW_ID,UOW_ID as UOW_Unique_ID,'' as BOW_NAME,CDC_TYPE_DESCRIPTION,'' as CDC_START_TIMESTAMP,'' as CDC_END_TIMESTAMP,CHANGE_DATA_CAPTURE_START_TIMESTAMP,CHANGE_DATA_CAPTURE_END_TIMESTAMP,INSERT_GMT_TIMESTAMP from ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL WHERE BOW_ID=@BOW_ID AND UOW_ID=@UOW_Unique_ID
   END 



