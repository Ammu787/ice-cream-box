-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_GET_CHILD_PIPELINE_LIST>
-- =======================================================

-- =======================================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <To get list of child pipelines related to particular parent pipeline based on job id from ABCR_CONTROL.VW_adf_pipeline_control table>
-- =======================================================
																										
CREATE  PROCEDURE [ABCR_CONTROL].[USP_GET_CHILD_PIPELINE_LIST]
@JOB_ID INT  
AS  

	BEGIN  
		SELECT DISTINCT ChildPipeline_Text from ABCR_CONTROL.VW_adf_pipeline_control where JOB_ID = @JOB_ID and IS_Active_Flag = 'Y' 
	END



