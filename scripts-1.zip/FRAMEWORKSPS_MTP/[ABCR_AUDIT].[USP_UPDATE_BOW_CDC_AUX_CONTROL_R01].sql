-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_UPDATE_BOW_CDC_AUX_CONTROL_R01>
-- =======================================================
-- =======================================================
-- Author:      <Poojitha Voggu>
-- Create Date: <23-08-2022>
-- Description: <Using to update CHANGE_DATA_CAPTURE start & End timestamps in ABCR_AUDIT.BOW_CDC_AUX_CONTROL_R01 table>
-- =======================================================

CREATE   PROCEDURE [ABCR_AUDIT].[USP_UPDATE_BOW_CDC_AUX_CONTROL_R01]
@CHANGE_DATA_CAPTURE_START_TIMESTAMP [datetime2](7),  
@CHANGE_DATA_CAPTURE_END_TIMESTAMP [datetime2](7),  
@BOW_ID [bigint],  
@UOW_ID [bigint]

  
AS                                                                       
BEGIN 

SET NOCOUNT ON; 

   update ABCR_AUDIT.BOW_CDC_AUX_CONTROL_R01 set [CHANGE_DATA_CAPTURE_START_TIMESTAMP]=@CHANGE_DATA_CAPTURE_START_TIMESTAMP, [CHANGE_DATA_CAPTURE_END_TIMESTAMP]=@CHANGE_DATA_CAPTURE_END_TIMESTAMP where BOW_ID=@BOW_ID and UOW_ID=@UOW_ID  
   
End



