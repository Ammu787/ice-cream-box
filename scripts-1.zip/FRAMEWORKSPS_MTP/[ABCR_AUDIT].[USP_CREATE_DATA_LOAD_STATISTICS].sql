-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_CREATE_DATA_LOAD_STATISTICS>
-- =======================================================

-- =============================================  
-- Author:      <Nivedita Gaddale>  
-- Create Date: <23-09-2022>  
-- Description: <Updating the log information to ABCR_AUDIT.DATA_LOAD_STATISTICS table>  
-- =============================================  
  
CREATE  PROCEDURE [ABCR_AUDIT].[USP_CREATE_DATA_LOAD_STATISTICS]
@bow_Id int,    
@sbow_Id int,    
@uow_Id bigint,    
@Job_Start_Time datetime2(7),    
@Job_End_Time datetime2(7),    
@ProcessID VARCHAR(100),    
@Git_Project_Name VARCHAR(100),    
@Job_Name VARCHAR(100),    
@Job_Repository_Id VARCHAR(100),    
@Job_Version VARCHAR(100),    
@Job_Used_Context VARCHAR(100),    
@Component_Name VARCHAR(100),    
@Stats_Capture_At VARCHAR(100),    
@Job_Status VARCHAR(100),    
@Job_Execution_Duration VARCHAR(100),    
@Error_Type VARCHAR(100),    
@Error_Code int,    
@Error_Message VARCHAR(MAX),    
@HPSM_Ticket_Status VARCHAR(100)    

  
AS      
BEGIN   
   
SET NOCOUNT ON  
     
   BEGIN    
  
    insert into ABCR_AUDIT.VW_DATA_LOAD_STATISTICS (BOW_Id,SBOW_Id,UOW_Id,Job_Start_Time,Job_End_Time,ProcessID,Git_Project_Name,Job_Name,Job_Repository_Id,Job_Version,Job_Used_Context,Component_Name,Stats_Capture_At,Job_Status,Job_Execution_Duration,Error_Type,Error_Code,Error_Message,HPSM_Ticket_Status)  
	Values(@bow_Id,@sbow_Id,@uow_Id,@Job_Start_Time,@Job_End_Time,@ProcessID,@Git_Project_Name,@Job_Name,@Job_Repository_Id,@Job_Version,@Job_Used_Context,@Component_Name,@Stats_Capture_At,@Job_Status,@Job_Execution_Duration,@Error_Type,@Error_Code,@Error_Message,@HPSM_Ticket_Status)    
     
   END    
  
END



