-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_Environment_Config_Values>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting  details  from ABCR_CONTROL.VW_Environment_Config_Values>
-- =============================================

CREATE   PROCEDURE [ABCR_CONTROL].[USP_Environment_Config_Values]    
@env varchar(10),
@Tenant_ID Int

AS    
SET NOCOUNT ON;    
BEGIN    
	Select ENVIRONMENT_CONFIG_KEY_TEXT as [Key],ENVIRONMENT_CONFIG_VALUE_TEXT    
	as [Value] from ABCR_CONTROL.VW_ENVIRONMENT_CONFIGURATION_VALUES    
	WHERE IS_ACTIVE_FLAG='Y' and ENVIRONMENT=@env and TENANT_ID=@Tenant_ID    
END



