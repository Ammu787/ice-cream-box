-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_UPDATE_BOW_CDC_AUX_CONTROL>
-- =======================================================
-- =============================================  
-- Author:      <Satya Bhargavi>  
-- Create Date: <23-08-2022>  
-- Description: <Used to update the details about Change data capture start & end timestamps from ABCR_AUDIT.BOW_CDC_AUX_CONTROL_R01 table>  
-- =============================================  
   
CREATE  PROCEDURE [ABCR_AUDIT].[USP_UPDATE_BOW_CDC_AUX_CONTROL]  
 
@CHANGE_DATA_CAPTURE_START_TIMESTAMP [varchar](50),  
@CHANGE_DATA_CAPTURE_END_TIMESTAMP [varchar](50),  
@BOW_ID [bigint],  
@UOW_ID [bigint]   
AS   
    SET NOCOUNT ON;                                                                     
   BEGIN   
   declare @cdc_start  datetime2, @cdc_end  datetime2  
   select @cdc_start= replace(@CHANGE_DATA_CAPTURE_START_TIMESTAMP,'+',''),@cdc_end= replace(@CHANGE_DATA_CAPTURE_END_TIMESTAMP,'+','')  
   update ABCR_AUDIT.BOW_CDC_AUX_CONTROL_R01 set [CHANGE_DATA_CAPTURE_START_TIMESTAMP]=convert(datetime2,@cdc_start), [CHANGE_DATA_CAPTURE_END_TIMESTAMP]=convert(datetime2,@cdc_end) where [BOW_ID]=@BOW_ID and [UOW_ID]=@UOW_ID  
   End



