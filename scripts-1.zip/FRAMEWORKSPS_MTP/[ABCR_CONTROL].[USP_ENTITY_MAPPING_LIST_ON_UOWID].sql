-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_ENTITY_MAPPING_LIST_ON_UOWID>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting  details  from ABCR_CONTROL.VW_ENTITY_MAPPING_CONTROL>
-- =============================================

CREATE   Procedure [ABCR_CONTROL].[USP_ENTITY_MAPPING_LIST_ON_UOWID]  
@UOW_ID Bigint,  
@TENANT_ID Int  
  
AS  
BEGIN  
WITH  
entity_map_CTE AS    
(    
    SELECT Tenant_ID ,UOW_ID ,SBOW_ID,Parent_UOW_ID,UOW_ID as Base_UOW_ID, 0 AS LEVEL  
            FROM  ABCR_CONTROL.VW_Entity_Mapping_Control    
    WHERE Tenant_ID=@TENANT_ID AND Parent_UOW_ID  = 0  
UNION ALL    
    SELECT entity_map.Tenant_ID    
            , entity_map.UOW_ID, entity_map.SBOW_ID,entity_map.Parent_UOW_ID,Base_UOW_ID  
            , (entity_map_CTE.LEVEL + 1) AS LEVEL    
    FROM  ABCR_CONTROL.VW_Entity_Mapping_Control as entity_map  
    JOIN entity_map_CTE    
    ON entity_map.Parent_UOW_ID = entity_map_CTE.UOW_ID  
)    
,final_cte as(  
SELECT Base_UOW_ID ,UOW_ID,level  
FROM entity_map_CTE where UOW_ID = @UOW_ID  
)  
select Tenant_ID ,a.UOW_ID as UOW_ID,SBOW_ID,Parent_UOW_ID,b.UOW_ID as Base_UOW_ID,a.LEVEL   from entity_map_CTE a join final_cte b on a.base_uow_id = b.base_uow_id   and a.level>=b.level
end  



