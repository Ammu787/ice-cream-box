-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_GET_SOURCE_SINK_PATH>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting  details  from ABCR_CONTROL.VW_UOW_Configuration_Values
-- =============================================

CREATE PROC [ABCR_CONTROL].[USP_GET_SOURCE_SINK_PATH]     
@UOW_ID BIGINT      
    
AS      
BEGIN      
    
SET NOCOUNT ON    
    
SELECT Config_Key_Text, Config_Value_Text FROM ABCR_CONTROL.VW_UOW_Configuration_Values WHERE UOW_ID = @UOW_ID AND (Config_Key_Text = 'SOURCE_PATH' OR Config_Key_Text = 'SINK_PATH')      
    
END



