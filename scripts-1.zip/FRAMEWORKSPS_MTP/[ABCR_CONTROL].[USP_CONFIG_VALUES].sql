-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_CONFIG_VALUES>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting  details  from ABCR_CONTROL.CONFIG_VALUES>
-- =============================================

CREATE procedure [ABCR_CONTROL].[USP_CONFIG_VALUES]
@BOWID Bigint,
@SBOWID Bigint,
@UOWID Bigint


As
Begin
	Select  [Config_Key_Text] as [Key], [Config_Value_Text] as [Value] from ABCR_CONTROL.VW_UOW_Configuration_Values
	where BOW_ID = @BOWID AND SBOW_ID=@SBOWID AND UOW_ID=@UOWID AND IS_Active_Flag='Y'
End



