-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_CREATE_LOG_HEADER>
-- =======================================================

-- =======================================================  
-- Author:      <Aastha Bahuguna>  
-- Create Date: <23-08-2022>  
-- Description: <Updating below log details into ABCR_AUDIT.VW_Log_Header table for the particular job id>  
-- =======================================================
  
CREATE  PROCEDURE [ABCR_AUDIT].[USP_CREATE_LOG_HEADER] 
@TENANT_ID [INT] ,  
@BOW_ID [INT] ,  
@UOW_ID [BIGINT] ,  
@BATCH_EXECUTION_ID [VARCHAR](50) ,  
@STATUS_FLAG [CHAR](1) ,  
@EXECUTION_START_TIME [DATETIME2](7) ,  
@EXECUTION_END_TIME [DATETIME2](7) ,  
@sbow_id [INT] =null,  
@JOB_EXECUTION_ID [VARCHAR](50),  
@JOB_ID [INT],  
@SOURCE_TOTAL_RECORD_COUNT [INT],  
@TARGET_TOTAL_RECORD_COUNT [INT]  
 
  
AS  
BEGIN  
  
SET NOCOUNT ON;  
  
 set transaction isolation level serializable  
 declare @maxid int   
 select @maxid =  ISNULL(max(Log_Header_ID),0) + 1 from ABCR_AUDIT.VW_LOG_HEADER   
  
 INSERT INTO ABCR_AUDIT.VW_LOG_HEADER (Tenant_ID,Log_Header_ID, BOW_ID, UOW_ID, Batch_Execution_ID, Status_Flag, Execution_Start_Time, Execution_End_Time, SBOW_ID, Job_Execution_id, Job_Id,Source_Total_Record_Count,Target_Total_Record_Count)  
 values( @TENANT_ID ,@maxid, @BOW_ID , @UOW_ID , @BATCH_EXECUTION_ID, @STATUS_FLAG, @EXECUTION_START_TIME, @EXECUTION_END_TIME, @sbow_id, @JOB_EXECUTION_ID, @JOB_ID,@SOURCE_TOTAL_RECORD_COUNT,@TARGET_TOTAL_RECORD_COUNT)  
  
 select * from ABCR_AUDIT.VW_LOG_HEADER where Log_Header_ID = @maxid  
  
END


