-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_GET_JOB_ID_LIST>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting list of job_id's from  ABCR_CONTROL.VW_common_configuration_values table & converted json string to integer from function ABCR_CONTROL.UDF_SPLIT_JOB_ID to process>
-- =============================================

CREATE PROC [ABCR_CONTROL].[USP_GET_JOB_ID_LIST]       
@CONFIG_KEY NVARCHAR(100)       

AS       
BEGIN     

SET NOCOUNT ON

--DECLARE @JOB_ID NVARCHAR(100)     
--DECLARE @LIST NVARCHAR(500)     

--	SELECT @LIST = [Config_Value_Text] FROM ABCR_CONTROL.VW_common_configuration_values WHERE Config_Key_Text = @CONFIG_KEY     

--	SELECT @JOB_ID = JOB_ID FROM OPENJSON (@LIST) WITH (JOB_ID NVARCHAR(MAX) '$.JobIDs')     

--	SELECT  @LIST as JOB_LIST,JOB_ID FROM ABCR_CONTROL.UDF_SPLIT_JOB_ID (SUBSTRING(@JOB_ID,2,LEN(@JOB_ID)-2),',')     
  
  DECLARE @EXEC NVARCHAR(100)
  DECLARE @JOB_ID NVARCHAR(100)
  DECLARE @LIST NVARCHAR(100)    
  DECLARE  @CH_PIPELINE NVARCHAR(100)
      
  SELECT @LIST = [Config_Value_Text] FROM ABCR_CONTROL.common_configuration_values WHERE Config_Key_Text = @CONFIG_KEY

  SELECT @JOB_ID = JOB_ID FROM OPENJSON (@LIST)      
  WITH (JOB_ID NVARCHAR(MAX) '$.JobIDs')

  SELECT @EXEC = EXEC_ID FROM OPENJSON (@LIST)      
  WITH (EXEC_ID NVARCHAR(MAX) '$.Exec')

  DECLARE @GET_JOB_ID TABLE (JOB_ID INT)

  INSERT @GET_JOB_ID
  SELECT  JOB_ID FROM ABCR_CONTROL.UDF_SPLIT_JOB_ID(SUBSTRING(@JOB_ID,2,LEN(@JOB_ID)-2),',')

  SELECT @CH_PIPELINE = ChildPipeline_Text FROM ABCR_CONTROL.adf_pipeline_control WHERE JOB_ID IN (SELECT JOB_ID FROM @GET_JOB_ID)
      
  SELECT @JOB_ID AS JOB_LIST, @EXEC AS EXEC_ID, @CH_PIPELINE AS CH_PIPELINE

END



