-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.USP_GET_JOB_PROCESS_DETAILS_FOR_JOBID_UOWID>
-- =======================================================

-- =======================================================
-- Author:      <SATYA BHARGAVI>
-- Create Date: <23-08-2022>
-- Description: <This StoredProcedure is used to extract the records from the Job Process Control table based onthe Jobid and UOWid passed as the parameters >
-- =======================================================

CREATE   PROCEDURE [ABCR_CONTROL].[USP_GET_JOB_PROCESS_DETAILS_FOR_JOBID_UOWID]
@jobid Int,
@bowid Bigint,
@uowid BigInt,
@mode char(1)
--,
--@layer Char(1)
As
SET NOCOUNT ON;
declare @temp table (BOW_ID INT, SBOW_ID INT, UOW_ID BIGINT, STAGE_ID INT,TASK_ID INT,QUERY_TYPE VARCHAR(2000),QUERY_TEXT VARCHAR(MAX),PARAMS_JSON_TEXT VARCHAR(2000), Actions_Text VARCHAR (2000),
				SOURCE_TABLE_NAME VARCHAR(2000),TARGET_TABLE_NAME VARCHAR(2000),SBOW_NAME VARCHAR(2000),SEQUENCE_ID INT,UOW_NAME VARCHAR(2000),BATCH_ID INT,UOW_DESCRIPTION VARCHAR (2000), PII_COLUMNS VARCHAR(2000),SPARK_SETTINGS_TEXT VARCHAR(2000),SRC_SYSTEM_ID INT)
BEGIN
	declare @job_execution_id varchar(max)
	declare @execution_start_time datetime2
	select @execution_start_time=max(Execution_Start_Time) FROM ABCR_AUDIT.VW_LOG_HEADER where Job_Id=@jobid 
	print(@execution_start_time)
	
	select @job_execution_id =Job_Execution_id FROM ABCR_AUDIT.VW_LOG_HEADER  where Execution_Start_Time=@execution_start_time
	print(@job_execution_id)
	
	
	IF EXISTS (select 1 FROM ABCR_AUDIT.VW_LOG_HEADER where Job_Execution_id=@job_execution_id and Status_Flag<>'S') and @mode = 'R'
		BEGIN
			insert into @temp(bow_id, sbow_id, uow_id,stage_id,task_id,query_type,query_text,params_json_text,actions_text, source_table_name,target_table_name,
	sbow_name,sequence_Id,uow_name,batch_id,UOW_Description, pii_columns, spark_settings_text,src_system_id)
			Select pc.BOW_ID, pc.SBOW_ID, pc.UOW_ID,pc.Stage_ID as stage_id,pc.Task_ID,pc.Query_Type,pc.Query_Text,pc.PARAMS_JSON_TEXT,pc.Actions_Text, pc.Source_Table_Name,pc.Target_Table_Name,
			sc.SBOW_NAME,sc.SEQUENCE_ID as sequence_Id,uc.UOW_NAME,pc.Batch_ID as batch_id,uc.UOW_Description
			,usc.Columns as pii_columns, pc.SPARK_SETTINGS_TEXT,bc.SRC_SYSTEM_ID
			From
			ABCR_CONTROL.VW_Job_orchestration_control jc,
			ABCR_CONTROL.VW_Process_Control pc left outer join ABCR_CONTROL.VW_UOW_Security_Control usc on pc.UOW_ID = usc.UOW_ID and pc.BOW_ID=usc.BOW_ID,
			ABCR_CONTROL.VW_SBOW_CONTROL sc,
			ABCR_CONTROL.VW_UOW_CONTROL uc,
			ABCR_CONTROL.VW_BOW_CONTROL bc

			Where
			jc.JOB_ID = @jobid and jc.BOW_ID = @bowid and jc.BOW_ID = pc.BOW_ID and
			--pc.parquet_Query_indicator =@layer and
			jc.UOW_ID=pc.Schema_ID and sc.SBOW_ID = pc.SBOW_ID and sc.BOW_ID = pc.BOW_ID and
			uc.UOW_ID = pc.UOW_ID and pc.Schema_ID = @uowid and  jc.BOW_ID = bc.BOW_ID and  uc.BOW_ID = bc.BOW_ID 
			--Order by sc.sequence_id,pc.stage_id,pc.task_id,pc.batch_id
			EXCEPT
			Select pc.BOW_ID, pc.SBOW_ID, pc.UOW_ID,pc.Stage_ID as stage_id,pc.Task_ID,pc.Query_Type,pc.Query_Text,pc.PARAMS_JSON_TEXT,pc.Actions_Text, pc.Source_Table_Name,pc.Target_Table_Name,
			sc.SBOW_NAME,sc.SEQUENCE_ID as sequence_Id,uc.UOW_NAME,pc.Batch_ID as batch_id,uc.UOW_Description
			,usc.Columns as pii_columns, pc.SPARK_SETTINGS_TEXT,bc.SRC_SYSTEM_ID
			--into #tmp 
			From
			ABCR_CONTROL.VW_Job_orchestration_control jc,
			ABCR_CONTROL.VW_Process_Control pc left outer join ABCR_CONTROL.VW_UOW_Security_Control usc on pc.UOW_ID = usc.UOW_ID and pc.BOW_ID=usc.BOW_ID,
			ABCR_AUDIT.VW_LOG_HEADER lh ,
			ABCR_CONTROL.VW_SBOW_CONTROL sc,
			ABCR_CONTROL.VW_UOW_CONTROL uc,
			ABCR_CONTROL.VW_BOW_CONTROL bc

			Where
			jc.JOB_ID = @jobid and jc.BOW_ID = @bowid  and jc.BOW_ID = pc.BOW_ID and
			--pc.parquet_Query_indicator =@layer and
			jc.UOW_ID=pc.Schema_ID and sc.SBOW_ID = pc.SBOW_ID and sc.BOW_ID = pc.BOW_ID and
			uc.UOW_ID = pc.UOW_ID and pc.Schema_ID =  @uowid  and  jc.BOW_ID = bc.BOW_ID and  uc.BOW_ID = bc.BOW_ID
			and  pc.UOW_ID= lh.UOW_ID and pc.SBOW_ID = lh.SBOW_ID
			and (Job_Execution_id= @job_execution_id and Status_Flag = 'S' )
			Order by sc.SEQUENCE_ID,pc.Stage_ID,pc.Task_ID,pc.Batch_ID
		END
	ELSE
		BEGIN
			insert into @temp(bow_id, sbow_id, uow_id,stage_id,task_id,query_type,query_text,params_json_text,actions_text, source_table_name,target_table_name,
			sbow_name,sequence_Id,uow_name,batch_id,UOW_Description, pii_columns, spark_settings_text,src_system_id)
			Select pc.BOW_ID, pc.SBOW_ID, pc.UOW_ID,pc.Stage_ID,pc.Task_ID,pc.Query_Type,pc.Query_Text,pc.PARAMS_JSON_TEXT,pc.Actions_Text, pc.Source_Table_Name,pc.Target_Table_Name,
			sc.SBOW_NAME,sc.SEQUENCE_ID,uc.UOW_NAME,pc.Batch_ID,uc.UOW_Description
			,usc.Columns as pii_columns, pc.SPARK_SETTINGS_TEXT,bc.SRC_SYSTEM_ID
			--into #tmp 
			From
			ABCR_CONTROL.VW_Job_orchestration_control jc,
			ABCR_CONTROL.VW_Process_Control pc left outer join ABCR_CONTROL.VW_UOW_Security_Control usc on pc.UOW_ID = usc.UOW_ID and pc.BOW_ID=usc.BOW_ID,
			ABCR_CONTROL.VW_SBOW_CONTROL sc,
			ABCR_CONTROL.VW_UOW_CONTROL uc,
			ABCR_CONTROL.VW_BOW_CONTROL bc

			Where
			jc.JOB_ID = @jobid and jc.BOW_ID = @bowid and jc.BOW_ID = pc.BOW_ID and
			--pc.parquet_Query_indicator =@layer and
			jc.UOW_ID=pc.Schema_ID and sc.SBOW_ID = pc.SBOW_ID and sc.BOW_ID = pc.BOW_ID and
			uc.UOW_ID = pc.UOW_ID and pc.Schema_ID = @uowid and  jc.BOW_ID = bc.BOW_ID and  uc.BOW_ID = bc.BOW_ID 
			Order by sc.SEQUENCE_ID,pc.Stage_ID,pc.Task_ID,pc.Batch_ID
		END
	select bow_id, sbow_id, uow_id,stage_id,task_id,query_type,query_text,params_json_text,actions_text, source_table_name,target_table_name,
	sbow_name,sequence_Id,uow_name,batch_id,UOW_Description, pii_columns,spark_settings_text,src_system_id from @temp
	Order by sequence_id,stage_id,task_id,batch_id
end



