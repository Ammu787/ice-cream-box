-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_GET_UOW_ID_FOR_JOB_ID>
-- =======================================================
-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <To get TENANT_ID,BOW_ID,SBOW_ID,UOW_ID,Seq_ID FROM ABCR_CONTROL.VW_JOB_ORCHESTRATION_CONTROL table for the particular job id with active flag status 'Y'>
-- =============================================

CREATE   PROCEDURE [ABCR_CONTROL].[USP_GET_UOW_ID_FOR_JOB_ID]
@JOB_ID INT  

AS  
BEGIN  
SET NOCOUNT ON

SELECT TENANT_ID,BOW_ID,SBOW_ID,UOW_ID,Seq_ID  FROM ABCR_CONTROL.VW_Job_orchestration_control WHERE JOB_ID = @JOB_ID and IS_Active_Flag='Y';

END



