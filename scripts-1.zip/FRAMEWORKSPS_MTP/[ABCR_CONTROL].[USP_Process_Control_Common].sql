-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_Process_Control_Common>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting  details  from ABCR_CONTROL.VW_Process_Control>
-- =============================================

CREATE  PROCEDURE [ABCR_CONTROL].[USP_Process_Control_Common]
@BOW_ID INT,
@SBOW_ID INT,
@UOW_ID BIGINT

AS
SET NOCOUNT ON;
	BEGIN
		select [Tenant_ID], [BOW_ID], [SBOW_ID], [UOW_ID], [Stage_ID], [Task_ID], [Batch_ID], [Query_Type], [Query_Text], [Schema_ID], [SPARK_SETTINGS_TEXT], [IS_ACTIVE_FLAG], [Source_Table_Name], [Target_Table_Name], [PARAMS_JSON_TEXT],[Actions_Text]  from ABCR_CONTROL.VW_Process_Control WHERE [BOW_ID]=@BOW_ID AND [SBOW_ID]=@SBOW_ID AND [UOW_ID]=@UOW_ID  AND IS_ACTIVE_FLAG in('Y','y') order by Stage_ID, Task_ID
	END



