-- =============================================        
-- Author:      <Nivedita Gaddale>        
-- Create Date: <16-09-2022>        
-- Description: <Getting the databricks information from global_abcr_pilot.job_configuration_values table for any specified job_id>        
-- =============================================      
    
    
CREATE  PROC [ABCR_CONTROL].[USP_GET_DATABRICKS_CLUSTER_DETAILS]                  
@JOB_ID INT                  
AS                  
BEGIN             
          
SET NOCOUNT ON           
          
declare @bow_id bigint,@DataBricks_URL as varchar(500),@Job_Cluster_ID as BIGINT;        
          
  SELECT @bow_id=BOW_ID from ABCR_CONTROL.job_configuration_values a, ABCR_CONTROL.Job_orchestration_control b                
  where JobId =@JOB_ID and a.JobId = b.JOB_ID                
  SELECT @DataBricks_URL= Config_Value_Text from ABCR_CONTROL.job_configuration_values WHERE Config_Key_Text in                 
('DataBricks_URL') AND JobId =  @JOB_ID ;        
  SELECT @Job_Cluster_ID= Config_Value_Text from ABCR_CONTROL.job_configuration_values WHERE Config_Key_Text in                 
('Job_Cluster_ID') AND JobId =  @JOB_ID  ;        
        
select @bow_id as BOW_ID,@DataBricks_URL as DataBricks_URL,@Job_Cluster_ID as Job_Cluster_ID;        
                
END



