-- ==========================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_GET_PREVIOUS_INCREMENTAL_TIMESTAMP>  
-- =======================================================  
-- Author:      <Nivedita Gaddale>  
-- Create Date: <23-08-2022>  
-- Description: <Converting timestamp to integer format from ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL table>  
-- =============================================  
  
    
CREATE  PROC [ABCR_AUDIT].[USP_GET_PREVIOUS_INCREMENTAL_TIMESTAMP]        
@UOW_ID BIGINT      
   
AS          
BEGIN    
  
SET NOCOUNT ON  
  
  DECLARE @Insert_GMT_Timestamp DATETIME        
          
        SELECT @Insert_GMT_Timestamp = INSERT_GMT_TIMESTAMP FROM ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL WHERE UOW_ID = @UOW_ID        
        SELECT cast(substring(replace(replace(replace(replace(convert(varchar, @Insert_GMT_Timestamp,121),'-',''),':',''),' ',''),'.',''),1,17) as bigint) as Previous_Incremental_Time_Stamp        
END


