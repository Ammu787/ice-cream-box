-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_JOB_ORCHESTRATION_PROCESS_STATUS>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting  details  from ABCR_CONTROL.VW_JOB_ORCHESTRATION_PROCESS_STATUS>
-- =============================================

CREATE   PROCEDURE [ABCR_CONTROL].[USP_JOB_ORCHESTRATION_PROCESS_STATUS]
@job_execution_id varchar(500),
@uow_id_list VARCHAR(MAX)

AS

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRANSACTION t1
BEGIN Try
SET NOCOUNT ON;
BEGIN
    declare @bow_id int
	declare @sbow_id int
	declare @uow_id bigint
	declare @Batch_Execution_ID varchar(500)
	declare @Job_Execution_id_temp varchar(500)
	declare @Status_Flag char(1)
	declare @log_header_id int
	declare @job_run_duration int
	declare @wait_time int

    declare @Error VARCHAR(MAX)
    declare @temp table (bow_id int, sbow_id int, uow_id bigint, Job_Execution_id varchar(500), Batch_Execution_ID varchar(500), Status_Flag char(1), log_header_id int, job_run_duration int, wait_time int)
	

	insert into @temp (uow_id) select * from [dbo].[usp_util_convertstrtorow](@uow_id_list)
	
    
	DECLARE cursor_results CURSOR
	FOR SELECT lh.BOW_ID, lh.SBOW_ID, lh.UOW_ID, lh.Job_Execution_id, lh.Batch_Execution_ID, lh.Status_Flag, lh.Log_Header_ID, DATEDIFF(mi, lh.Execution_Start_Time, getdate()), jc.Wait_Time_In_Min 
    from ABCR_AUDIT.VW_LOG_HEADER lh
	inner join ABCR_CONTROL.VW_Job_orchestration_control jc on lh.BOW_ID=jc.BOW_ID and lh.SBOW_ID=jc.SBOW_ID and lh.UOW_ID=jc.UOW_ID and lh.Job_Id=jc.JOB_ID
	where lh.Job_Execution_id=@job_execution_id 
    
    OPEN cursor_results;
    FETCH NEXT FROM cursor_results INTO @bow_id, @sbow_id, @uow_id, @Job_Execution_id_temp, @Batch_Execution_ID, @Status_Flag, @log_header_id, @job_run_duration, @wait_time

	WHILE @@FETCH_STATUS = 0
    BEGIN
		update @temp set bow_id=@bow_id, sbow_id=@sbow_id, Job_Execution_id=@Job_Execution_id_temp, Batch_Execution_ID=@Batch_Execution_ID, Status_Flag=@Status_Flag, log_header_id=@log_header_id, job_run_duration=@job_run_duration, wait_time=@wait_time
		where uow_id=@uow_id 
		
		FETCH NEXT FROM cursor_results INTO @bow_id, @sbow_id, @uow_id, @Job_Execution_id_temp, @Batch_Execution_ID, @Status_Flag, @log_header_id, @job_run_duration, @wait_time 
    END
    CLOSE cursor_results;
    DEALLOCATE cursor_results;

	commit transaction t1
	delete from @temp where job_execution_id is null
	select * from @temp	
END
END Try

BEGIN Catch

set @Error = Error_Message()
IF @@TRANCOUNT > 0
rollback transaction t1
return
End Catch
IF @@TRANCOUNT > 0
commit transaction t1
RETURN;



