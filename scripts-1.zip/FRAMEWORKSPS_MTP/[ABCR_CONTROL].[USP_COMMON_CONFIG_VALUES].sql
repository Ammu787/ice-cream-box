-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_COMMON_CONFIG_VALUES>
-- =======================================================

-- =======================================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting  details  from ABCR_CONTROL.VW_COMMON_CONFIGURATION_VALUES>
-- =======================================================

CREATE  Procedure [ABCR_CONTROL].[USP_COMMON_CONFIG_VALUES]
As
Begin

	Select Config_Key_Text as [Key],Config_Value_Text as [Value] from ABCR_CONTROL.VW_common_configuration_values
	WHERE IS_Active_Flag='Y'

END



