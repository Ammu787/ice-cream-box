-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_Schema_Configuration>
-- =======================================================
-- =======================================================
-- Author:      <Nivedita Gaddale>  
-- Create Date: <23-08-2022>  
-- Description: <To get schema_name from ABCR_CONTROL.VW_Schema_Configuration table for the respective TENANT_ID>  
-- =======================================================
  
CREATE   Procedure [ABCR_CONTROL].[USP_Schema_Configuration]    
@TENANT_ID INT    
As    
Begin      
  
SET NOCOUNT ON  
  
 Select Schema_name  from ABCR_CONTROL.VW_Schema_Configuration where Tenant_ID = @TENANT_ID     
      
END



