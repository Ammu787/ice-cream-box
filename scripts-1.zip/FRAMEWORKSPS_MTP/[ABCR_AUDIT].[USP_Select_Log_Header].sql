-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_Select_Log_Header>
-- =======================================================
-- =======================================================
-- Author:      <ASTHA BAHUGUNA>  
-- Create Date: <23-08-2022>  
-- Description: <Select last run rows based on execution id from ABCR_AUDIT.VW_LOG_HEADER table>  
-- ========================================================
  
CREATE  PROCEDURE [ABCR_AUDIT].[USP_Select_Log_Header]
@BOW_ID INT,  
@UOW_ID BIGINT,  
@BATCH_EXECUTION_ID varchar(50)   

AS  
BEGIN  
  
SET NOCOUNT ON;  
  
 ---if @BATCH_EXECUTION_ID = null  
 --select * from [ABCR_AUDIT].[Log_Header] WITH (NOLOCK) WHERE [BOW_ID]=@BOW_ID AND [UOW_ID]=@UOW_ID AND Execution_Start_Time = @EXECUTION_START_TIME AND Status_Flag = 'R'  
 --else  
 select * from ABCR_AUDIT.VW_LOG_HEADER WITH (NOLOCK) WHERE [BOW_ID]=@BOW_ID AND [UOW_ID]=@UOW_ID AND Batch_Execution_ID = @BATCH_EXECUTION_ID AND Status_Flag = 'R'  
  
END



