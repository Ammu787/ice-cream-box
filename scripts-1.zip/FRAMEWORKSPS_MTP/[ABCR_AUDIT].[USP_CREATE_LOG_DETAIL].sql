-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_CREATE_LOG_DETAIL>
-- =======================================================

-- =============================================  
-- Author:      <Aastha Bahuguna>  
-- Create Date: <23-08-2022>  
-- Description: <Inserting  below log information into ABCR_AUDIT.VW_Log_Detail table for the particular LOG_HEADER_ID Which is generated in Log_HEADER TABLE>  
-- =============================================  
  
CREATE  PROCEDURE [ABCR_AUDIT].[USP_CREATE_LOG_DETAIL]
@Tenant_ID [int],   
@Log_Header_ID [int],  
@BOW_ID [int],   
@UOW_ID [Bigint],  
@Batch_Execution_ID [varchar](50),   
@Status_Flag [char](1),   
@Start_Part_Number [int],   
@End_Part_Number [int],  
@Execution_Start_Time [datetime2](7),  
@Execution_End_Time [datetime2](7) ,  
@Landing_Record_Count [bigint] ,  
@History_Total_Record_Count [bigint] ,   
@Total_Partitions_Count [int] ,   
@Total_Files_Count [int],  
@File_Name_Processed [VARCHAR](100),   
@Batch_ID [bigint],  
@Stage_Id [int],  
@Task_ID [int]  
  
AS  
BEGIN   
  
SET NOCOUNT ON;   
  
    set transaction isolation level serializable;  
   
 declare @max_detail_id int  
 select @max_detail_id =ISNULL(max(Log_Detail_ID),0) + 1 from ABCR_AUDIT.VW_LOG_DETAIL  
  
    INSERT INTO ABCR_AUDIT.VW_LOG_DETAIL (Tenant_ID, Log_Header_ID, Log_Detail_ID, BOW_ID, UOW_ID, Stage_ID, Batch_Execution_ID, Batch_ID, Status_Flag, Start_Part_Number, End_Part_Number, Execution_Start_Time, Execution_End_Time, Landing_Record_Count, History_Total_Record_Count, Total_Partitions_Count, Total_Files_Count, File_Name_Processed, Task_ID) 
	VALUES( @Tenant_ID, @Log_Header_ID, @max_detail_id, @BOW_ID, @UOW_ID, @Stage_Id, @Batch_Execution_ID, @Batch_ID, @Status_Flag, @Start_Part_Number, @End_Part_Number, @Execution_Start_Time, @Execution_End_Time, @Landing_Record_Count, @History_Total_Record_Count, @Total_Partitions_Count, @Total_Files_Count, @File_Name_Processed, @Task_ID)   
 
	select * from ABCR_AUDIT.VW_LOG_DETAIL where Log_Detail_ID =@max_detail_id and Log_Header_ID =@Log_Header_ID and Batch_Execution_ID=@Batch_Execution_ID  
  
END



