-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_UPDATE_INCREMENTAL_TIME_STAMP>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Using to update CDC start & End timestamps in ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL table>
-- =============================================
  
CREATE  PROCEDURE [ABCR_AUDIT].[USP_UPDATE_INCREMENTAL_TIME_STAMP]  
@Insert_GMT_Timestamp DATETIME,
@UOW_ID BIGINT,
@CHANGE_DATA_CAPTURE_START_TIMESTAMP DATETIME,
@CHANGE_DATA_CAPTURE_END_TIMESTAMP DATETIME   
AS    
BEGIN  

SET NOCOUNT ON

		UPDATE ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL    
		SET CHANGE_DATA_CAPTURE_START_TIMESTAMP = @CHANGE_DATA_CAPTURE_START_TIMESTAMP,    
		CHANGE_DATA_CAPTURE_END_TIMESTAMP = @CHANGE_DATA_CAPTURE_END_TIMESTAMP,     
		INSERT_GMT_TIMESTAMP = @Insert_GMT_Timestamp     
		WHERE UOW_ID = @UOW_ID    

END


