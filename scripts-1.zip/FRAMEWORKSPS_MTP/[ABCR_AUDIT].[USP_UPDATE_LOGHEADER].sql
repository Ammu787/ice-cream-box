-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_UPDATE_LOGHEADER>
-- =======================================================

-- =============================================
-- Author:      <Aastha Bahuguna>
-- Create Date: <23-08-2022>
-- Description: <Using to update Execution end timestamp, Status flag, Source & target record counts in ABCR_AUDIT.VW_LOG_HEADER table>
-- =============================================
  
CREATE PROCEDURE [ABCR_AUDIT].[USP_UPDATE_LOGHEADER] 
@Tenant_ID [int] ,  
@Log_Header_ID [int] ,  
@Batch_Execution_ID [varchar](50) ,  
@UOW_ID [bigint],  
@Status_Flag [char](1) ,  
@Execution_End_Time [datetime2](7),  
@Source_Total_Record_Count [INT],  
@Target_Total_Record_Count [INT]  
  
AS   
BEGIN  

SET NOCOUNT ON; 

   declare @status_flag_check char(1)  
   select @status_flag_check = isnull(Status_Flag,'R') from ABCR_AUDIT.VW_LOG_HEADER where Log_Header_ID=@Log_Header_ID and Tenant_ID=@Tenant_ID and Batch_Execution_ID=@Batch_Execution_ID and UOW_ID=@UOW_ID  
     
	if @status_flag_check = 'R'  
    begin  
     UPDATE ABCR_AUDIT.VW_LOG_HEADER set Execution_End_Time=@Execution_End_Time, Status_Flag=@Status_Flag, Source_Total_Record_Count=@Source_Total_Record_Count,Target_Total_Record_Count=@Target_Total_Record_Count where Log_Header_ID=@Log_Header_ID
	and Tenant_ID=@Tenant_ID and Batch_Execution_ID=@Batch_Execution_ID and UOW_ID=@UOW_ID   
    end
	
End


