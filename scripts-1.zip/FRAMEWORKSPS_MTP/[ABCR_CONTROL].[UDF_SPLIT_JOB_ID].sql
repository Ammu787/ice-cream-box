-- =======================================================
-- Create Function Template for <ABCR_CONTROL>.<UDF_SPLIT_JOB_ID>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Converting Json string Job_Id's to as list and row by row values>
-- =============================================

CREATE FUNCTION [ABCR_CONTROL].[UDF_SPLIT_JOB_ID]
(  
@INPUT NVARCHAR(1000),  
@CHARACTER CHAR(1)  
)  
RETURNS @OUTPUT TABLE (JOB_ID NVARCHAR(1000))  
AS  
BEGIN  


DECLARE @STARTINDEX INT, @ENDINDEX INT  
SET @STARTINDEX = 1  
	IF SUBSTRING(@INPUT,LEN(@INPUT) - 1, LEN(@INPUT)) <> @CHARACTER  
		BEGIN  
		 SET @INPUT = @INPUT + @CHARACTER  
		END  
	WHILE CHARINDEX(@CHARACTER,@INPUT) > 0  
		BEGIN  
		 SET @ENDINDEX = CHARINDEX(@CHARACTER,@INPUT)  
		 INSERT INTO @OUTPUT(JOB_ID)  
		 SELECT SUBSTRING(@INPUT,@STARTINDEX,@ENDINDEX - 1)  
		 SET @INPUT = SUBSTRING(@INPUT,@ENDINDEX + 1, LEN(@INPUT))  
		END  
	RETURN  
END



