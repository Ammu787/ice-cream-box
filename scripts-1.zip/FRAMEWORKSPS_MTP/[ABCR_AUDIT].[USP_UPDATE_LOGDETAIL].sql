-- =======================================================
-- Create Stored Procedure Template for <ABCR_AUDIT>.<USP_UPDATE_LOGDETAIL>
-- =======================================================

-- =======================================================
-- Author:      <Aastha Bahuguna>
-- Create Date: <23-08-2022>
-- Description: <Using to update Execution end timestamp, Status flag, record counts in ABCR_AUDIT.VW_LOG_DETAIL table>
-- =======================================================
  
CREATE  PROCEDURE [ABCR_AUDIT].[USP_UPDATE_LOGDETAIL]
@Tenant_ID [int] ,  
@Log_Header_ID [int] ,  
@BOW_ID [int],  
@UOW_ID [bigint],  
@Batch_Execution_ID [nvarchar](100) ,  
@Status_Flag [char](1) ,  
@Execution_End_Time [datetime2](7) ,  
@Landing_Record_Count [bigint] ,  
@History_Total_Record_Count [bigint] ,  
@Total_Partitions_Count [int] ,  
@Total_Files_Count [int],  
@Stage_Id [int],  
@Inserted_Record_Count [int],  
@Updated_Record_Count [int],  
@Deleted_Record_Count[int],  
@Fedllc_Record_Count [int],  
@Fed_Inserted_Record_Count [int],  
@Fed_Updated_Record_Count [int],  
@Fed_Deleted_Record_Count [int]  
 
AS  
BEGIN  
 
SET NOCOUNT ON;

   UPDATE ABCR_AUDIT.VW_LOG_DETAIL   
   set Execution_End_Time=@Execution_End_Time, Status_Flag=@Status_Flag, Landing_Record_Count=@Landing_Record_Count,   
   History_Total_Record_Count=@History_Total_Record_Count, Total_Partitions_Count=@Total_Partitions_Count,   
   Total_Files_Count=@Total_Files_Count, Updated_Record_Count=@Updated_Record_Count,   
   Inserted_Record_Count=@Inserted_Record_Count, Deleted_Record_Count=@Deleted_Record_Count, Fedllc_Record_Count = @Fedllc_Record_Count, Fed_Inserted_Record_Count = @Fed_Inserted_Record_Count, Fed_Updated_Record_Count = @Fed_Updated_Record_Count, Fed_Deleted_Record_Count = @Fed_Deleted_Record_Count        
   where Log_Header_ID=@Log_Header_ID and Tenant_ID=@Tenant_ID and Batch_Execution_ID=@Batch_Execution_ID and  Stage_ID=@Stage_Id and BOW_ID =@BOW_ID AND UOW_ID =@UOW_ID  
  
End



