-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_GET_PROCESS_DETAILS_FOR_JOBID>
-- =======================================================
-- =============================================  
-- Author:      <Satya Bhargavi>  
-- Create Date: <29-10-2022>  
-- Description: <This StoredProcedure is used to extract the records from the Job Process Control table based onthe Jobid and UOWid passed as the parameters>  
-- =============================================  
   

CREATE PROCEDURE [ABCR_CONTROL].[USP_GET_PROCESS_DETAILS_FOR_JOBID] 
@JOB_ID INT,  
@TENANT_ID INT,  
@UOW_ID BIGINT,  
@MODE char(1)

AS  
SET NOCOUNT ON;  
  
declare @temp table (Tenant_ID INT,  UOW_ID BIGINT, SBOW_ID INT, Parent_UOW_ID BIGINT,Base_UOW_ID BIGINT,LEVEL1 INT)  
declare @Job_Params nvarchar(100)  
declare @processing_layers_list nvarchar(100)  
declare @job_execution_id varchar(max)  
declare @execution_start_time datetime2  
BEGIN  
--- select processing_layers columns for the job_id  
          select @Job_Params = Job_Params , @UOW_ID = UOW_ID from  ABCR_CONTROL.JOB_ORCHESTRATION_CONTROL  
          where JOB_ID = @JOB_ID and Tenant_id= @TENANT_ID and UOW_ID = @UOW_ID;  
      
--convert the json into list  
          SELECT @processing_layers_list=Job_Params FROM OPENJSON (@Job_Params)     
          WITH (Job_Params NVARCHAR(MAX) '$.layers')  
      
--create temptable by joining with sbow_control  
          select b.TENANT_ID, b.JOB_ID, b.BOW_ID, a.SBOW_ID, b.UOW_ID, a.sequence_id as Seq_ID, b.IS_Active_Flag as Active_Flag,  
          b.Wait_Time_In_Min,processing_layer into #temptable from ABCR_CONTROL.sbow_control a,(  
          SELECT t.*, Value as processing_layer FROM  ABCR_CONTROL.JOB_ORCHESTRATION_CONTROL t  
          CROSS APPLY STRING_SPLIT(@processing_layers_list , ',') ) b  
          where a.layer_code = b.processing_layer and a.TENANT_ID= b.TENANT_ID and  JOB_ID=@JOB_ID and uow_id = @UOW_ID order by  a.sequence_id  
    --select * from #temptable  
--create temp table from entity_mapping_control  
          insert into @temp  
          EXEC ABCR_CONTROL.USP_ENTITY_MAPPING_LIST_ON_UOWID @UOW_ID,@TENANT_ID  
     
--create   temp_orch_table    
    select  b.TENANT_ID, JOB_ID, b.BOW_ID, b.SBOW_ID, a.UOW_ID, Seq_ID, Active_Flag,  
              Wait_Time_In_Min,processing_layer into #temp_orch_table  
           from @temp a,#temptable b where base_uow_id = b.uow_id and a.SBOW_ID = b.SBOW_ID  
   
 --- last run exec start_time  for this job_id        
     select @execution_start_time=max(Execution_Start_Time) FROM ABCR_AUDIT.LOG_HEADER where Job_Id=@JOB_ID  
           print(@execution_start_time)  
  --- last run @job_execution_id  for this job_id      
           select @job_execution_id =Job_Execution_id FROM ABCR_AUDIT.LOG_HEADER  where Execution_Start_Time=@execution_start_time  
           print(@job_execution_id)  
         
           IF EXISTS (select 1 FROM ABCR_AUDIT.LOG_HEADER where Job_Execution_id=@job_execution_id and Status_Flag<>'S') and @MODE = 'R'  
           BEGIN  
               Select pc.BOW_ID, pc.SBOW_ID, pc.UOW_ID,pc.Stage_ID as stage_id,pc.Task_ID,pc.Query_Type,pc.Query_Text,pc.PARAMS_JSON_TEXT,pc.Actions_Text, pc.Source_Table_Name,pc.Target_Table_Name,  
          sc.SBOW_NAME,sc.SEQUENCE_ID as sequence_Id,uc.UOW_NAME,pc.Batch_ID as batch_id,uc.UOW_Description  
          ,usc.Columns as pii_columns, pc.SPARK_SETTINGS_TEXT,bc.SRC_SYSTEM_ID    
          From  
          #temp_orch_table jc,  
           ABCR_CONTROL.Process_Control pc left outer join ABCR_CONTROL.UOW_Security_Control usc on pc.UOW_ID = usc.UOW_ID and pc.BOW_ID=usc.BOW_ID,  
           ABCR_CONTROL.SBOW_CONTROL sc,  
           ABCR_CONTROL.UOW_CONTROL uc,  
           ABCR_CONTROL.BOW_CONTROL bc  
           Where  
           jc.UOW_ID=pc.UOW_ID and  jc.BOW_ID = pc.BOW_ID and  jc.SBOW_ID = pc.SBOW_ID  
           and sc.SBOW_ID = pc.SBOW_ID  and sc.BOW_ID = pc.BOW_ID and  
           uc.UOW_ID = pc.UOW_ID and   uc.BOW_ID = bc.BOW_ID   and sc.SBOW_ID = uc.SBOW_ID    
           --Order by jc.seq_id,sc.sequence_id, pc.stage_id,pc.task_id,pc.batch_id  
           except  
     Select pc.BOW_ID, pc.SBOW_ID, pc.UOW_ID,pc.Stage_ID as stage_id,pc.Task_ID,pc.Query_Type,pc.Query_Text,pc.PARAMS_JSON_TEXT,pc.Actions_Text, pc.Source_Table_Name,pc.Target_Table_Name,  
          sc.SBOW_NAME,sc.SEQUENCE_ID as sequence_Id,uc.UOW_NAME,pc.Batch_ID as batch_id,uc.UOW_Description  
          ,usc.Columns as pii_columns, pc.SPARK_SETTINGS_TEXT,bc.SRC_SYSTEM_ID    
          From  
          #temp_orch_table jc,  
           ABCR_CONTROL.Process_Control pc left outer join ABCR_CONTROL.UOW_Security_Control usc on pc.UOW_ID = usc.UOW_ID and pc.BOW_ID=usc.BOW_ID,  
           ABCR_CONTROL.SBOW_CONTROL sc,  
           ABCR_CONTROL.UOW_CONTROL uc,  
           ABCR_CONTROL.BOW_CONTROL bc,  
     ABCR_AUDIT.LOG_HEADER lh  
           Where  
           jc.UOW_ID=pc.UOW_ID and  jc.BOW_ID = pc.BOW_ID and  jc.SBOW_ID = pc.SBOW_ID  
           and sc.SBOW_ID = pc.SBOW_ID  and sc.BOW_ID = pc.BOW_ID and  
           uc.UOW_ID = pc.UOW_ID and   uc.BOW_ID = bc.BOW_ID   and sc.SBOW_ID = uc.SBOW_ID   
     and pc.UOW_ID= lh.UOW_ID and pc.SBOW_ID = lh.SBOW_ID  
           and (Job_Execution_id= @job_execution_id and Status_Flag = 'S')  
           END  
           else  
        BEGIN  
                       Select pc.BOW_ID, pc.SBOW_ID, pc.UOW_ID,pc.Stage_ID as stage_id,pc.Task_ID,pc.Query_Type,pc.Query_Text,pc.PARAMS_JSON_TEXT,pc.Actions_Text, pc.Source_Table_Name,pc.Target_Table_Name,  
          sc.SBOW_NAME,sc.SEQUENCE_ID as sequence_Id,uc.UOW_NAME,pc.Batch_ID as batch_id,uc.UOW_Description  
          ,usc.Columns as pii_columns, pc.SPARK_SETTINGS_TEXT,bc.SRC_SYSTEM_ID    
          From  
          #temp_orch_table jc,  
           ABCR_CONTROL.Process_Control pc left outer join ABCR_CONTROL.UOW_Security_Control usc on pc.UOW_ID = usc.UOW_ID and pc.BOW_ID=usc.BOW_ID,  
           ABCR_CONTROL.SBOW_CONTROL sc,  
           ABCR_CONTROL.UOW_CONTROL uc,  
           ABCR_CONTROL.BOW_CONTROL bc  
           Where  
           jc.UOW_ID=pc.UOW_ID and  jc.BOW_ID = pc.BOW_ID and  jc.SBOW_ID = pc.SBOW_ID  
           and sc.SBOW_ID = pc.SBOW_ID  and sc.BOW_ID = pc.BOW_ID and  
           uc.UOW_ID = pc.UOW_ID and   uc.BOW_ID = bc.BOW_ID   and sc.SBOW_ID = uc.SBOW_ID    
           Order by jc.seq_id,sc.sequence_id, pc.stage_id,pc.task_id,pc.batch_id  
        END  
  
drop table  #temptable  
drop table #temp_orch_table  
  
END  
  
   


