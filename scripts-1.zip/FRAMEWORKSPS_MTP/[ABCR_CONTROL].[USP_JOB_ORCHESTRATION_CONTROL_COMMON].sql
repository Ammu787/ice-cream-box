-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_JOB_ORCHESTRATION_CONTROL_COMMON>
-- =======================================================
-- =======================================================  
-- Author:      <Aastha Bahuguna>  
-- Create Date: <31-08-2022>  
-- Description: <This StoredProcedure is used to extract the records from the ABCR_CONTROL.VW_JOB_ORCHESTRATION_CONTROL table if the mode is not equal to "R">
-- ======================================================= 

CREATE  PROCEDURE [ABCR_CONTROL].[USP_JOB_ORCHESTRATION_CONTROL_COMMON]
@JOB_ID INT,
@TENANT_ID INT,
@MODE char(1)
AS
SET NOCOUNT ON;
declare @temp table (TENANT_ID int,JOB_ID int, BOW_ID INT, SBOW_ID INT, UOW_ID BIGINT, SEQ_ID INT, Active_Flag char(1), Wait_Time_In_Min int, STATUS_FLAG char(1))
BEGIN
   
    if upper(@MODE) <> 'R'
        Begin
            print('Inside N flow')
            select TENANT_ID, JOB_ID, BOW_ID, SBOW_ID, UOW_ID, Seq_ID, IS_Active_Flag as Active_Flag, Wait_Time_In_Min
            from ABCR_CONTROL.VW_Job_orchestration_control where JOB_ID=@JOB_ID and IS_Active_Flag = 'Y' AND TENANT_ID = @TENANT_ID
            
        end
    else
        Begin
            print('Inside R flow')
            declare @job_execution_id varchar(max)
            declare @execution_start_time datetime2
            declare @BOW_ID_header int
            declare @SBOW_ID_header int
            declare @UOW_ID_header Bigint
            declare @JOB_EXECUTION_ID_header varchar(max)
            declare @BATCH_EXECUTION_ID_header varchar(max)
            declare @STATUS_FLAG_header char (1)
            
            
            insert into @temp(TENANT_ID, JOB_ID, BOW_ID, SBOW_ID, UOW_ID, SEQ_ID, Active_Flag, Wait_Time_In_Min) select
            TENANT_ID, JOB_ID, BOW_ID, SBOW_ID, UOW_ID, Seq_ID, IS_Active_Flag ,Wait_Time_In_Min from ABCR_CONTROL.VW_Job_orchestration_control
            where JOB_ID=@JOB_ID and IS_Active_Flag='Y'
        
            select @execution_start_time=max(Execution_Start_Time) FROM ABCR_AUDIT.VW_LOG_HEADER where Job_Id = @JOB_ID
            print(@execution_start_time)
        
            select @job_execution_id =Job_Execution_id FROM ABCR_AUDIT.VW_LOG_HEADER  where Execution_Start_Time=@execution_start_time
            print(@job_execution_id)
            
            declare  header_uow_status CURSOR
            for     select distinct a.BOW_ID,a.SBOW_ID, b.Schema_ID,Batch_Execution_ID, Job_Execution_id, Status_Flag
            FROM ABCR_AUDIT.VW_LOG_HEADER a ,ABCR_CONTROL.VW_Process_Control b where  Job_Execution_id=@job_execution_id and
            a.UOW_ID = b.UOW_ID
        
            OPEN header_uow_status;
            FETCH NEXT FROM header_uow_status INTO @BOW_ID_header,@SBOW_ID_header, @UOW_ID_header,@BATCH_EXECUTION_ID_header, @JOB_EXECUTION_ID_header, @STATUS_FLAG_header
        
            WHILE @@FETCH_STATUS = 0
            BEGIN
                update @temp set STATUS_FLAG=@STATUS_FLAG_header where BOW_ID=@BOW_ID_header and UOW_ID=@UOW_ID_header
            FETCH NEXT FROM header_uow_status INTO @BOW_ID_header,@SBOW_ID_header, @UOW_ID_header,@BATCH_EXECUTION_ID_header, @JOB_EXECUTION_ID_header, @STATUS_FLAG_header
      
            END
            CLOSE header_uow_status;
            DEALLOCATE header_uow_status;
             delete from @temp where upper(status_flag)='S'
            select * from @temp
        end
    
       
END



