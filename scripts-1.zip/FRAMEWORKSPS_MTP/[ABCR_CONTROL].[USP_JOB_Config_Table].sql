-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_JOB_Config_Table>
-- =======================================================

-- =============================================
-- Author:      <Nivedita Gaddale>
-- Create Date: <23-08-2022>
-- Description: <Getting  details  from ABCR_CONTROL.VW_JOB_Config_Table>
-- =============================================


CREATE  Procedure [ABCR_CONTROL].[USP_JOB_Config_Table]
@JobId Int


As
Begin
Select Config_Key_Text as [Key], Config_Value_Text as [Value] from ABCR_CONTROL.VW_job_configuration_values where JobId = @JobId


End



