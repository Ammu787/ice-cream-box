-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.<USP_GET_UPDATED_QUERY_TEXT >
-- =======================================================
-- =======================================================
-- Author:      <Poojitha Voggu>  
-- Create Date: <23-08-2022>  
-- Description: <Used to fetch the details about CDC END TIME STAMP,NO OF DAYS, TABLE NAME,CDC QUERY, SELECT QUERY & LOAD TYPE from ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL & ABCR_CONTROL.VW_Process_contrlol table for the specified TENANT_ID,BOW_ID,SBOW_ID,UOW_ID>  
-- =======================================================
      
CREATE  PROCEDURE [ABCR_CONTROL].[USP_GET_UPDATED_QUERY_TEXT] 
@CDC_START_TIMESTAMP [DATETIME2](7),
@NO_OF_DAYS INT ,
@SELECT_QUERY VARCHAR(MAX),
@TABLE_NAME VARCHAR(100) 
  

AS  
BEGIN
SET NOCOUNT ON  
 
  
DECLARE @INDEX_VALUE INT,@LENGTH INT,@LENGTH1 INT,@INDEX_VALUE1 INT,@INDEX_VALUE2 INT,@INDEX_VALUE3 INT,@CDC_END_TIMESTAMP [DATETIME2](7);  
DECLARE @SELECT_STATEMENT VARCHAR(MAx),@CDC_QUERY_TEXT VARCHAR(MAx),@ErMsg Varchar(4000),@CDC_COLUMN VARCHAR(100);  
  
SET @SELECT_QUERY = LTRIM(RTRIM(@SELECT_QUERY));  
SET @INDEX_VALUE = CHARINDEX(UPPER('@cdc_start_time'), UPPER(@SELECT_QUERY));  
SET @INDEX_VALUE1 = CHARINDEX(UPPER('@cdc_end_time'), UPPER(@SELECT_QUERY),@INDEX_VALUE+1);  
SET @INDEX_VALUE2 = CHARINDEX(UPPER('WHERE'), UPPER(@SELECT_QUERY));  
SET @INDEX_VALUE3 = CHARINDEX('>=', @SELECT_QUERY,@INDEX_VALUE2+1);  
SET @LENGTH= len('@cdc_start_time');  
SET @LENGTH1= len('@cdc_end_time');  
  
  
   IF (@INDEX_VALUE = 0 or @INDEX_VALUE1 = 0)  
        BEGIN  
			SET @ErMsg = 'Could not find Seperator';  
            Raiserror(@ErMsg,16,1);  
        END  
   
   ELSE  
        BEGIN  
            SET @CDC_END_TIMESTAMP= DATEADD(DAY,@NO_OF_DAYS,@CDC_START_TIMESTAMP);  
            SET @CDC_COLUMN= LTRIM(RTRIM(SUbSTRING(@SELECT_QUERY,@INDEX_VALUE2+5,(@INDEX_VALUE3-(@INDEX_VALUE2+5)))));  
            --select @CDC_COLUMN  
            SET @SELECT_STATEMENT= REPLACE((REPLACE(@SELECT_QUERY,SUBSTRING(@SELECT_QUERY,@INDEX_VALUE1,@LENGTH1),CONCAT('''',@CDC_END_TIMESTAMP,''''))),SUBSTRING(@SELECT_QUERY,@INDEX_VALUE,@LENGTH),CONCAT('''',@CDC_START_TIMESTAMP,''''))  
            set @CDC_QUERY_TEXT= 'select MAX('+@CDC_COLUMN+') AS MAX_CDC_COLUMN FROM '+@TABLE_NAME+' WHERE '+@CDC_COLUMN+'>='''+CAST(@CDC_START_TIMESTAMP as nvarchar(50))+''' AND '+@CDC_COLUMN+'<'''+CAST(@CDC_END_TIMESTAMP as nvarchar(50))+'''';  
            SELECT @SELECT_STATEMENT as SELECT_STATEMENT,@CDC_QUERY_TEXT as MAX_CDC_QUERY_TEXT;  
  
       END  
END



