-- =======================================================
-- Create Stored Procedure Template for <ABCR_CONTROL>.USP_GET_JOB_PROCESS_DETAILS
-- =======================================================
-- =======================================================
-- Author:      <Poojitha Voggu>    
-- Create Date: <23-08-2022>    
-- Description: <Used to fetch the details about CDC END TIME STAMP,NO OF DAYS, TABLE NAME,CDC QUERY, SELECT QUERY & LOAD TYPE from ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL_R01 & ABCR_CONTROL.VW_Process_contrlol table for the specified TENANT_ID,BOW_ID,SBOW_ID,UOW_ID>    
-- =======================================================
    
CREATE  PROC [ABCR_CONTROL].[USP_GET_PROCESS_CONTROL_DETAILS]   
@TENANT_ID INT,
@BOW_ID INT ,
@SBOW_ID INT,
@UOW_ID BIGINT  

AS    
BEGIN    
    
SET NOCOUNT ON    
    
DECLARE @CDC_END_TIMESTAMP  [DATETIME2](7),@TABLE_NAME VARCHAR(100),@NO_OF_DAYS INT;    
DECLARE @CDC_QUERY VARCHAR(MAx),@CDC_QUERY_TEXT VARCHAR(MAx),@SELECT_QUERY VARCHAR(MAX),@ErMsg Varchar(4000);    
    
DECLARE @LOAD_TYPE VARCHAR(20);    
    
select @LOAD_TYPE= Config_Value_Text from ABCR_CONTROL.VW_UOW_Configuration_Values where UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID and Config_Key_Text='INGESTION_TYPE';    
    
  IF(@LOAD_TYPE='IL')    
      
  BEGIN    
     
   select @CDC_END_TIMESTAMP=CHANGE_DATA_CAPTURE_END_TIMESTAMP from ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL WHERE UOW_ID=@UOW_ID and BOW_ID=@BOW_ID;    
   select @NO_OF_DAYS=Config_Value_Text from ABCR_CONTROL.VW_UOW_Configuration_Values where UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID and Config_Key_Text='NO_OF_DAYS';    
   select @TABLE_NAME=Source_Table_Name from ABCR_CONTROL.VW_Process_Control where  UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID  and Query_Type='SPARK_SQL';    
   select @CDC_QUERY_TEXT= REPLACE(Query_Text,'@cdc_col_value','''') from ABCR_CONTROL.VW_Process_Control where  UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID  and Query_Type='CDC_SQL';    
   Select @CDC_QUERY= @CDC_QUERY_TEXT+CAST(@CDC_END_TIMESTAMP as varchar(30))+'''';    
   select @SELECT_QUERY= Query_Text from ABCR_CONTROL.VW_Process_Control where  UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID  and Query_Type='SPARK_SQL';    
    
   IF @@ROWCOUNT = 0    
     BEGIN    
     SET @ErMsg = 'Error Retrieving Record from ABCR_CONTROL.VW_Process_Control';    
     PRINT @ErMsg;    
     END    
   ELSE    
     BEGIN    
        
    Select @CDC_END_TIMESTAMP as CDC_END_TIMESTAMP, @NO_OF_DAYS as NO_OF_DAYS,     
       @TABLE_NAME as TABLE_NAME,     
       @CDC_QUERY as CDC_QUERY,    
       @SELECT_QUERY as SELECT_QUERY,    
       @LOAD_TYPE as LOAD_TYPE;    
     END    
       
  END     
ELSE IF(@LOAD_TYPE='TL')    
    
BEGIN    
  select @CDC_END_TIMESTAMP=CHANGE_DATA_CAPTURE_END_TIMESTAMP from ABCR_AUDIT.VW_BOW_CDC_AUX_CONTROL WHERE UOW_ID=@UOW_ID and BOW_ID=@BOW_ID;    
  --select @NO_OF_DAYS=Config_Value from ABCR_CONTROL.VW_UOW.configuration_values where UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID and Config_Key='NO_OF_DAYS';    
  select @TABLE_NAME=Source_Table_Name from ABCR_CONTROL.VW_Process_Control where  UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID  and Query_Type='SPARK_SQL';    
  --select @CDC_QUERY_TEXT= REPLACE(Query_Text,'@Value','''') from ABCR_CONTROL.VW_Process_Control where  UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID  and Query_Type='CDC_SQL';    
  --Select @CDC_QUERY= @CDC_QUERY_TEXT+@CDC_END_TIMESTAMP+'''';    
  select @SELECT_QUERY= Query_Text from ABCR_CONTROL.VW_Process_Control where  UOW_ID=@UOW_ID and SBOW_ID=@SBOW_ID and BOW_ID=@BOW_ID  and Query_Type='SPARK_SQL';    
    
   IF @@ROWCOUNT = 0    
    BEGIN    
    SET @ErMsg = 'Error Retrieving Record from ABCR_CONTROL.VW_Process_Control';    
    PRINT @ErMsg;    
    END    
    
   ELSE    
      
   BEGIN    
        
    Select @CDC_END_TIMESTAMP as CDC_END_TIMESTAMP, 0 as NO_OF_DAYS,     
       @TABLE_NAME as TABLE_NAME,     
       'NULL' as CDC_QUERY,    
       @SELECT_QUERY as SELECT_QUERY,    
      @LOAD_TYPE as LOAD_TYPE;    
    END    
    
  END    
    
ELSE    
BEGIn    
  PRINt 'Enter Correct Config value';    
END    
    
END



